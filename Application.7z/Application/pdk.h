

//
// Plugins system definitions
//

#define STRING_LENGTH       260
#define PLUGIN_RES_BASE     9000
#define PLUGIN_VERSION      100
#define PLUGIN_MENU_END     ((PWCHAR)-1)

typedef struct _PLUGIN_ENTRY * (WINAPI *KD_INIT_PLUGIN)(
	const struct _KDP_ROUTINES *RoutineTable,
	ULONG PluginVersion
	);

typedef VOID (WINAPI *KD_DESTROY_PLUGIN)(
	);

typedef VOID (WINAPI *KD_ON_PROCESS_CHANGE)(
	struct _PROCESS_INFO *NewProcess
	);

typedef VOID (WINAPI *KD_MENU_CALLBACK)(
	);


//
// Structures
//

typedef const struct DECLSPEC_ALIGN(1) _PLUGIN_MENU {
    PWCHAR              MenuTitle;
    KD_MENU_CALLBACK    Callback;
} PLUGIN_MENU, *PPLUGIN_MENU;

typedef const struct DECLSPEC_ALIGN(1) _PLUGIN_ENTRY {
    PWCHAR              PluginTitle;
    PPLUGIN_MENU        MenuList;
} PLUGIN_ENTRY, *PPLUGIN_ENTRY;


class CPlugin
{
public:
	CPlugin(HMODULE hModule, PPLUGIN_ENTRY lpPluginEntry) {
		BaseAddress = hModule;
        PluginEntry = lpPluginEntry;
	};
	PWCHAR GetPluginName() {return PluginEntry->PluginTitle;};
    PPLUGIN_MENU GetPluginMenuList() {return PluginEntry->MenuList;};
	HMODULE GetPluginHandle() {return BaseAddress;};
	FARPROC GetPluginRoutine(PCHAR Routine) {return GetProcAddress(BaseAddress, Routine);};
private:
	PPLUGIN_ENTRY PluginEntry;
	HMODULE BaseAddress;
};


extern ULONG PluginsCount;
extern CPlugin **PluginsList;


typedef struct DECLSPEC_ALIGN(1) _THREAD_INFO_EX {
	ULONG ProcessObject;
	ULONG ProcessId;
	ULONG ThreadObject;
	ULONG ThreadId;
	ULONG Teb;
	ULONG ServiceTable;
	ULONG StartAddress;
} THREAD_INFO_EX, *PTHREAD_INFO_EX;

typedef	struct DECLSPEC_ALIGN(1) _PROCESS_INFO {
	ULONG ProcessObject;
	ULONG ImageBase;
	ULONG Peb;
	ULONG ProcessId;
	ULONG ParentId;
	ULONG VirtualSize;
	WCHAR Path[STRING_LENGTH];
} PROCESS_INFO, *PPROCESS_INFO;

typedef struct DECLSPEC_ALIGN(1) _SERVICE_ENTRY_INFO {
	ULONG	Index;
	ULONG	Current;
	ULONG	Original;
} SERVICE_ENTRY_INFO, *PSERVICE_ENTRY_INFO;

typedef struct DECLSPEC_ALIGN(1) _DRIVER_INFO {
	PVOID ImageBase;
	PVOID EntryPoint;
	ULONG ImageSize;
	WCHAR ImagePath[STRING_LENGTH];
} DRIVER_INFO, *PDRIVER_INFO;

//
// Plugins core
//
VOID InitializePlugins();
VOID DestroyPlugins();
VOID KdCallOnProcessChange(PROCESS_ENTRY *NewProcess);
INT_PTR CALLBACK DlgConsole(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);


//
// Plugins System Helper
//
VOID WINAPI KdFreeBuffer(PVOID Buffer);
VOID WINAPIV KdWriteLog(PWCHAR Format, ...);
VOID WINAPI KdWriteLogDirect(PWCHAR Buffer);
ULONG WINAPI KdShowMessage(PWCHAR Message, PWCHAR Title, ULONG uType);
VOID WINAPI KdShowConsole(VOID);
PVOID WINAPI KdGetCurrentProcess(VOID);
PVOID WINAPI KdGetCsrProcess(VOID);
PVOID WINAPI KdGetSystemProcess(VOID);
PVOID WINAPI KdGetSystemIdleProcess(VOID);
PVOID WINAPI KdGetSelectedProcess(VOID);
HWND WINAPI KdGetMainWindow(VOID);


//
// Process Object
//
ULONG WINAPI KdEnumActiveProcesses(PVOID **ProcessObjectList);
VOID WINAPI KdGetProcessInformation(PVOID ProcessObject, PROCESS_INFO *Buffer);
ULONG WINAPI KdEnumProcessModules(PVOID ProcessObject, DLL_ENTRY **Buffer);
HANDLE WINAPI KdOpenProcessByPid(ULONG ProcessId);
HANDLE WINAPI KdOpenProcessByPointer(PVOID ProcessObject);
PVOID WINAPI KdGetProcessPointerByPid(ULONG ProcessId);
PVOID WINAPI KdGetProcessPointerByHandle(HANDLE hProcess);
BOOL WINAPI KdKillProcess(PVOID ProcessObject);
BOOL WINAPI KdForceKillProcess(PVOID ProcessObject);
BOOL WINAPI KdSuspendProcess(PVOID ProcessObject);
BOOL WINAPI KdResumeProcess(PVOID ProcessObject);
BOOL WINAPI KdForceResumeProcess(PVOID ProcessObject);


//
// Thread Object
//
ULONG WINAPI KdEnumActiveThreads(PVOID **ThreadObjectList);
ULONG WINAPI KdEnumProcessThreads(PVOID ProcessObject, PVOID **ThreadObjectList);
VOID WINAPI KdGetThreadInformation(PVOID ThreadObject, THREAD_INFO_EX *Buffer);
VOID WINAPI KdGetThreadParentProcess(PVOID ThreadObject, PROCESS_INFO *ProcessInformation);
HANDLE WINAPI KdOpenThreadByTid(ULONG ThreadId);
HANDLE WINAPI KdOpenThreadByPointer(PVOID ThreadObject);
PVOID WINAPI KdGetThreadPointerByTid(ULONG ThreadId);
PVOID WINAPI KdGetThreadPointerByHandle(HANDLE hThread);
BOOL WINAPI KdForceKillThread(PVOID ThreadObject);
BOOL WINAPI KdSuspendThread(PVOID ThreadObject);
BOOL WINAPI KdResumeThread(PVOID ThreadObject);
BOOL WINAPI KdForceResumeThread(PVOID ThreadObject);
BOOL WINAPI KdGetContextThread(PVOID ThreadObject, CONTEXT *Context);
BOOL WINAPI KdSetContextThread(PVOID ThreadObject, CONTEXT *Context);


//
// Memory Management
//
BOOL WINAPI KdReadVirtualMemory(PVOID ProcessObject, PVOID VirtualAddress, PVOID Buffer, ULONG Size, PULONG BytesRead);
BOOL WINAPI KdWriteVirtualMemory(PVOID ProcessObject, PVOID VirtualAddress, PVOID Buffer, ULONG Size, PULONG BytesWritten);
BOOL WINAPI KdQueryVirtualMemory(PVOID ProcessObject, PVOID VirtualAddress, PMEMORY_BASIC_INFORMATION Buffer, ULONG dwLength);
BOOL WINAPI KdProtectVirtualMemory(PVOID ProcessObject, PVOID VirtualAddress, ULONG dwSize, ULONG NewProtection, PULONG OldProtection);
PVOID WINAPI KdAllocateVirtualMemory(PVOID ProcessObject, ULONG Size);
VOID WINAPI KdFreeVirtualMemory(PVOID ProcessObject, PVOID VirtualAddress);
BOOL WINAPI KdReadPhysicalMemory(PLARGE_INTEGER PhysicalAddress, PVOID Buffer, SIZE_T Size);
BOOL WINAPI KdWritePhysicalMemory(PLARGE_INTEGER PhysicalAddress, PVOID Buffer, SIZE_T Size);
PVOID WINAPI KdAllocateNonpagedPool(ULONG Size);
VOID WINAPI KdFreeNonpagedPool(PVOID NonpagedPoolAddress);
BOOL WINAPI KdUnmapViewOfSection(PVOID ProcessObject, PVOID SectionBase);
ULONG WINAPI KdGetLowestPhysicalPage(VOID);
ULONG WINAPI KdGetHighestPhysicalPage(VOID);
ULONG WINAPI KdGetNumberOfPhysicalPages(VOID);
PVOID WINAPI KdGetHighestUserAddress(VOID);
PVOID WINAPI KdGetSystemRangeStart(VOID);
PVOID WINAPI KdGetUserProbeAddress(VOID);


//
// File System
//
HANDLE WINAPI KdOpenFile(PWCHAR FilePath);
BOOL WINAPI KdReadFileByHandle(HANDLE hFile, PVOID Buffer, ULONG Size, PLARGE_INTEGER Offset);
BOOL WINAPI KdWriteFileByHandle(HANDLE hFile, PVOID Buffer, ULONG Size, PLARGE_INTEGER Offset);
BOOL WINAPI KdReadFileByName(PWCHAR FilePath, PVOID Buffer, ULONG Size, PLARGE_INTEGER Offset);
BOOL WINAPI KdWriteFileByName(PWCHAR FilePath, PVOID Buffer, ULONG Size, PLARGE_INTEGER Offset);
BOOL WINAPI KdReadSectors(ULONG DiskNumber, ULONG SectorNumber, USHORT SectorCount , PVOID Buffer);
BOOL WINAPI KdWriteSectors(ULONG DiskNumber, ULONG SectorNumber, USHORT SectorCount , PVOID Buffer);
BOOL WINAPI KdGetFileNameByHandle(HANDLE hFile, PWCHAR FileName, ULONG Size);
BOOL WINAPI KdGetFileNameByPointer(PVOID FileObject, PWCHAR FileName, ULONG Size);
BOOL WINAPI KdCopyFile(PWCHAR SourceFilePath, PWCHAR DestinationFilePath);
BOOL WINAPI KdDeleteFile(PWCHAR FilePath);
BOOL WINAPI KdForceDeleteFile(PWCHAR FilePath);
BOOL WINAPI KdCheckFileSignature(PWCHAR FilePath);


//
// Driver/Device Object
//
ULONG WINAPI KdEnumKernelModules(DRIVER_INFO **KernelModuleList);
ULONG WINAPI KdEnumDrivers(PVOID **DriverObjectList);
ULONG WINAPI KdEnumDevices(PVOID **DeviceObjectList);
BOOL WINAPI KdGetDriverName(PVOID DriverObject, PWCHAR DriverName, ULONG Size);
BOOL WINAPI KdGetDeviceName(PVOID DeviceObject, PWCHAR DeviceName, ULONG Size);
ULONG WINAPI KdEnumUnloadedDrivers(DRIVER_INFO **DriversList);


//
// Object Manager
//
ULONG WINAPI KdEnumHandles(PVOID ProcessObject, HANDLE_ENTRY **HandlesList);
ULONG WINAPI KdEnumObjectTypes(OBJECT_TYPE_ENTRY **ObjectTypesList);
BOOL WINAPI KdGetObjectName(PVOID Object, PWCHAR ObjectName, ULONG Size);
BOOL WINAPI KdGetObjectTypeName(PVOID Object, PWCHAR ObjectTypeName, ULONG Size);
PVOID WINAPI KdGetObjectPointerByHandle(HANDLE Handle);
BOOL WINAPI KdCloseRemoteHandle(PVOID ProcessObject, HANDLE Handle);


//
// System Control
//
PKIDT_ENTRY WINAPI KdEnumInterrupts(UCHAR ProcessorNumber);
ULONG_PTR WINAPI KdHookInterruptOffset(ULONG Index, ULONG_PTR ServiceRoutine, UCHAR Processor);
USHORT WINAPI KdHookInterruptSelector(ULONG Index, USHORT ServiceRoutine, UCHAR Processor);
ULONG WINAPI KdEnumServiceTable(SERVICE_ENTRY_INFO **Servicetable);
VOID WINAPI KdRestoreServiceTable(VOID);
VOID WINAPI KdHookServiceTable(ULONG Index, PVOID ServiceRoutine);
ULONG WINAPI KdEnumShadowServiceTable(SERVICE_ENTRY_INFO **ShadowServicetable);
VOID WINAPI KdRestoreShadowServiceTable(VOID);
VOID WINAPI KdHookShadowServiceTable(ULONG Index, PVOID ServiceRoutine);
ULONG WINAPI KdEnumActiveTimers(TIMER_ENTRY **TimersList);
BOOL WINAPI KdCancelTimer(PVOID TimerObject);
ULONG WINAPI KdGetCr0(VOID);
ULONG WINAPI KdGetCr4(VOID);
VOID WINAPI KdReadMsr(ULONG Register, PULONGLONG Value);
VOID WINAPI KdWriteMsr(ULONG Register, PULONGLONG Value);
PVOID WINAPI KdGetKernelBase(VOID);
ULONG WINAPI KdGetKernelSize(VOID);
PVOID WINAPI KdGetPsLoadedModuleList(VOID);
PVOID WINAPI KdGetMmLoadedUserImageList(VOID);
PVOID WINAPI KdGetPspCidTable(VOID);
BOOL WINAPI KdCallBiosInterrupt(UCHAR Interrupt, PBIOS_REGISTERS Context);
UCHAR WINAPI KdReadPortChar(USHORT Port);
USHORT WINAPI KdReadPortShort(USHORT Port);
ULONG WINAPI KdReadPortLong(USHORT Port);
VOID WINAPI KdReadPortBufferChar(USHORT Port, PUCHAR Buffer, ULONG Count);
VOID WINAPI KdReadPortBufferShort(USHORT Port, PUSHORT Buffer, ULONG Count);
VOID WINAPI KdReadPortBufferLong(USHORT Port, PULONG Buffer, ULONG Count);
VOID WINAPI KdWritePortChar(USHORT Port, UCHAR Value);
VOID WINAPI KdWritePortShort(USHORT Port, USHORT Value);
VOID WINAPI KdWritePortLong(USHORT Port, ULONG Value);
VOID WINAPI KdWritePortBufferChar(USHORT Port, PUCHAR Buffer, ULONG Count);
VOID WINAPI KdWritePortBufferShort(USHORT Port, PUSHORT Buffer, ULONG Count);
VOID WINAPI KdWritePortBufferLong(USHORT Port, PULONG Buffer, ULONG Count);
BOOL WINAPI KdDeviceRead(PVOID DeviceObject, PVOID FileObject, PVOID Buffer, ULONG Length, PLARGE_INTEGER StartingOffset);
BOOL WINAPI KdDeviceWrite(PVOID DeviceObject, PVOID FileObject, PVOID Buffer, ULONG Length, PLARGE_INTEGER StartingOffset);
BOOL WINAPI KdDeviceIoControl(PVOID DeviceObject, PVOID FileObject, ULONG IoControlCode, PVOID InputBuffer, ULONG InputBufferLength, PVOID OutputBuffer, ULONG OutputBufferLength, BOOL InternalDeviceIoControl);
VOID WINAPI KdExecuteCode(PVOID Process, PKSTART_ROUTINE StartAddress, PVOID Context);



typedef VOID (WINAPI *KDP_FreeBuffer)(PVOID Buffer);
typedef VOID (WINAPIV *KDP_WriteLog)(PWCHAR Format, ...);
typedef VOID (WINAPI *KDP_WriteLogDirect)(PWCHAR Buffer);
typedef ULONG (WINAPI *KDP_ShowMessage)(PWCHAR Message, PWCHAR Title, ULONG uType);
typedef VOID (WINAPI *KDP_ShowConsole)(VOID);
typedef PVOID (WINAPI *KDP_GetCurrentProcess)(VOID);
typedef PVOID (WINAPI *KDP_GetCsrProcess)(VOID);
typedef PVOID (WINAPI *KDP_GetSystemProcess)(VOID);
typedef PVOID (WINAPI *KDP_GetSystemIdleProcess)(VOID);
typedef PVOID (WINAPI *KDP_GetSelectedProcess)(VOID);
typedef HWND (WINAPI *KDP_GetMainWindow)(VOID);
typedef ULONG (WINAPI *KDP_EnumActiveProcesses)(PVOID **ProcessObjectList);
typedef VOID (WINAPI *KDP_GetProcessInformation)(PVOID ProcessObject, PROCESS_INFO *Buffer);
typedef ULONG (WINAPI *KDP_EnumProcessModules)(PVOID ProcessObject, DLL_ENTRY **Buffer);
typedef HANDLE (WINAPI *KDP_OpenProcessByPid)(ULONG ProcessId);
typedef HANDLE (WINAPI *KDP_OpenProcessByPointer)(PVOID ProcessObject);
typedef PVOID (WINAPI *KDP_GetProcessPointerByPid)(ULONG ProcessId);
typedef PVOID (WINAPI *KDP_GetProcessPointerByHandle)(HANDLE hProcess);
typedef BOOL (WINAPI *KDP_KillProcess)(PVOID ProcessObject);
typedef BOOL (WINAPI *KDP_ForceKillProcess)(PVOID ProcessObject);
typedef BOOL (WINAPI *KDP_SuspendProcess)(PVOID ProcessObject);
typedef BOOL (WINAPI *KDP_ResumeProcess)(PVOID ProcessObject);
typedef BOOL (WINAPI *KDP_ForceResumeProcess)(PVOID ProcessObject);
typedef ULONG (WINAPI *KDP_EnumActiveThreads)(PVOID **ThreadObjectList);
typedef ULONG (WINAPI *KDP_EnumProcessThreads)(PVOID ProcessObject, PVOID **ThreadObjectList);
typedef VOID (WINAPI *KDP_GetThreadInformation)(PVOID ThreadObject, THREAD_INFO_EX *Buffer);
typedef VOID (WINAPI *KDP_GetThreadParentProcess)(PVOID ThreadObject, PROCESS_INFO *ProcessInformation);
typedef HANDLE (WINAPI *KDP_OpenThreadByTid)(ULONG ThreadId);
typedef HANDLE (WINAPI *KDP_OpenThreadByPointer)(PVOID ThreadObject);
typedef PVOID (WINAPI *KDP_GetThreadPointerByTid)(ULONG ThreadId);
typedef PVOID (WINAPI *KDP_GetThreadPointerByHandle)(HANDLE hThread);
typedef BOOL (WINAPI *KDP_ForceKillThread)(PVOID ThreadObject);
typedef BOOL (WINAPI *KDP_SuspendThread)(PVOID ThreadObject);
typedef BOOL (WINAPI *KDP_ResumeThread)(PVOID ThreadObject);
typedef BOOL (WINAPI *KDP_ForceResumeThread)(PVOID ThreadObject);
typedef BOOL (WINAPI *KDP_GetContextThread)(PVOID ThreadObject, CONTEXT *Context);
typedef BOOL (WINAPI *KDP_SetContextThread)(PVOID ThreadObject, CONTEXT *Context);
typedef BOOL (WINAPI *KDP_ReadVirtualMemory)(PVOID ProcessObject, PVOID VirtualAddress, PVOID Buffer, ULONG Size, PULONG BytesRead);
typedef BOOL (WINAPI *KDP_WriteVirtualMemory)(PVOID ProcessObject, PVOID VirtualAddress, PVOID Buffer, ULONG Size, PULONG BytesWritten);
typedef BOOL (WINAPI *KDP_QueryVirtualMemory)(PVOID ProcessObject, PVOID VirtualAddress, PMEMORY_BASIC_INFORMATION Buffer, ULONG dwLength);
typedef BOOL (WINAPI *KDP_ProtectVirtualMemory)(PVOID ProcessObject, PVOID VirtualAddress, ULONG dwSize, ULONG NewProtection, PULONG OldProtection);
typedef PVOID (WINAPI *KDP_AllocateVirtualMemory)(PVOID ProcessObject, ULONG Size);
typedef VOID (WINAPI *KDP_FreeVirtualMemory)(PVOID ProcessObject, PVOID VirtualAddress);
typedef BOOL (WINAPI *KDP_ReadPhysicalMemory)(PLARGE_INTEGER PhysicalAddress, PVOID Buffer, SIZE_T Size);
typedef BOOL (WINAPI *KDP_WritePhysicalMemory)(PLARGE_INTEGER PhysicalAddress, PVOID Buffer, SIZE_T Size);
typedef PVOID (WINAPI *KDP_AllocateNonpagedPool)(ULONG Size);
typedef VOID (WINAPI *KDP_FreeNonpagedPool)(PVOID NonpagedPoolAddress);
typedef BOOL (WINAPI *KDP_UnmapViewOfSection)(PVOID ProcessObject, PVOID SectionBase);
typedef ULONG (WINAPI *KDP_GetLowestPhysicalPage)(VOID);
typedef ULONG (WINAPI *KDP_GetHighestPhysicalPage)(VOID);
typedef ULONG (WINAPI *KDP_GetNumberOfPhysicalPages)(VOID);
typedef PVOID (WINAPI *KDP_GetHighestUserAddress)(VOID);
typedef PVOID (WINAPI *KDP_GetSystemRangeStart)(VOID);
typedef PVOID (WINAPI *KDP_GetUserProbeAddress)(VOID);
typedef HANDLE (WINAPI *KDP_OpenFile)(PWCHAR FilePath);
typedef BOOL (WINAPI *KDP_ReadFileByHandle)(HANDLE hFile, PVOID Buffer, ULONG Size, PLARGE_INTEGER Offset);
typedef BOOL (WINAPI *KDP_WriteFileByHandle)(HANDLE hFile, PVOID Buffer, ULONG Size, PLARGE_INTEGER Offset);
typedef BOOL (WINAPI *KDP_ReadFileByName)(PWCHAR FilePath, PVOID Buffer, ULONG Size, PLARGE_INTEGER Offset);
typedef BOOL (WINAPI *KDP_WriteFileByName)(PWCHAR FilePath, PVOID Buffer, ULONG Size, PLARGE_INTEGER Offset);
typedef BOOL (WINAPI *KDP_ReadSectors)(ULONG DiskNumber, ULONG SectorNumber, USHORT SectorCount , PVOID Buffer);
typedef BOOL (WINAPI *KDP_WriteSectors)(ULONG DiskNumber, ULONG SectorNumber, USHORT SectorCount , PVOID Buffer);
typedef BOOL (WINAPI *KDP_GetFileNameByHandle)(HANDLE hFile, PWCHAR FileName, ULONG Size);
typedef BOOL (WINAPI *KDP_GetFileNameByPointer)(PVOID FileObject, PWCHAR FileName, ULONG Size);
typedef BOOL (WINAPI *KDP_CopyFile)(PWCHAR SourceFilePath, PWCHAR DestinationFilePath);
typedef BOOL (WINAPI *KDP_DeleteFile)(PWCHAR FilePath);
typedef BOOL (WINAPI *KDP_ForceDeleteFile)(PWCHAR FilePath);
typedef BOOL (WINAPI *KDP_CheckFileSignature)(PWCHAR FilePath);
typedef ULONG (WINAPI *KDP_EnumKernelModules)(DRIVER_INFO **KernelModuleList);
typedef ULONG (WINAPI *KDP_EnumDrivers)(PVOID **DriverObjectList);
typedef ULONG (WINAPI *KDP_EnumDevices)(PVOID **DeviceObjectList);
typedef BOOL (WINAPI *KDP_GetDriverName)(PVOID DriverObject, PWCHAR DriverName, ULONG Size);
typedef BOOL (WINAPI *KDP_GetDeviceName)(PVOID DeviceObject, PWCHAR DeviceName, ULONG Size);
typedef ULONG (WINAPI *KDP_EnumUnloadedDrivers)(DRIVER_INFO **DriversList);
typedef ULONG (WINAPI *KDP_EnumHandles)(PVOID ProcessObject, HANDLE_ENTRY **HandlesList);
typedef ULONG (WINAPI *KDP_EnumObjectTypes)(OBJECT_TYPE_ENTRY **ObjectTypesList);
typedef BOOL (WINAPI *KDP_GetObjectName)(PVOID Object, PWCHAR ObjectName, ULONG Size);
typedef BOOL (WINAPI *KDP_GetObjectTypeName)(PVOID Object, PWCHAR ObjectTypeName, ULONG Size);
typedef PVOID (WINAPI *KDP_GetObjectPointerByHandle)(HANDLE Handle);
typedef BOOL (WINAPI *KDP_CloseRemoteHandle)(PVOID ProcessObject, HANDLE Handle);
typedef PKIDT_ENTRY (WINAPI *KDP_EnumInterrupts)(UCHAR ProcessorNumber);
typedef ULONG_PTR (WINAPI *KDP_HookInterruptOffset)(ULONG Index, ULONG_PTR ServiceRoutine, UCHAR Processor);
typedef USHORT (WINAPI *KDP_HookInterruptSelector)(ULONG Index, USHORT ServiceRoutine, UCHAR Processor);
typedef ULONG (WINAPI *KDP_EnumServiceTable)(SERVICE_ENTRY_INFO **Servicetable);
typedef VOID (WINAPI *KDP_RestoreServiceTable)(VOID);
typedef VOID (WINAPI *KDP_HookServiceTable)(ULONG Index, PVOID ServiceRoutine);
typedef ULONG (WINAPI *KDP_EnumShadowServiceTable)(SERVICE_ENTRY_INFO **ShadowServicetable);
typedef VOID (WINAPI *KDP_RestoreShadowServiceTable)(VOID);
typedef VOID (WINAPI *KDP_HookShadowServiceTable)(ULONG Index, PVOID ServiceRoutine);
typedef ULONG (WINAPI *KDP_EnumActiveTimers)(TIMER_ENTRY **TimersList);
typedef BOOL (WINAPI *KDP_CancelTimer)(PVOID TimerObject);
typedef ULONG (WINAPI *KDP_GetCr0)(VOID);
typedef ULONG (WINAPI *KDP_GetCr4)(VOID);
typedef VOID (WINAPI *KDP_ReadMsr)(ULONG Register, PULONGLONG Value);
typedef VOID (WINAPI *KDP_WriteMsr)(ULONG Register, PULONGLONG Value);
typedef PVOID (WINAPI *KDP_GetKernelBase)(VOID);
typedef ULONG (WINAPI *KDP_GetKernelSize)(VOID);
typedef PVOID (WINAPI *KDP_GetPsLoadedModuleList)(VOID);
typedef PVOID (WINAPI *KDP_GetMmLoadedUserImageList)(VOID);
typedef PVOID (WINAPI *KDP_GetPspCidTable)(VOID);
typedef BOOL (WINAPI *KDP_CallBiosInterrupt)(UCHAR Interrupt, PBIOS_REGISTERS Context);
typedef UCHAR (WINAPI *KDP_ReadPortChar)(USHORT Port);
typedef USHORT (WINAPI *KDP_ReadPortShort)(USHORT Port);
typedef ULONG (WINAPI *KDP_ReadPortLong)(USHORT Port);
typedef VOID (WINAPI *KDP_ReadPortBufferChar)(USHORT Port, PUCHAR Buffer, ULONG Count);
typedef VOID (WINAPI *KDP_ReadPortBufferShort)(USHORT Port, PUSHORT Buffer, ULONG Count);
typedef VOID (WINAPI *KDP_ReadPortBufferLong)(USHORT Port, PULONG Buffer, ULONG Count);
typedef VOID (WINAPI *KDP_WritePortChar)(USHORT Port, UCHAR Value);
typedef VOID (WINAPI *KDP_WritePortShort)(USHORT Port, USHORT Value);
typedef VOID (WINAPI *KDP_WritePortLong)(USHORT Port, ULONG Value);
typedef VOID (WINAPI *KDP_WritePortBufferChar)(USHORT Port, PUCHAR Buffer, ULONG Count);
typedef VOID (WINAPI *KDP_WritePortBufferShort)(USHORT Port, PUSHORT Buffer, ULONG Count);
typedef VOID (WINAPI *KDP_WritePortBufferLong)(USHORT Port, PULONG Buffer, ULONG Count);
typedef BOOL (WINAPI *KDP_DeviceRead)(PVOID DeviceObject, PVOID FileObject, PVOID Buffer, ULONG Length, PLARGE_INTEGER StartingOffset);
typedef BOOL (WINAPI *KDP_DeviceWrite)(PVOID DeviceObject, PVOID FileObject, PVOID Buffer, ULONG Length, PLARGE_INTEGER StartingOffset);
typedef BOOL (WINAPI *KDP_DeviceIoControl)(PVOID DeviceObject, PVOID FileObject, ULONG IoControlCode, PVOID InputBuffer, ULONG InputBufferLength, PVOID OutputBuffer, ULONG OutputBufferLength, BOOL InternalDeviceIoControl);
typedef VOID (WINAPI *KDP_ExecuteCode)(PVOID Process, PKSTART_ROUTINE StartAddress, PVOID Context);

typedef struct DECLSPEC_ALIGN(1) _KDP_ROUTINES {
    ULONG SizeOfStruct;
    KDP_FreeBuffer FreeBuffer;
    KDP_WriteLog WriteLog;
    KDP_WriteLogDirect WriteLogDirect;
    KDP_ShowMessage ShowMessage;
    KDP_ShowConsole ShowConsole;
    KDP_GetCurrentProcess GetCurrentProcess;
    KDP_GetCsrProcess GetCsrProcess;
    KDP_GetSystemProcess GetSystemProcess;
    KDP_GetSystemIdleProcess GetSystemIdleProcess;
    KDP_GetSelectedProcess GetSelectedProcess;
    KDP_GetMainWindow GetMainWindow;
    KDP_EnumActiveProcesses EnumActiveProcesses;
    KDP_GetProcessInformation GetProcessInformation;
    KDP_EnumProcessModules EnumProcessModules;
    KDP_OpenProcessByPid OpenProcessByPid;
    KDP_OpenProcessByPointer OpenProcessByPointer;
    KDP_GetProcessPointerByPid GetProcessPointerByPid;
    KDP_GetProcessPointerByHandle GetProcessPointerByHandle;
    KDP_KillProcess KillProcess;
    KDP_ForceKillProcess ForceKillProcess;
    KDP_SuspendProcess SuspendProcess;
    KDP_ResumeProcess ResumeProcess;
    KDP_ForceResumeProcess ForceResumeProcess;
    KDP_EnumActiveThreads EnumActiveThreads;
    KDP_EnumProcessThreads EnumProcessThreads;
    KDP_GetThreadInformation GetThreadInformation;
    KDP_GetThreadParentProcess GetThreadParentProcess;
    KDP_OpenThreadByTid OpenThreadByTid;
    KDP_OpenThreadByPointer OpenThreadByPointer;
    KDP_GetThreadPointerByTid GetThreadPointerByTid;
    KDP_GetThreadPointerByHandle GetThreadPointerByHandle;
    KDP_ForceKillThread ForceKillThread;
    KDP_SuspendThread SuspendThread;
    KDP_ResumeThread ResumeThread;
    KDP_ForceResumeThread ForceResumeThread;
    KDP_GetContextThread GetContextThread;
    KDP_SetContextThread SetContextThread;
    KDP_ReadVirtualMemory ReadVirtualMemory;
    KDP_WriteVirtualMemory WriteVirtualMemory;
    KDP_QueryVirtualMemory QueryVirtualMemory;
    KDP_ProtectVirtualMemory ProtectVirtualMemory;
    KDP_AllocateVirtualMemory AllocateVirtualMemory;
    KDP_FreeVirtualMemory FreeVirtualMemory;
    KDP_ReadPhysicalMemory ReadPhysicalMemory;
    KDP_WritePhysicalMemory WritePhysicalMemory;
    KDP_AllocateNonpagedPool AllocateNonpagedPool;
    KDP_FreeNonpagedPool FreeNonpagedPool;
    KDP_UnmapViewOfSection UnmapViewOfSection;
    KDP_GetLowestPhysicalPage GetLowestPhysicalPage;
    KDP_GetHighestPhysicalPage GetHighestPhysicalPage;
    KDP_GetNumberOfPhysicalPages GetNumberOfPhysicalPages;
    KDP_GetHighestUserAddress GetHighestUserAddress;
    KDP_GetSystemRangeStart GetSystemRangeStart;
    KDP_GetUserProbeAddress GetUserProbeAddress;
    KDP_OpenFile OpenFile;
    KDP_ReadFileByHandle ReadFileByHandle;
    KDP_WriteFileByHandle WriteFileByHandle;
    KDP_ReadFileByName ReadFileByName;
    KDP_WriteFileByName WriteFileByName;
    KDP_ReadSectors ReadSectors;
    KDP_WriteSectors WriteSectors;
    KDP_GetFileNameByHandle GetFileNameByHandle;
    KDP_GetFileNameByPointer GetFileNameByPointer;
    KDP_CopyFile CopyFile;
    KDP_DeleteFile DeleteFile;
    KDP_ForceDeleteFile ForceDeleteFile;
    KDP_CheckFileSignature CheckFileSignature;
    KDP_EnumKernelModules EnumKernelModules;
    KDP_EnumDrivers EnumDrivers;
    KDP_EnumDevices EnumDevices;
    KDP_GetDriverName GetDriverName;
    KDP_GetDeviceName GetDeviceName;
    KDP_EnumUnloadedDrivers EnumUnloadedDrivers;
    KDP_EnumHandles EnumHandles;
    KDP_EnumObjectTypes EnumObjectTypes;
    KDP_GetObjectName GetObjectName;
    KDP_GetObjectTypeName GetObjectTypeName;
    KDP_GetObjectPointerByHandle GetObjectPointerByHandle;
    KDP_CloseRemoteHandle CloseRemoteHandle;
    KDP_EnumInterrupts EnumInterrupts;
    KDP_HookInterruptOffset HookInterruptOffset;
    KDP_HookInterruptSelector HookInterruptSelector;
    KDP_EnumServiceTable EnumServiceTable;
    KDP_RestoreServiceTable RestoreServiceTable;
    KDP_HookServiceTable HookServiceTable;
    KDP_EnumShadowServiceTable EnumShadowServiceTable;
    KDP_RestoreShadowServiceTable RestoreShadowServiceTable;
    KDP_HookShadowServiceTable HookShadowServiceTable;
    KDP_EnumActiveTimers EnumActiveTimers;
    KDP_CancelTimer CancelTimer;
    KDP_GetCr0 GetCr0;
    KDP_GetCr4 GetCr4;
    KDP_ReadMsr ReadMsr;
    KDP_WriteMsr WriteMsr;
    KDP_GetKernelBase GetKernelBase;
    KDP_GetKernelSize GetKernelSize;
    KDP_GetPsLoadedModuleList GetPsLoadedModuleList;
    KDP_GetMmLoadedUserImageList GetMmLoadedUserImageList;
    KDP_GetPspCidTable GetPspCidTable;
    KDP_CallBiosInterrupt CallBiosInterrupt;
    KDP_ReadPortChar ReadPortChar;
    KDP_ReadPortShort ReadPortShort;
    KDP_ReadPortLong ReadPortLong;
    KDP_ReadPortBufferChar ReadPortBufferChar;
    KDP_ReadPortBufferShort ReadPortBufferShort;
    KDP_ReadPortBufferLong ReadPortBufferLong;
    KDP_WritePortChar WritePortChar;
    KDP_WritePortShort WritePortShort;
    KDP_WritePortLong WritePortLong;
    KDP_WritePortBufferChar WritePortBufferChar;
    KDP_WritePortBufferShort WritePortBufferShort;
    KDP_WritePortBufferLong WritePortBufferLong;
    KDP_DeviceRead DeviceRead;
    KDP_DeviceWrite DeviceWrite;
    KDP_DeviceIoControl DeviceIoControl;
    KDP_ExecuteCode ExecuteCode;
}KDP_ROUTINES, *PKDP_ROUTINES;

static const KDP_ROUTINES RoutineTable = {
    sizeof(KDP_ROUTINES),
    KdFreeBuffer,
    KdWriteLog,
    KdWriteLogDirect,
    KdShowMessage,
    KdShowConsole,
    KdGetCurrentProcess,
    KdGetCsrProcess,
    KdGetSystemProcess,
    KdGetSystemIdleProcess,
    KdGetSelectedProcess,
    KdGetMainWindow,
    KdEnumActiveProcesses,
    KdGetProcessInformation,
    KdEnumProcessModules,
    KdOpenProcessByPid,
    KdOpenProcessByPointer,
    KdGetProcessPointerByPid,
    KdGetProcessPointerByHandle,
    KdKillProcess,
    KdForceKillProcess,
    KdSuspendProcess,
    KdResumeProcess,
    KdForceResumeProcess,
    KdEnumActiveThreads,
    KdEnumProcessThreads,
    KdGetThreadInformation,
    KdGetThreadParentProcess,
    KdOpenThreadByTid,
    KdOpenThreadByPointer,
    KdGetThreadPointerByTid,
    KdGetThreadPointerByHandle,
    KdForceKillThread,
    KdSuspendThread,
    KdResumeThread,
    KdForceResumeThread,
    KdGetContextThread,
    KdSetContextThread,
    KdReadVirtualMemory,
    KdWriteVirtualMemory,
    KdQueryVirtualMemory,
    KdProtectVirtualMemory,
    KdAllocateVirtualMemory,
    KdFreeVirtualMemory,
    KdReadPhysicalMemory,
    KdWritePhysicalMemory,
    KdAllocateNonpagedPool,
    KdFreeNonpagedPool,
    KdUnmapViewOfSection,
    KdGetLowestPhysicalPage,
    KdGetHighestPhysicalPage,
    KdGetNumberOfPhysicalPages,
    KdGetHighestUserAddress,
    KdGetSystemRangeStart,
    KdGetUserProbeAddress,
    KdOpenFile,
    KdReadFileByHandle,
    KdWriteFileByHandle,
    KdReadFileByName,
    KdWriteFileByName,
    KdReadSectors,
    KdWriteSectors,
    KdGetFileNameByHandle,
    KdGetFileNameByPointer,
    KdCopyFile,
    KdDeleteFile,
    KdForceDeleteFile,
    KdCheckFileSignature,
    KdEnumKernelModules,
    KdEnumDrivers,
    KdEnumDevices,
    KdGetDriverName,
    KdGetDeviceName,
    KdEnumUnloadedDrivers,
    KdEnumHandles,
    KdEnumObjectTypes,
    KdGetObjectName,
    KdGetObjectTypeName,
    KdGetObjectPointerByHandle,
    KdCloseRemoteHandle,
    KdEnumInterrupts,
    KdHookInterruptOffset,
    KdHookInterruptSelector,
    KdEnumServiceTable,
    KdRestoreServiceTable,
    KdHookServiceTable,
    KdEnumShadowServiceTable,
    KdRestoreShadowServiceTable,
    KdHookShadowServiceTable,
    KdEnumActiveTimers,
    KdCancelTimer,
    KdGetCr0,
    KdGetCr4,
    KdReadMsr,
    KdWriteMsr,
    KdGetKernelBase,
    KdGetKernelSize,
    KdGetPsLoadedModuleList,
    KdGetMmLoadedUserImageList,
    KdGetPspCidTable,
    KdCallBiosInterrupt,
    KdReadPortChar,
    KdReadPortShort,
    KdReadPortLong,
    KdReadPortBufferChar,
    KdReadPortBufferShort,
    KdReadPortBufferLong,
    KdWritePortChar,
    KdWritePortShort,
    KdWritePortLong,
    KdWritePortBufferChar,
    KdWritePortBufferShort,
    KdWritePortBufferLong,
    KdDeviceRead,
    KdDeviceWrite,
    KdDeviceIoControl,
    KdExecuteCode,
};