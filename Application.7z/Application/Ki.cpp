#include <windows.h>
#include <math.h>
#include <imagehlp.h>
#include <shlwapi.h>
#include <stdio.h>
#include <psapi.h>
#include "Ki.h"
#include "Symbols.h"
#include "help.h"
#include "ntdll.h"
#include "shadow_service_strings.h"

#pragma comment (lib, "imagehlp.lib")
#pragma warning (disable : 4996)


NTSTATUS (NTAPI *pNtQuerySystemInformation)(SYSTEM_INFORMATION_CLASS, PVOID, ULONG, PULONG);
NTSTATUS (NTAPI *pNtLoadDriver)(PUNICODE_STRING);
NTSTATUS (NTAPI *pNtUnloadDriver)(PUNICODE_STRING);
NTSTATUS (NTAPI *pNtDeviceIoControlFile)( HANDLE, HANDLE, PVOID, PVOID, PVOID, ULONG, PVOID, ULONG, PVOID, ULONG);
PVOID (NTAPI *CsrGetProcessId)(VOID);

HANDLE DeviceHandle;
WCHAR CurrentKernelFileName[260], CurrentSystemroot[260];
WCHAR DriverPath[260], DeviceName[256];

SHORT NtBuildNumber;
BOOL CaptureDbgMode;
WCHAR *ErrorMsg;
ULONG_PTR *KiSsdt, *KiShadowSsdt;
PWCHAR *KiSsdtStrings, *KiShadowSsdtStrings;
ULONG KiSsdtLimit, KiShadowSsdtLimit;
PPROCESS_ENTRY KiProcessList;
PROCESS_ENTRY KiKdProcess;
PROCESS_ENTRY KiCsrProcess;
PROCESS_ENTRY KiSystemProcess;
PROCESS_ENTRY KiIdleProcess;
ULONG KiProcessCount;
PROCESS_ENTRY KiCurrentProcess;
ULONG_PTR InterruptServiceRoutines[256];
PVOID KiReadBuffer, KiReadAddress;
SIZE_T KiReadSize;





SHORT GetNtBuildNumber(VOID)
{
	HKEY hKey;
	LONG lRet;
	WCHAR BuildString[16] = L"";
	DWORD BufferSize = sizeof(BuildString);
	SHORT BuildNumber = 0;

	lRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE,
						L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion",
						0, 
						KEY_QUERY_VALUE,
						&hKey);

	if(lRet == ERROR_SUCCESS) {
		if (ERROR_SUCCESS == RegQueryValueEx(hKey,
											 L"CurrentBuildNumber", 
											 NULL, 
											 NULL,
											 (LPBYTE)BuildString,
											 &BufferSize)) {
			BuildNumber = (SHORT)wcstoul(BuildString, NULL, 10);
		}
		RegCloseKey(hKey);
	}
	return BuildNumber;
}

PWCHAR *GetSsdtStrings(VOID)
{
	LOADED_IMAGE LoadedImage;
	PVOID PtrImage;
	PWCHAR *Result;
	PUSHORT Ordinals;
	PULONG ExportRva;
	PCHAR FunctionString, *StringRva;
	ULONG ServiceId, FunctionId;

	MapAndLoad("ntdll.dll", NULL, &LoadedImage, FALSE, TRUE);
	PtrImage = calloc(LoadedImage.FileHeader->OptionalHeader.SizeOfImage, sizeof(UCHAR));
	CopyMemory((PUCHAR)PtrImage, LoadedImage.MappedAddress, LoadedImage.FileHeader->OptionalHeader.SizeOfHeaders);
	for (WORD Index = 0; Index < LoadedImage.FileHeader->FileHeader.NumberOfSections; Index++)
	{
		CopyMemory((PUCHAR)PtrImage + LoadedImage.Sections[Index].VirtualAddress,
				   LoadedImage.MappedAddress + LoadedImage.Sections[Index].PointerToRawData,
				   LoadedImage.Sections[Index].SizeOfRawData
				   );
	}
	UnMapAndLoad(&LoadedImage);
	LoadedImage.FileHeader = (PIMAGE_NT_HEADERS)((ULONG_PTR)PtrImage + ((PIMAGE_DOS_HEADER)PtrImage)->e_lfanew);
	
	PIMAGE_EXPORT_DIRECTORY ExportDirectory = (PIMAGE_EXPORT_DIRECTORY)(LoadedImage.FileHeader->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress + (ULONG_PTR)PtrImage);
	StringRva = (PCHAR *)(ExportDirectory->AddressOfNames + (ULONG_PTR)PtrImage);
	Ordinals = (PUSHORT)(ExportDirectory->AddressOfNameOrdinals + (ULONG_PTR)PtrImage);
	ExportRva = (PULONG)(ExportDirectory->AddressOfFunctions + (ULONG_PTR)PtrImage);

	Result = (PWCHAR *)calloc(KiSsdtLimit, sizeof(PWCHAR));
	for (ULONG Index = 0; Index < KiSsdtLimit; Index++) 
	{
		Result[Index] = L"Unknown Entry";
	}

	for (ULONG Index = 0; Index < ExportDirectory->NumberOfNames; Index++)
	{
		FunctionId = ExportRva[Ordinals[Index]] + (ULONG_PTR)PtrImage;
		FunctionString = StringRva[Index] + (ULONG_PTR)PtrImage;
		if (*(PUCHAR)FunctionId == 0xb8 && 
			*(PUCHAR)(FunctionId + 5)  == 0xba &&
			*(PUCHAR)(FunctionId + 10) == 0xff &&
			(*(PUCHAR)(FunctionId + 12) & 0xc0) == 0xc0)
		{
			if (FunctionString[0] == 'N' && FunctionString[1] == 't')
			{
				ServiceId = *(PULONG)(FunctionId + 1);
				if (ServiceId < KiSsdtLimit)
				{
					Result[ServiceId] = (PWCHAR)calloc(256, sizeof(WCHAR));
					_snwprintf_s(Result[ServiceId], 256, _TRUNCATE, L"%S", FunctionString);
				}
			}
		}
	}
	free(PtrImage);
	return Result;
}

DWORD InstallDriver(PWCHAR ImagePath, PWCHAR SymbolicLink)
{
	DWORD Status, Ret = 1, Value;
	UNICODE_STRING usKey;
	HKEY hk, hk2;
	WCHAR wcBuffer[1024];
    WCHAR wcBuffer2[1024];


    _snwprintf_s(wcBuffer, COF(wcBuffer), L"SYSTEM\\CurrentControlSet\\Services\\%s", SymbolicLink);
	
	if(RegCreateKeyEx(HKEY_LOCAL_MACHINE, 
		wcBuffer, 
		0,
		NULL,
		REG_OPTION_NON_VOLATILE,
		KEY_ALL_ACCESS,
		NULL,
		&hk,
		NULL)!=ERROR_SUCCESS)
	{
		return 0;
	}

	_snwprintf_s(wcBuffer, COF(wcBuffer), L"\\??\\%s", ImagePath);
	if(RegSetValueEx(hk, L"ImagePath", 0, REG_EXPAND_SZ, (const PBYTE)wcBuffer, lstrlen(wcBuffer)*sizeof(WCHAR)) != ERROR_SUCCESS)
	{
		Ret = 0;
		goto cleanup;
	}

	Value = SERVICE_KERNEL_DRIVER;
	if(RegSetValueEx(hk, L"Type", 0, REG_DWORD, (LPBYTE)&Value, sizeof(DWORD)) != ERROR_SUCCESS)
	{
		Ret = 0;
		goto cleanup;
	}
	
	Value = SERVICE_DEMAND_START;
	if(RegSetValueEx(hk, L"Start", 0, REG_DWORD, (LPBYTE)&Value, sizeof(DWORD)) != ERROR_SUCCESS)
	{
		Ret = 0;
		goto cleanup;
	}

	Value = SERVICE_ERROR_NORMAL;
	if(RegSetValueEx(hk, L"ErrorControl", 0, REG_DWORD, (LPBYTE)&Value, sizeof(DWORD)) != ERROR_SUCCESS)
	{
		Ret = 0;
		goto cleanup;
	}

	_snwprintf_s(wcBuffer, COF(wcBuffer), L"\\Registry\\Machine\\System\\CurrentControlSet\\Services\\%s", SymbolicLink);
	KdInitUnicodeString(&usKey, wcBuffer);

    switch (GetSystemMetrics(SM_CLEANBOOT))
    {
    case 1:
        _snwprintf_s(wcBuffer2, COF(wcBuffer2), L"SYSTEM\\CurrentControlSet\\Control\\SafeBoot\\Minimal\\%s.sys", SymbolicLink);
        RegCreateKeyEx(HKEY_LOCAL_MACHINE, wcBuffer2, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &hk2, NULL);
        RegCloseKey(hk2);
        break;

    case 2:
        _snwprintf_s(wcBuffer2, COF(wcBuffer2), L"SYSTEM\\CurrentControlSet\\Control\\SafeBoot\\Network\\%s.sys", SymbolicLink);
        RegCreateKeyEx(HKEY_LOCAL_MACHINE, wcBuffer2, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &hk2, NULL);
        RegCloseKey(hk2);
        break;
    }

	Status = pNtLoadDriver(&usKey);
	if(Status != STATUS_SUCCESS)
	{	
		Ret = 0;
	}

	SHDeleteKey(hk, L"Enum");
	SHDeleteKey(hk, L"Security");

cleanup:

	RegCloseKey(hk); 

	return Ret; 
}

DWORD UninstallDriver(PWCHAR ImagePath, PWCHAR SymbolicLink)
{
	DWORD Status, Ret = 1, Value = SERVICE_KERNEL_DRIVER;
	UNICODE_STRING usKey;
	HKEY hk;
	WCHAR wcBuffer[1024];

    _snwprintf_s(wcBuffer, COF(wcBuffer), L"SYSTEM\\CurrentControlSet\\Services\\%s", SymbolicLink);
	
	RegCreateKeyEx(HKEY_LOCAL_MACHINE, 
		wcBuffer, 
		0,
		NULL,
		REG_OPTION_NON_VOLATILE,
		KEY_ALL_ACCESS,
		NULL,
		&hk,
		NULL);

    _snwprintf_s(wcBuffer, COF(wcBuffer), L"\\??\\%s", ImagePath);
	RegSetValueEx(hk, L"ImagePath", 0, REG_EXPAND_SZ, (const PBYTE)wcBuffer, lstrlen(wcBuffer)*sizeof(WCHAR));

	Value = SERVICE_KERNEL_DRIVER;
	RegSetValueEx(hk, L"Type", 0, REG_DWORD, (LPBYTE)&Value, sizeof(DWORD));
	
	Value = SERVICE_DEMAND_START;
	RegSetValueEx(hk, L"Start", 0, REG_DWORD, (LPBYTE)&Value, sizeof(DWORD));

	Value = SERVICE_ERROR_NORMAL;
	RegSetValueEx(hk, L"ErrorControl", 0, REG_DWORD, (LPBYTE)&Value, sizeof(DWORD));

	_snwprintf_s(wcBuffer, COF(wcBuffer), L"\\Registry\\Machine\\System\\CurrentControlSet\\Services\\%s", SymbolicLink);
	KdInitUnicodeString(&usKey, wcBuffer);

	Status = pNtUnloadDriver(&usKey);

	if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"SYSTEM\\CurrentControlSet\\Services", 0, KEY_ALL_ACCESS, &hk) != ERROR_SUCCESS)
	{
		return 0;
	}

	if(SHDeleteKey(hk, SymbolicLink) != ERROR_SUCCESS)
	{
		Ret = 0;
	}

	RegCloseKey(hk); hk = 0;

    switch (GetSystemMetrics(SM_CLEANBOOT))
    {
    case 1:
        if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"SYSTEM\\CurrentControlSet\\Control\\SafeBoot\\Minimal", 0, KEY_ALL_ACCESS, &hk) != ERROR_SUCCESS)
        {
            _snwprintf_s(wcBuffer, COF(wcBuffer), L"%s.sys", SymbolicLink);
            SHDeleteKey(hk, wcBuffer);
            RegCloseKey(hk);
        }
        break;

    case 2:
        if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"SYSTEM\\CurrentControlSet\\Control\\SafeBoot\\Network", 0, KEY_ALL_ACCESS, &hk) != ERROR_SUCCESS)
        {
            _snwprintf_s(wcBuffer, COF(wcBuffer), L"%s.sys", SymbolicLink);
            SHDeleteKey(hk, wcBuffer);
            RegCloseKey(hk);
        }
        break;
    }

	return Ret;
}

ULONG SyscallNaked(ULONG Ioctl, KI_PACKET *KiPacket)
{
	UCHAR IoStatus[8];
	IO_INPUT_BUFFER IoBuffer;

	ZeroMemory(&IoBuffer, sizeof(IoBuffer));
	IoBuffer.Key = GetTickCount() + 'SIBA';
	IoBuffer.ControlCode[IoBuffer.Index] = Ioctl ^ IoBuffer.Key;
	IoBuffer.InputBuffer[IoBuffer.Index] = (PVOID)((ULONG_PTR)KiPacket ^ IoBuffer.Key);

	return pNtDeviceIoControlFile(DeviceHandle,
								 NULL,
								 NULL,
								 NULL,
								 &IoStatus,
								 CODE(CORE_IOCTL_INDEX),
								 NULL,
								 0,
								 &IoBuffer,
								 0);
}

BOOL Syscall(ULONG Ioctl, KI_PACKET *KiPacket)
{
	ULONG dwRet;
	IO_INPUT_BUFFER IoBuffer;

	ZeroMemory(&IoBuffer, sizeof(IoBuffer));
	IoBuffer.Key = GetTickCount() + 'SIBA';
	IoBuffer.ControlCode[IoBuffer.Index] = Ioctl ^ IoBuffer.Key;
	IoBuffer.InputBuffer[IoBuffer.Index] = (PVOID)((ULONG_PTR)KiPacket ^ IoBuffer.Key);

	return DeviceIoControl(DeviceHandle,
						   CODE(CORE_IOCTL_INDEX),
						   NULL,
						   0,
						   &IoBuffer,
						   0,
						   &dwRet,
						   NULL);
}

ULONG EnumerateProcesses(PPROCESS_ENTRY *Processes)
{
    KI_PACKET KiPacket;

    if (KiProcessList)
        VirtualFree(KiProcessList, 0, MEM_RELEASE);
    Syscall(IOCTL_ENUM_PROCESS, &KiPacket);
    *Processes = KiProcessList = KiPacket.Parameters.ProcessEnumerate.Processes;
    KiProcessCount = KiPacket.Parameters.ProcessEnumerate.Count;
	return KiProcessCount;
}

ULONG EnumerateThreads(PTHREAD_ENTRY *Threads, PVOID ProcessObject)
{
    KI_PACKET KiPacket;
	
    *Threads = NULL;
    KiPacket.Parameters.ThreadEnumerate.ProcessObject = ProcessObject;
    Syscall(IOCTL_ENUM_THREADS, &KiPacket);
    if (KiPacket.Parameters.ThreadEnumerate.Threads)
    {
        *Threads = new THREAD_ENTRY[KiPacket.Parameters.ThreadEnumerate.Count];
        RtlCopyMemory(*Threads, KiPacket.Parameters.ThreadEnumerate.Threads, sizeof(THREAD_ENTRY) * KiPacket.Parameters.ThreadEnumerate.Count);
	    VirtualFree(KiPacket.Parameters.ThreadEnumerate.Threads, 0, MEM_RELEASE);
    }
    return KiPacket.Parameters.ThreadEnumerate.Count;
}

ULONG EnumerateDlls(PVOID ProcessObject, PDLL_ENTRY *Dlls)
{
    KI_PACKET KiPacket;

    *Dlls = NULL;
    KiPacket.Parameters.DllEnumerate.ProcessObject = ProcessObject;
    Syscall(IOCTL_ENUM_DLL, &KiPacket);
    if (KiPacket.Parameters.DllEnumerate.Dlls)
    {
        *Dlls = new DLL_ENTRY[KiPacket.Parameters.DllEnumerate.Count];
        RtlCopyMemory(*Dlls, KiPacket.Parameters.DllEnumerate.Dlls, sizeof(DLL_ENTRY) * KiPacket.Parameters.DllEnumerate.Count);
	    VirtualFree(KiPacket.Parameters.DllEnumerate.Dlls, 0, MEM_RELEASE);
    }
    return KiPacket.Parameters.DllEnumerate.Count;
}

ULONG EnumerateDrivers(PDRIVER_ENTRY *Drivers)
{
    KI_PACKET KiPacket;
    PDRIVER_ENTRY DrvKrnl = NULL, DrvWin32 = NULL;

    *Drivers = NULL;
    Syscall(IOCTL_ENUM_DRIVER, &KiPacket);
    if (KiPacket.Parameters.DriversEnumerate.Drivers)
    {
        *Drivers = new DRIVER_ENTRY[KiPacket.Parameters.DriversEnumerate.Count];
        RtlCopyMemory(*Drivers, KiPacket.Parameters.DriversEnumerate.Drivers, sizeof(DRIVER_ENTRY) * KiPacket.Parameters.DriversEnumerate.Count);
	    VirtualFree(KiPacket.Parameters.DriversEnumerate.Drivers, 0, MEM_RELEASE);

        for (ULONG i = 0; i < KiPacket.Parameters.DriversEnumerate.Count; i++)
        {
            PDRIVER_ENTRY lpDrv = *Drivers;
            if (_wcsicmp(PathToFileName(lpDrv[i].ImagePath), CurrentKernelFileName) == 0)
            {
                DrvKrnl = &lpDrv[i];
            }
            else if (_wcsicmp(PathToFileName(lpDrv[i].ImagePath), L"win32k.sys") == 0)
            {
                DrvWin32 = &lpDrv[i];
            }
        }
        if (DrvKrnl && DrvWin32)
        {
            for (ULONG i = 0; i < KiPacket.Parameters.DriversEnumerate.Count; i++)
            {
                PDRIVER_ENTRY lpDrv = *Drivers;
                if (_wcsicmp(lpDrv[i].ImagePath, L"\\Filesystem\\Raw") == 0)
                {
                    lpDrv[i].ImageBase = DrvKrnl->ImageBase;
                    lpDrv[i].ImageSize = DrvKrnl->ImageSize;
                }
                else if (_wcsicmp(lpDrv[i].ImagePath, L"\\Driver\\WMIxWDM") == 0)
                {
                    lpDrv[i].ImageBase = DrvKrnl->ImageBase;
                    lpDrv[i].ImageSize = DrvKrnl->ImageSize;
                }
                else if (_wcsicmp(lpDrv[i].ImagePath, L"\\Driver\\PnpManager") == 0)
                {
                    lpDrv[i].ImageBase = DrvKrnl->ImageBase;
                    lpDrv[i].ImageSize = DrvKrnl->ImageSize;
                }
                else if (_wcsicmp(lpDrv[i].ImagePath, L"\\Driver\\ACPI_HAL") == 0)
                {
                    lpDrv[i].ImageBase = DrvKrnl->ImageBase;
                    lpDrv[i].ImageSize = DrvKrnl->ImageSize;
                }
                else if (_wcsicmp(lpDrv[i].ImagePath, L"\\Driver\\Win32k") == 0)
                {
                    lpDrv[i].ImageBase = DrvWin32->ImageBase;
                    lpDrv[i].ImageSize = DrvWin32->ImageSize;
                }
            }
        }
    }
    return KiPacket.Parameters.DriversEnumerate.Count;
}

ULONG EnumerateDevices(PVOID **Devices)
{
    KI_PACKET KiPacket;

    *Devices = NULL;
    Syscall(IOCTL_ENUM_DEVICES, &KiPacket);
    if (KiPacket.Parameters.DevicesEnumerate.DeviceObjects)
    {
        *Devices = new PVOID[KiPacket.Parameters.DevicesEnumerate.Count];
        RtlCopyMemory(*Devices, KiPacket.Parameters.DevicesEnumerate.DeviceObjects, sizeof(PVOID) * KiPacket.Parameters.DevicesEnumerate.Count);
	    VirtualFree(KiPacket.Parameters.DevicesEnumerate.DeviceObjects, 0, MEM_RELEASE);
    }
    return KiPacket.Parameters.DevicesEnumerate.Count;
}

ULONG EnumerateSsdt(PSDT_ENTRY *Ssdt)
{
    KI_PACKET KiPacket;

    *Ssdt = NULL;
    Syscall(IOCTL_ENUM_SSDT, &KiPacket);
    if (KiPacket.Parameters.SsdtEnumerate.Ssdt)
    {
        *Ssdt = new SDT_ENTRY[KiPacket.Parameters.SsdtEnumerate.Count];
        RtlCopyMemory(*Ssdt, KiPacket.Parameters.SsdtEnumerate.Ssdt, sizeof(SDT_ENTRY) * KiPacket.Parameters.SsdtEnumerate.Count);
	    VirtualFree(KiPacket.Parameters.SsdtEnumerate.Ssdt, 0, MEM_RELEASE);
    }
    return KiPacket.Parameters.SsdtEnumerate.Count;
}

ULONG EnumerateShadowSsdt(PSDT_ENTRY *ShadowSsdt)
{
    KI_PACKET KiPacket;

    *ShadowSsdt = NULL;
    Syscall(IOCTL_ENUM_SHADOW_SSDT, &KiPacket);
    if (KiPacket.Parameters.SsdtEnumerate.Ssdt)
    {
        *ShadowSsdt = new SDT_ENTRY[KiPacket.Parameters.SsdtEnumerate.Count];
        RtlCopyMemory(*ShadowSsdt, KiPacket.Parameters.SsdtEnumerate.Ssdt, sizeof(SDT_ENTRY) * KiPacket.Parameters.SsdtEnumerate.Count);
        VirtualFree(KiPacket.Parameters.SsdtEnumerate.Ssdt, 0, MEM_RELEASE);
    }
    return KiPacket.Parameters.SsdtEnumerate.Count;
}

VOID EnumerateInterrupts(UCHAR Cpu, PKIDT_ENTRY *Idt)
{
    KI_PACKET KiPacket;
    ULONG_PTR Affinity;

    *Idt = NULL;
    Affinity = SetThreadAffinityMask(GetCurrentThread(), (ULONG_PTR)(1 << Cpu));
    Syscall(IOCTL_ENUM_IDT, &KiPacket);
    SetThreadAffinityMask(GetCurrentThread(), Affinity);
    if (KiPacket.Parameters.InterruptEnumerate.InterruptEntries)
    {
        *Idt = new KIDT_ENTRY[256];
        RtlCopyMemory(*Idt, KiPacket.Parameters.InterruptEnumerate.InterruptEntries, sizeof(KIDT_ENTRY) * 256);
        VirtualFree(KiPacket.Parameters.InterruptEnumerate.InterruptEntries, 0, MEM_RELEASE);
    }
}

ULONG_PTR HookInterruptOffset(UCHAR Cpu, ULONG Index, ULONG_PTR Offset)
{
    KI_PACKET KiPacket;
    ULONG_PTR Affinity;

    Affinity = SetThreadAffinityMask(GetCurrentThread(), (ULONG_PTR)(1 << Cpu));
    KiPacket.Parameters.InterrupHook.Index = Index;
    KiPacket.Parameters.InterrupHook.Offset = Offset;
    Syscall(IOCTL_IDT_OFFSET, &KiPacket);
    SetThreadAffinityMask(GetCurrentThread(), Affinity);
    return KiPacket.Parameters.InterrupHook.Offset;
}

USHORT HookInterruptSelector(UCHAR Cpu, ULONG Index, USHORT Selector)
{
    KI_PACKET KiPacket;
    ULONG_PTR Affinity;

    Affinity = SetThreadAffinityMask(GetCurrentThread(), (ULONG_PTR)(1 << Cpu));
    KiPacket.Parameters.InterrupHook.Index = Index;
    KiPacket.Parameters.InterrupHook.Selector = Selector;
    Syscall(IOCTL_IDT_SELECTOR, &KiPacket);
    SetThreadAffinityMask(GetCurrentThread(), Affinity);
    return KiPacket.Parameters.InterrupHook.Selector;
}

ULONG EnumerateObjectTypes(POBJECT_TYPE_ENTRY *ObjectTypesList)
{
    KI_PACKET KiPacket;
    DWORD Count;
    POBJECT_TYPE_ENTRY List;

    *ObjectTypesList = NULL;
	if (Syscall(IOCTL_ENUM_OBJECT_TYPES, &KiPacket))
	{
        List = (POBJECT_TYPE_ENTRY)KiPacket.Parameters.Common.Parameter1;
        Count = KiPacket.Parameters.Common.Parameter2;
		*ObjectTypesList = new OBJECT_TYPE_ENTRY[Count];
		RtlCopyMemory(*ObjectTypesList, List, sizeof(OBJECT_TYPE_ENTRY) * Count);
		VirtualFree(List, 0, MEM_RELEASE);
		
	}
	return Count;
}

ULONG EnumerateKernelHooks(PWCHAR ImagePath, PHOOK_ENTRY *Hooks, ULONG Flags)
{
    KI_PACKET KiPacket;
	
    *Hooks = NULL;
    KiPacket.Parameters.ImageHooksEnumerate.Flags = Flags;
    KiPacket.Parameters.ImageHooksEnumerate.ImagePath = ImagePath;
	Syscall(IOCTL_ENUM_HOOKS, &KiPacket);
    if (KiPacket.Parameters.ImageHooksEnumerate.HookEntries)
    {
        *Hooks = new HOOK_ENTRY[KiPacket.Parameters.ImageHooksEnumerate.Count];
        RtlCopyMemory(*Hooks, KiPacket.Parameters.ImageHooksEnumerate.HookEntries, sizeof(HOOK_ENTRY) * KiPacket.Parameters.ImageHooksEnumerate.Count);
        VirtualFree(KiPacket.Parameters.ImageHooksEnumerate.HookEntries, 0, MEM_RELEASE);
    }
    return KiPacket.Parameters.ImageHooksEnumerate.Count;
}

ULONG EnumerateHandles(PHANDLE_ENTRY *Handle, PVOID ProcessObject)
{
    KI_PACKET KiPacket;
	
    *Handle = NULL;
    KiPacket.Parameters.HandlesEnumerate.ProcessObject = ProcessObject;
    Syscall(IOCTL_ENUM_HANDLES, &KiPacket);
    if (KiPacket.Parameters.HandlesEnumerate.HandleEntries)
    {
        *Handle = new HANDLE_ENTRY[KiPacket.Parameters.HandlesEnumerate.Count];
        RtlCopyMemory(*Handle, KiPacket.Parameters.HandlesEnumerate.HandleEntries, sizeof(HANDLE_ENTRY) * KiPacket.Parameters.HandlesEnumerate.Count);
	    VirtualFree(KiPacket.Parameters.HandlesEnumerate.HandleEntries, 0, MEM_RELEASE);
    }
    return KiPacket.Parameters.HandlesEnumerate.Count;
}

PDRIVER_ENTRY GettDriverInformation(PVOID DriverObject)
{
    KI_PACKET KiPacket;
    PDRIVER_ENTRY DriverInformation = new DRIVER_ENTRY;

    RtlZeroMemory(DriverInformation, sizeof(DRIVER_ENTRY));
    KiPacket.Parameters.DriversQueryInformation.DriverObject = DriverObject;
    KiPacket.Parameters.DriversQueryInformation.DriverInformation = DriverInformation;
    if (!Syscall(IOCTL_GET_DRIVER_INFO, &KiPacket))
    {
        delete DriverInformation;
        DriverInformation = NULL;
    }
    return DriverInformation;
}

PWCHAR GetObjectTypeName(PVOID Object)
{
    KI_PACKET KiPacket;
    PWCHAR ObjectTypeName = new WCHAR[MAX_PATH];

    RtlZeroMemory(ObjectTypeName, sizeof(WCHAR) * MAX_PATH);
    KiPacket.Parameters.ObjectQueryTypeName.Object = Object;
    KiPacket.Parameters.ObjectQueryTypeName.ObjectTypeName = ObjectTypeName;
    if (!Syscall(IOCTL_GET_OBJECT_TYPE, &KiPacket))
    {
        delete ObjectTypeName;
        ObjectTypeName = NULL;
    }
    return ObjectTypeName;
}

PWCHAR GetTypeName(PVOID Type)
{
    KI_PACKET KiPacket;
    PWCHAR ObjectTypeName = new WCHAR[MAX_PATH];

    RtlZeroMemory(ObjectTypeName, sizeof(WCHAR) * MAX_PATH);
    KiPacket.Parameters.Common.Parameter1 = (ULONG_PTR)Type;
    KiPacket.Parameters.Common.Parameter2 = (ULONG_PTR)ObjectTypeName;
    Syscall(IOCTL_GET_TYPE_NAME, &KiPacket);
    return ObjectTypeName;
}

PWCHAR GetObjectName(PVOID Object)
{
    KI_PACKET KiPacket;
    PWCHAR ObjectName = new WCHAR[MAX_PATH];

    RtlZeroMemory(ObjectName, sizeof(WCHAR) * MAX_PATH);
    KiPacket.Parameters.ObjectQueryName.Object = Object;
    KiPacket.Parameters.ObjectQueryName.ObjectName = ObjectName;
    if (!Syscall(IOCTL_GET_OBJECT_NAME, &KiPacket))
    {
        delete ObjectName;
        ObjectName = NULL;
    }
    return ObjectName;
}

BOOL KiReadVirtualMemory(PVOID ProcessObject, PVOID Address, PVOID Buffer, SIZE_T Size)
{
    KI_PACKET KiPacket;
    ULONG Nbr = 0;

    KiPacket.Parameters.VirtualRead.ProcessObject = ProcessObject;
    KiPacket.Parameters.VirtualRead.VirtualAddress = Address;
    KiPacket.Parameters.VirtualRead.Buffer = Buffer;
    KiPacket.Parameters.VirtualRead.Size = Size;
    KiPacket.Parameters.VirtualRead.NumberOfBytesRead = &Nbr;
    return Syscall(IOCTL_VM_READ, &KiPacket);
}

BOOL KiWriteVirtualMemory(PVOID ProcessObject, PVOID Address, PVOID Buffer, SIZE_T Size)
{
    KI_PACKET KiPacket;
    ULONG Nbw = 0;

    KiPacket.Parameters.VirtualWrite.ProcessObject = ProcessObject;
    KiPacket.Parameters.VirtualWrite.VirtualAddress = Address;
    KiPacket.Parameters.VirtualWrite.Buffer = Buffer;
    KiPacket.Parameters.VirtualWrite.Size = Size;
    KiPacket.Parameters.VirtualWrite.NumberOfBytesWritten = &Nbw;
    return Syscall(IOCTL_VM_WRITE, &KiPacket);
}

BOOL ReadPhysicalPages(PLARGE_INTEGER PhysicalAddress, PVOID Buffer, SIZE_T Size)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.PhysicalRead.PhysicalAddress = PhysicalAddress;
    KiPacket.Parameters.PhysicalRead.Buffer = Buffer;
    KiPacket.Parameters.PhysicalRead.Size = Size;
    return Syscall(IOCTL_PHYSICAL_PAGE_READ, &KiPacket);
}

BOOL WritePhysicalPages(PLARGE_INTEGER PhysicalAddress, PVOID Buffer, SIZE_T Size)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.PhysicalWrite.PhysicalAddress = PhysicalAddress;
    KiPacket.Parameters.PhysicalWrite.Buffer = Buffer;
    KiPacket.Parameters.PhysicalWrite.Size = Size;
    return Syscall(IOCTL_PHYSICAL_PAGE_WRITE, &KiPacket);
}

PVOID AllocateVirtualMemory(PVOID ProcessObject, SIZE_T Size)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.VirtualAlloc.ProcessObject = ProcessObject;
    KiPacket.Parameters.VirtualAlloc.Size = Size;
    Syscall(IOCTL_ALLOCATE_PROCESS_VM, &KiPacket);
    return KiPacket.Parameters.VirtualAlloc.Address;
}

VOID FreeVirtualMemory(PVOID ProcessObject, PVOID Address, SIZE_T Size)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.VirtualFree.ProcessObject = ProcessObject;
    KiPacket.Parameters.VirtualFree.Address = Address;
    KiPacket.Parameters.VirtualFree.Size = Size;
    Syscall(IOCTL_DEALLOCATE_PROCESS_VM, &KiPacket);
}

BOOL ProtectVirtualMemory(PVOID ProcessObject, PVOID Address, SIZE_T Size, ULONG NewProtection, PULONG OldProtection)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.VirtualProtect.ProcessObject = ProcessObject;
    KiPacket.Parameters.VirtualProtect.Address = Address;
    KiPacket.Parameters.VirtualProtect.Size = Size;
    KiPacket.Parameters.VirtualProtect.NewProtection = NewProtection;
    KiPacket.Parameters.VirtualProtect.OldProtection = OldProtection;
    return Syscall(IOCTL_PROTECT_PROCESS_VM, &KiPacket);
}

BOOL QueryVirtualMemory(PVOID ProcessObject, PVOID Address, SIZE_T Size, PMEMORY_BASIC_INFORMATION MemoryBasicInformation)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.VirtualQuery.ProcessObject = ProcessObject;
    KiPacket.Parameters.VirtualQuery.Address = Address;
    KiPacket.Parameters.VirtualQuery.Size = Size;
    KiPacket.Parameters.VirtualQuery.MemoryBasicInformation = MemoryBasicInformation;
    return Syscall(IOCTL_QUERY_PROCESS_VM, &KiPacket);
}

BOOL UnmapSection(PVOID ProcessObject, PVOID SectionBase)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.SectionUnmap.ProcessObject = ProcessObject;
    KiPacket.Parameters.SectionUnmap.SectionBase = SectionBase;
    return Syscall(IOCTL_UNMAP_SECTION, &KiPacket);
}

HANDLE GetProcessHandle(PVOID ProcessObject)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.ProcessOpen.ProcessObject = ProcessObject;
    KiPacket.Parameters.ProcessOpen.ProcessId = 0;
    Syscall(IOCTL_PROCESS_OPEN, &KiPacket);
    return KiPacket.Parameters.ProcessOpen.Handle;
}

HANDLE GetProcessHandleById(ULONG ProcessId)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.ProcessOpen.ProcessObject = NULL;
    KiPacket.Parameters.ProcessOpen.ProcessId = ProcessId;
    Syscall(IOCTL_PROCESS_OPEN, &KiPacket);
    return KiPacket.Parameters.ProcessOpen.Handle;
}

BOOL ProcessKill(PVOID ProcessObject, BOOL ForceKill)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.ProcessKill.ProcessObject = ProcessObject;
    KiPacket.Parameters.ProcessKill.ForceKill = ForceKill;
    return Syscall(IOCTL_PROCESS_KILL, &KiPacket);
}

BOOL ProcessSuspend(PVOID ProcessObject)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.ProcessSuspend.ProcessObject = ProcessObject;
    return Syscall(IOCTL_PROCESS_SUSPEND, &KiPacket);
}

BOOL ProcessResume(PVOID ProcessObject, BOOL ForceResume)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.ProcessResume.ProcessObject = ProcessObject;
    KiPacket.Parameters.ProcessResume.ForceResume = ForceResume;
    return Syscall(IOCTL_PROCESS_RESUME, &KiPacket);
}

VOID GetProcessInformation(PVOID ProcessObject, PPROCESS_ENTRY Process)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.ProcessQueryInformation.ProcessObject = ProcessObject;
    KiPacket.Parameters.ProcessQueryInformation.Process = Process;
    Syscall(IOCTL_GET_PROCESS_INFO, &KiPacket);
}

HANDLE GetThreadHandle(PVOID ThreadObject)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.ThreadOpen.ThreadObject = ThreadObject;
    KiPacket.Parameters.ThreadOpen.ThreadId = 0;
    Syscall(IOCTL_THREAD_OPEN, &KiPacket);
    return KiPacket.Parameters.ThreadOpen.Handle;
}

HANDLE GetThreadHandleById(ULONG ThreadId)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.ThreadOpen.ThreadObject = NULL;
    KiPacket.Parameters.ThreadOpen.ThreadId = ThreadId;
    Syscall(IOCTL_THREAD_OPEN, &KiPacket);
    return KiPacket.Parameters.ThreadOpen.Handle;
}

BOOL ThreadKill(PVOID ThreadObject)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.ThreadKill.ThreadObject = ThreadObject;
    return Syscall(IOCTL_THREAD_KILL, &KiPacket);
}

BOOL ThreadCaptureStack(PVOID ThreadObject, PCONTEXT Context)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.ThreadCaptureStack.ThreadObject = ThreadObject;
    KiPacket.Parameters.ThreadCaptureStack.Context = Context;
    return Syscall(IOCTL_ENUM_THREAD_TRACE, &KiPacket);
}

BOOL ThreadSuspend(PVOID ThreadObject)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.ThreadSuspend.ThreadObject = ThreadObject;
    return Syscall(IOCTL_THREAD_SUSPEND, &KiPacket);
}

BOOL ThreadResume(PVOID ThreadObject, BOOL ForceResume)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.ThreadResume.ThreadObject = ThreadObject;
    KiPacket.Parameters.ThreadResume.ForceResume = ForceResume;
    return Syscall(IOCTL_THREAD_RESUME, &KiPacket);
}

VOID GetThreadProcessInformation(PVOID ThreadObject, PPROCESS_ENTRY Process, PTHREAD_ENTRY Thread)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.ThreadQueryInformation.ThreadObject = ThreadObject;
    KiPacket.Parameters.ThreadQueryInformation.Process = Process;
    KiPacket.Parameters.ThreadQueryInformation.Thread = Thread;
    Syscall(IOCTL_THREAD_TO_PROCESS, &KiPacket);
}

BOOL CloseProcessHandle(PVOID ProcessObject, HANDLE Handle)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.CloseHandle.ProcessObject = ProcessObject;
    KiPacket.Parameters.CloseHandle.Handle = Handle;
    return Syscall(IOCTL_CLOSE_HANDLE, &KiPacket);
}

BOOL FileDelete(PWCHAR FilePath, BOOL ForceDelete)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.FileDelete.FilePath = FilePath;
    KiPacket.Parameters.FileDelete.ForceDelete = ForceDelete;
    return Syscall(IOCTL_DELETE_FILE, &KiPacket);
}

BOOL FileCopy(PWCHAR SourceFilePath, PWCHAR DestinationFilePath)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.FileCopy.SourceFilePath = SourceFilePath;
    KiPacket.Parameters.FileCopy.DestinationFilePath = DestinationFilePath;
    return Syscall(IOCTL_COPY_FILE, &KiPacket);
}

BOOL SendIoPacket(PKD_IO_PACKET IoPacket)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.IoPacket.Packet = *IoPacket;
    return Syscall(IOCTL_IO_PACKET, &KiPacket);
}


BOOL GetNtdllFunctions(VOID)
{
    HMODULE hNtdll;

    hNtdll = GetModuleHandle(L"ntdll.dll");
    if (hNtdll)
    {
        *(FARPROC *)&pNtQuerySystemInformation = GetProcAddress(hNtdll, "NtQuerySystemInformation");
        if (pNtQuerySystemInformation == NULL)
            return FALSE;

        *(FARPROC *)&pNtLoadDriver = GetProcAddress(hNtdll, "NtLoadDriver");
        if (pNtLoadDriver == NULL)
            return FALSE;

        *(FARPROC *)&pNtUnloadDriver = GetProcAddress(hNtdll, "NtUnloadDriver");
        if (pNtUnloadDriver == NULL)
            return FALSE;

        *(FARPROC *)&pNtDeviceIoControlFile = GetProcAddress(hNtdll, "NtDeviceIoControlFile");
        if (pNtDeviceIoControlFile == NULL)
            return FALSE;
    }
    else
    {
        return FALSE;
    }

    return TRUE;
}

LONG KeInitialize(PWCHAR lpDeviceName, PWCHAR lpDriverPath, BOOL DbgMode)
{
	ULONG Result;
	WCHAR SymbolicLink[256];
	KI_PACKET KiPacket;
    OSVERSIONINFOEXW VersionInfo;


	wcsncpy(DriverPath, lpDriverPath, COF(DriverPath));
	wcsncpy(DeviceName, lpDeviceName, COF(DeviceName));
	NtBuildNumber = GetNtBuildNumber();
    VersionInfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEXW);
    GetVersionEx((LPOSVERSIONINFOW)&VersionInfo);
	CaptureDbgMode = DbgMode;

    if (VersionInfo.dwBuildNumber != NtBuildNumber)
        MessageBox(NULL, L"NtBuildNumber seems to be hacked", L"Kernel Detective", MB_OK | MB_ICONEXCLAMATION);

    if (!GetNtdllFunctions())
    {
        ErrorMsg = L"Cannot locate native system calls addresses";
        return INIT_UNKNOWN_ERROR;
    }

	switch (NtBuildNumber)
	{
	case 2600: // XP sp0-3
		KiSsdtLimit = 284;
        if (VersionInfo.wServicePackMajor)
        {
		    KiShadowSsdtLimit = 667;
		    KiShadowSsdtStrings = ShadowServiceTableXp;
        }
        else
        {
            KiShadowSsdtLimit = 666;
		    KiShadowSsdtStrings = ShadowServiceTableXpServicePack0;
        }
		break;

	case 6000: // vista sp0
		KiSsdtLimit = 398;
		KiShadowSsdtLimit = 772;
		KiShadowSsdtStrings = ShadowServiceTableVista;
		break;

	case 6001: // vista sp1
		KiSsdtLimit = 391;
		KiShadowSsdtLimit = 772;
		KiShadowSsdtStrings = ShadowServiceTableVista;
		break;

	case 6002: // vista sp2
		KiSsdtLimit = 391;
		KiShadowSsdtLimit = 772;
		KiShadowSsdtStrings = ShadowServiceTableVista;
		break;

	case 7600: // seven sp0
		KiSsdtLimit = 401;
		KiShadowSsdtLimit = 825;
		KiShadowSsdtStrings = ShadowServiceTableSeven;
		break;

    case 7601: // seven sp1
		KiSsdtLimit = 401;
		KiShadowSsdtLimit = 825;
		KiShadowSsdtStrings = ShadowServiceTableSeven;
		break;

	default:
		ErrorMsg = L"Unsupported Operating System";
		return INIT_UNSUPPORTED_OS;
	}

	UninstallDriver(lpDriverPath, lpDeviceName);
	if (!InstallDriver(lpDriverPath, lpDeviceName))
	{
		ErrorMsg = L"Unable to install the system component";
        UninstallDriver(lpDriverPath, lpDeviceName);
        return INIT_CANNOT_LOAD_DRIVER;
	}

	

	_snwprintf(SymbolicLink, COF(SymbolicLink), L"\\\\.\\%s", lpDeviceName);
	DeviceHandle = CreateFile(SymbolicLink,
							  GENERIC_READ | GENERIC_WRITE,
							  0,
							  NULL, 
							  OPEN_EXISTING, 
							  0,
							  NULL);

	if (DeviceHandle == INVALID_HANDLE_VALUE)
	{
		ErrorMsg = L"Unable to open the system component";
        UninstallDriver(lpDriverPath, lpDeviceName);
		return INIT_CANNOT_LOAD_DRIVER;
	}

	KiSsdtStrings = GetSsdtStrings();
	KiSsdt = (ULONG_PTR *)calloc(KiSsdtLimit, sizeof(ULONG_PTR));
	KiShadowSsdt = (ULONG_PTR *)calloc(KiShadowSsdtLimit, sizeof(ULONG_PTR));

	GetWindowsDirectoryW(CurrentSystemroot, MAX_PATH);
    KiPacket.Parameters.Initialize.CaptureDbgMode = CaptureDbgMode;
	KiPacket.Parameters.Initialize.InterruptServiceRoutines = InterruptServiceRoutines;
	KiPacket.Parameters.Initialize.KernelFileName = CurrentKernelFileName;
	KiPacket.Parameters.Initialize.NtBuildNumber = NtBuildNumber;
	KiPacket.Parameters.Initialize.ShadowSsdt = KiShadowSsdt;
	KiPacket.Parameters.Initialize.Ssdt = KiSsdt;
	KiPacket.Parameters.Initialize.SystemrootPath = CurrentSystemroot;
    *(FARPROC *)&CsrGetProcessId = GetProcAddress(GetModuleHandle(L"ntdll.dll"), "CsrGetProcessId");
	if (CsrGetProcessId)
        KiPacket.Parameters.Initialize.CsrProcessId = CsrGetProcessId();
    else
        KiPacket.Parameters.Initialize.CsrProcessId = 0;
    Result = SyscallNaked(IOCTL_INITIALIZE, &KiPacket);

	switch (Result)
	{
	case INIT_SUCCESS:
		break;

	case INIT_UNSUPPORTED_OS:
		ErrorMsg = L"Running Operating System is not supported";
		KeCleanup();
		return INIT_UNSUPPORTED_OS;

	case INIT_CANNOT_LOCATE_ITEMS:
		ErrorMsg = L"Kernel Detective cannot find some essential system components";
		KeCleanup();
		return INIT_CANNOT_LOCATE_ITEMS;

	case INIT_CANNOT_LOCATE_KERNEL:
		ErrorMsg = L"Kernel Detective cannot find the system kernel file";
		KeCleanup();
		return INIT_CANNOT_LOCATE_KERNEL;

	case INIT_CANNOT_LOAD_KERNEL:
		ErrorMsg = L"Kernel Detective cannot load the system kernel file";
		KeCleanup();
		return INIT_CANNOT_LOAD_KERNEL;

	default:
		ErrorMsg = L"Unknown error while initializing the system component";
		KeCleanup();
        return INIT_UNKNOWN_ERROR;
	}

    FullKernelModulesPath[0] = new WCHAR [MAX_PATH];
    _snwprintf(FullKernelModulesPath[0], MAX_PATH, L"\\Systemroot\\system32\\%s", CurrentKernelFileName);
    GetProcessInformation(KiPacket.Parameters.Initialize.KiKdProcess, &KiKdProcess);
    GetProcessInformation(KiPacket.Parameters.Initialize.KiCsrProcess, &KiCsrProcess);
    GetProcessInformation(KiPacket.Parameters.Initialize.KiSystemProcess, &KiSystemProcess);
    GetProcessInformation(KiPacket.Parameters.Initialize.KiIdleProcess, &KiIdleProcess);

	return INIT_SUCCESS;
}

VOID KeCleanup(VOID)
{
	ULONG Index;

    if (DeviceHandle != 0 && DeviceHandle != INVALID_HANDLE_VALUE)
	    CloseHandle(DeviceHandle);
	UninstallDriver(DriverPath, DeviceName);

	if (KiSsdt) 
        free(KiSsdt);
	if (KiShadowSsdt)
        free(KiShadowSsdt);
    if (KiSsdtStrings)
    {
	    for (Index = 0; Index < KiSsdtLimit; Index++) 
        {
		    free(KiSsdtStrings[Index]);
	    }
    }
	if (KiSsdtStrings) 
        free(KiSsdtStrings);
}


PVOID UpdateCommonBuffer(ULONG_PTR Address, SIZE_T Size)
{
	if (KiReadBuffer) 
        delete[] KiReadBuffer;

    KiReadBuffer = new UCHAR[alignNumber(Size, 16)];
	KiReadAddress = (PVOID)Address;
	KiReadSize = alignNumber(Size, 16);
	return KiReadBuffer;
}

PVOID GetCommonReadAddress()
{
    return KiReadAddress;
}

SIZE_T GetCommonReadSize()
{
    return KiReadSize;
}

PVOID GetCommonReadBuffer()
{
    return KiReadBuffer;
}

ULONG_PTR GetProcessEntryPoint(PVOID ProcessObject, ULONG_PTR ImageBase)
{
	ULONG_PTR NtHeaderOffset = NULL;
	ULONG_PTR EntryPoint = NULL;

	if (KiReadVirtualMemory(ProcessObject, (PVOID)(ImageBase + 0x3c), &NtHeaderOffset, sizeof(NtHeaderOffset)))
	{
		KiReadVirtualMemory(ProcessObject, (PVOID)(ImageBase + NtHeaderOffset + 0x28), &EntryPoint, sizeof(EntryPoint));
		return (EntryPoint + ImageBase);
	}
	return NULL;
}

VOID 
KdInitUnicodeString (
    OUT PUNICODE_STRING DestinationString,
    IN PCWSTR SourceString OPTIONAL
    )
{

    SIZE_T Length;

    DestinationString->MaximumLength = 0;
    DestinationString->Length = 0;
    DestinationString->Buffer = (PWSTR)SourceString;
    if (SourceString != NULL) {
        Length = wcslen(SourceString) * sizeof(WCHAR);

        if(Length >= (sizeof(WCHAR) * (0xffff/sizeof(WCHAR)))) {
            Length = (sizeof(WCHAR) * (0xffff/sizeof(WCHAR))) - sizeof(UNICODE_NULL);
        }

        DestinationString->Length = (USHORT)Length;
        DestinationString->MaximumLength = (USHORT)(Length + sizeof(UNICODE_NULL));
    }

    return;
}


ULONG EnumerateUserModeDrivers(PDRIVER_ENTRY *Drivers)
{
    PDRIVER_ENTRY lpDrivers;
    PVOID *lpDriversBase;
    ULONG cbNeeded, Count;

    EnumDeviceDrivers((PVOID *)&cbNeeded, 0, &cbNeeded);
    Count = cbNeeded / sizeof(PVOID);
    lpDriversBase = new PVOID [Count];
    lpDrivers = new DRIVER_ENTRY [Count];
    EnumDeviceDrivers(lpDriversBase, cbNeeded, &cbNeeded);

    for (ULONG i = 0; i < Count; i++)
    {
        lpDrivers[i].ImageBase = lpDriversBase[i];
        GetDeviceDriverBaseName(lpDriversBase[i], lpDrivers[i].ImagePath, COF(lpDrivers[i].ImagePath));
    }

    delete[] lpDriversBase;
    *Drivers = lpDrivers;
    return Count;
}