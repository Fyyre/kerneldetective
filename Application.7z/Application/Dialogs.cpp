#include "Kernel Detective.h"
#include "Extras.h"
#include <atlstr.h>
#include <vector>
#include "pdk.h"

BOOL CALLBACK DlgAddress(HWND hWin,UINT uMsg,WPARAM wParam,LPARAM lParam);




HWND GlobalHandles[11];
HWND PrevSelTab;
CListView *CurrentList;
ULONG get_address_value;
HACCEL hAccelerator;
HHOOK g_hook;
HGDIOBJ gFontHandle;
ULONG PluginsMenuCount;

typedef struct _PLUGIN_DATA {
    ULONG            Index;
    KD_MENU_CALLBACK Callback;
} PLUGIN_DATA, *PPLUGIN_DATA;

std::vector<PLUGIN_DATA> *PluginMenuData;

PWCHAR tab_string[] = {
	L"Processes",
	L"Threads",
	L"Libraries",
	L"Handles",
	L"Drivers",
	L"Disassembler",
	L"Debug View",
	L"System Service Descriptor Table",
	L"System Service Descriptor Table Shadow",
	L"Interrupt Descriptor Table",
	L"Kernel Modifications"
};
      
PWCHAR icon_index[] = {
	MAKEINTRESOURCE(IDI_ICON2),
	MAKEINTRESOURCE(IDI_ICON12),
	MAKEINTRESOURCE(IDI_ICON3),
	MAKEINTRESOURCE(IDI_ICON4),
	MAKEINTRESOURCE(IDI_ICON5),
	MAKEINTRESOURCE(IDI_ICON6),
	MAKEINTRESOURCE(IDI_ICON7),
	MAKEINTRESOURCE(IDI_ICON8),
	MAKEINTRESOURCE(IDI_ICON9),
	MAKEINTRESOURCE(IDI_ICON10),
	MAKEINTRESOURCE(IDI_ICON11)
};

PWCHAR dlg_index[] = {
	MAKEINTRESOURCE(DLG_PROCESS),
	MAKEINTRESOURCE(DLG_THREAD),
	MAKEINTRESOURCE(DLG_MODULE),
	MAKEINTRESOURCE(DLG_HANDLE),
	MAKEINTRESOURCE(DLG_DRIVER),
	MAKEINTRESOURCE(DLG_DISASM),
	MAKEINTRESOURCE(DLG_DBGMSG),
	MAKEINTRESOURCE(DLG_SSDT),
	MAKEINTRESOURCE(DLG_SHADOWSSDT),
	MAKEINTRESOURCE(DLG_IDT),
	MAKEINTRESOURCE(DLG_UNHOOK)
};

DLGPROC dlg_proc[] = {
	DlgProcess,
	DlgThread,
	DlgModule,
	DlgHandle,
	DlgDriver,
	DlgDisasm,
	DlgDbgMsg,
	DlgSSDT,
	DlgShadowSSDT,
	DlgIDT,
	DlgUnhook
};
	
void SwitchTab()
{
	ShowWindow(PrevSelTab,SW_HIDE);
	HWND handle = GlobalHandles[SendMessage(hTab,TCM_GETCURSEL,NULL,NULL)];
	ShowWindow(handle,SW_SHOWDEFAULT);
	SetFocus(CurrentList->getHwnd());
	PrevSelTab = handle;
}


BOOL GetAddress(DWORD init, PDWORD plc)
{
	if (DialogBoxParam(hInstance, MAKEINTRESOURCE(DLG_ADDRESS), gWin, DlgAddress, init))
	{
		*plc = get_address_value;
		return TRUE;
	}
	return FALSE;
}


PWCHAR GetSetFilePath(HWND Owner, PWCHAR Filter, BOOL Get)
{
	OPENFILENAME ofn;

	RtlZeroMemory(&ofn, sizeof(OPENFILENAME));
	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.hwndOwner = Owner;
	ofn.lpstrFilter = Filter;
	ofn.Flags = OFN_LONGNAMES | OFN_NONETWORKBUTTON | OFN_FORCESHOWHIDDEN;
	ofn.nMaxFile = MAX_PATH;
	ofn.lpstrFile = new WCHAR [MAX_PATH];
	ofn.lpstrFile[0] = '\0';
	ofn.lpstrTitle = L"Choose File ...";
	if (Get)
	{
        ofn.Flags |= OFN_NOTESTFILECREATE;
		if (!GetOpenFileName(&ofn))
		{
			delete[] ofn.lpstrFile;
			return NULL;
		}
	}
	else
	{
		if (!GetSaveFileName(&ofn))
		{
			delete[] ofn.lpstrFile;
			return NULL;
		}
	}
	return ofn.lpstrFile;
}


BOOL CALLBACK DlgSetFile(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static WCHAR *Title;
	WCHAR *FilePath;

	switch (uMsg)
	{
	case WM_INITDIALOG:
		Title = (WCHAR *)lParam;
		SetWindowText(hWnd, Title);
		SetDlgItemText(hWnd, GETFILE_PATH, GetSetFilePath(hWnd, L"All Files(*.*)\0*.*\0\0", FALSE));
		break;
	case WM_COMMAND:
		switch (wParam)
		{
		case GETFILE_PICK:
			SetDlgItemText(hWnd, GETFILE_PATH, GetSetFilePath(hWnd, L"All Files(*.*)\0*.*\0\0", FALSE));
			break;
		case GETFILE_OK:
			FilePath = new WCHAR [MAX_PATH];
			GetDlgItemText(hWnd, GETFILE_PATH, FilePath, MAX_PATH);
			EndDialog(hWnd, (INT_PTR)FilePath);
			break;
		case GETFILE_EXIT:
			EndDialog(hWnd, NULL);
			break;
		default:
			return FALSE;
		}
		break;
	case WM_CLOSE:
		EndDialog(hWnd, NULL);
		break;
	default:
		return FALSE;
	}
	return TRUE;
}


BOOL CALLBACK DlgGetFile(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static WCHAR *Title;
	WCHAR *FilePath;

	switch (uMsg)
	{
	case WM_INITDIALOG:
		Title = (WCHAR *)lParam;
		SetWindowText(hWnd, Title);
		SetDlgItemText(hWnd, GETFILE_PATH, GetSetFilePath(hWnd, L"All Files(*.*)\0*.*\0\0", TRUE));
		break;
	case WM_COMMAND:
		switch (wParam)
		{
		case GETFILE_PICK:
			SetDlgItemText(hWnd, GETFILE_PATH, GetSetFilePath(hWnd, L"All Files(*.*)\0*.*\0\0", TRUE));
			break;
		case GETFILE_OK:
			FilePath = new WCHAR [MAX_PATH];
			GetDlgItemText(hWnd, GETFILE_PATH, FilePath, MAX_PATH);
			EndDialog(hWnd, (INT_PTR)FilePath);
			break;
		case GETFILE_EXIT:
			EndDialog(hWnd, NULL);
			break;
		default:
			return FALSE;
		}
		break;
	case WM_CLOSE:
		EndDialog(hWnd, NULL);
		break;
	default:
		return FALSE;
	}
	return TRUE;
}


BOOL CALLBACK DlgGetModuleName(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static WCHAR *Title;
	WCHAR *FilePath;

	switch (uMsg)
	{
	case WM_INITDIALOG:
		Title = (WCHAR *)lParam;
		SetWindowText(hWnd, Title);
		break;
	case WM_COMMAND:
		switch (wParam)
		{
		case GETFILE_OK:
			FilePath = new WCHAR [MAX_PATH];
			GetDlgItemText(hWnd, GETFILE_PATH, FilePath, MAX_PATH);
			EndDialog(hWnd, (INT_PTR)FilePath);
			break;
		case GETFILE_EXIT:
			EndDialog(hWnd, NULL);
			break;
		default:
			return FALSE;
		}
		break;
	case WM_CLOSE:
		EndDialog(hWnd, NULL);
		break;
	default:
		return FALSE;
	}
	return TRUE;
}

ULONG Stop;

typedef struct _DUMPTHREAD {
	PWCHAR FilePath;
	HWND hWnd;
    HWND hProgressbar;
} DUMPTHREAD, *PDUMPTHREAD;

DUMPTHREAD DumpThreadParameters;

DWORD WINAPI DumpThread(PVOID lpThreadParameter)
{
    BOOL Result = TRUE;
	ULONG Nbw;
    HANDLE hFile;
    ULONG NumberOfPhysicalPages;
    BYTE Buffer[4096];

    Stop = FALSE;
    NumberOfPhysicalPages = KdGetNumberOfPhysicalPages();
    SendMessage(DumpThreadParameters.hProgressbar, PBM_SETRANGE32, 0, NumberOfPhysicalPages);
    SendMessage(DumpThreadParameters.hProgressbar, PBM_SETSTEP, 1, NULL);
    SetThreadPriority(NtCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
    hFile = CreateFile(DumpThreadParameters.FilePath,
                       GENERIC_WRITE,
                       FILE_SHARE_READ,
                       NULL,
                       CREATE_ALWAYS,
                       FILE_ATTRIBUTE_NORMAL,
                       NULL);

    if (hFile != INVALID_HANDLE_VALUE)
    {
        for (ULONG nPage = 0; nPage < NumberOfPhysicalPages; nPage++)
        {
            LARGE_INTEGER PhysicalAddress;
            if (Stop)
            {
                Result = FALSE;
                break;
            }

            PhysicalAddress.QuadPart = nPage * PAGE_SIZE;
            ReadPhysicalPages(&PhysicalAddress, Buffer, PAGE_SIZE);
            WriteFile(hFile, Buffer, sizeof(Buffer), &Nbw, NULL);
            SendMessage(DumpThreadParameters.hProgressbar, PBM_STEPIT, NULL, NULL);
        }
    }
    else
    {
        Result = FALSE;
    }


    CloseHandle(hFile);
	if (Result)
	{
		MessageBox(gWin, L"Physical memory dumped successfully", AppName, MB_OK | MB_ICONINFORMATION);
	}
	else
	{
		MessageBox(gWin, L"Cannot dump all or some pages of physical memory", AppName, MB_OK | MB_ICONERROR);
	}
	SendMessage(DumpThreadParameters.hWnd, WM_CLOSE, NULL, NULL);
	delete[] DumpThreadParameters.FilePath;
    return (Result ? EXIT_SUCCESS : EXIT_FAILURE);
}


BOOL CALLBACK DlgDumpPhysicalMemory(HWND hWin, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
    {
	case WM_INITDIALOG:
		{
			WCHAR *FilePath = (WCHAR *)DialogBoxParam(hInstance, MAKEINTRESOURCE(DLG_GETFILE), hWin, DlgSetFile, (LPARAM)L"Choose dump file ...");
			if (FilePath)
			{
				DWORD ThreadId;

				DumpThreadParameters.FilePath = FilePath;
				DumpThreadParameters.hWnd = hWin;
                DumpThreadParameters.hProgressbar = GetDlgItem(hWin, IDC_PROGRESS);
				HANDLE hThread = CreateThread(NULL, 0L, DumpThread, NULL, 0, &ThreadId);
				CloseHandle(hThread);
			}
			else
			{
				EndDialog(hWin, EXIT_FAILURE);
			}
			return FALSE;
		}
	case WM_COMMAND:
		if (wParam == ID_CANCEL)
		{
			Stop = TRUE;
			EndDialog(hWin, EXIT_FAILURE);
			break;
		}
		break;
	case WM_CLOSE:
		EndDialog(hWin, EXIT_SUCCESS);
		break;
	default:
		return FALSE;
	}
	return TRUE;
}


BOOL CALLBACK DlgAddress(HWND hWin,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	WCHAR	Temp[BUFFER_LEN];
	WCHAR*	stopstring;
	static HBRUSH backclr = 0;

    switch (uMsg)
    {
    case WM_INITDIALOG :
		{
			backclr = CreateSolidBrush(settings.clr_back);
			_snwprintf_s(Temp, COF(Temp), _TRUNCATE, L"0x%p", lParam);
			SetDlgItemText(hWin,ADDRESS_START,Temp);
			SetFocus(GetDlgItem(hWin, ADDRESS_START));
			SendDlgItemMessage(hWin, ADDRESS_START, EM_SETSEL, 0, -1);
			SubclassEditBox(GetDlgItem(hWin, ADDRESS_START));
			return FALSE;
		};
	case WM_DESTROY:
		{
			DeleteObject(backclr);
			break;
		};
    case	WM_COMMAND :
		{
			switch	(wParam)
			{
			case	ADDRESS_OK: 
				{
					GetDlgItemText(hWin,ADDRESS_START, Temp,11);
					get_address_value = _tcstoul(Temp, &stopstring, 16);
					if	(stopstring[0])
						{Err(L"Invalid Address, make sure you write it in hex format !");break;}
					EndDialog(hWin,TRUE);
					break;
				};
			case	ADDRESS_EXIT:
				{
					get_address_value = 0;
					EndDialog(hWin,FALSE);
					break;
				};
			};
			break;
		};
	case	WM_CTLCOLOREDIT:
		{
			if	((HWND)lParam == GetDlgItem(hWin,ADDRESS_START))
			{
				SetBkMode((HDC)wParam,TRANSPARENT);
				SetTextColor((HDC)wParam,settings.clr_front);
				return (BOOL)backclr;
			};
			return FALSE;
		};
	default:
		return FALSE;
    };
    return TRUE;
};


LRESULT Listview_handler(LPNMLVCUSTOMDRAW lplvcd, PWCHAR *warnlist, int count, int status_pos, CListView *Listv)
{
    WCHAR Temp[BUFFER_LEN] = L"";
	LVCOLUMN lvc;

    switch(lplvcd->nmcd.dwDrawStage) 
    {
	case CDDS_PREPAINT :
		return CDRF_NOTIFYITEMDRAW;

	case CDDS_ITEMPREPAINT: //Before an item is drawn
		lplvcd->clrText   = settings.clr_front;
		Listv->getText(lplvcd->nmcd.dwItemSpec, status_pos, Temp, sizeof(Temp));
		for (int i = 0; i < count; i++)
		{
			if (!_tcscmp(warnlist[i], Temp))
			{ 
				if (!settings.igrone_warn_txt) 
				{
					lplvcd->clrText = settings.clr_warn_txt;
				}
				if (!settings.igrone_warn_bk)
				{
					lplvcd->clrTextBk = settings.clr_warn_bk;			
				}
				return CDRF_NEWFONT;
			}
		}

        if (((int)lplvcd->nmcd.dwItemSpec%2)==0)
		{
			lplvcd->clrTextBk = settings.clr_back;
		}
		else
		{
			lplvcd->clrTextBk = settings.clr_back2;
		}
		return CDRF_NEWFONT | CDRF_NOTIFYITEMDRAW;
	case CDDS_ITEMPREPAINT | CDDS_SUBITEM:
		if (lplvcd->iSubItem == 2) 
		{
			//
			// disassembler highlighting
			//
			lvc.mask = LVCF_TEXT;
			lvc.cchTextMax = sizeof(Temp);
			lvc.pszText = Temp;
			ListView_GetColumn(Listv->getHwnd(), lplvcd->iSubItem, &lvc);
			if (!settings.igrone_disasm && !_tcscmp(L"Disassembly", Temp))
			{
				Listv->getText(lplvcd->nmcd.dwItemSpec, lplvcd->iSubItem, Temp, sizeof(Temp));
				if (!_tcsncmp(L"call", Temp, 4))
				{
					SelectObject(lplvcd->nmcd.hdc, settings.hFontCall);
					lplvcd->clrText = settings.clr_disasm_call;
					return CDRF_NEWFONT;
				}
				else if (!_tcsncmp(L"ret", Temp, 3))
				{
					lplvcd->clrText = settings.clr_disasm_ret;
					return CDRF_NEWFONT;
				}
				else if (!_tcsncmp(L"jmp", Temp, 3))
				{
					lplvcd->clrText = settings.clr_disasm_jmp;
					return CDRF_NEWFONT;
				}
				else if (!_tcsncmp(L"j", Temp, 1))
				{
					lplvcd->clrText = settings.clr_disasm_jcc;
					return CDRF_NEWFONT;
				}
			}
		}
		else
		{
			SelectObject(lplvcd->nmcd.hdc, gFontHandle);
			lplvcd->clrText   = settings.clr_front;
			if (((int)lplvcd->nmcd.dwItemSpec%2)==0)
			{
				lplvcd->clrTextBk = settings.clr_back;
			}
			else
			{
				lplvcd->clrTextBk = settings.clr_back2;
			}
			return CDRF_NEWFONT;
		}
		break;
	}
    return CDRF_DODEFAULT;
}

WCHAR ThxList[] = 
    L"a_d_13\r\n"
    L"Alex\r\n"
    L"Deroko\r\n"
    L"EP_X0FF\r\n"
    L"Meriadoc\r\n"
    L"STRELiTZIA\r\n"
    L"Thug4Life\r\n"
    L"USForce\r\n"
    L"wj32\r\n"
    L"yAtEs\r\n"
    L"----------\r\n"
    L"Forgive me if I forgot someone :)";


BOOL CALLBACK DlgAbout(HWND hWin, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_COMMAND:
		switch (wParam)
		{
		case IDOK:
			EndDialog(hWin, 0);
			break;

        case IDTHANKS:
            MessageBox(hWin, ThxList, L"Greetings", MB_OK);
            break;

		case ID_AT4RE:
			ShellExecute(0, L"open", L"http://www.at4re.com", 0, 0, SW_SHOWMAXIMIZED);
			break;

		default:
			return FALSE;
		}
		break;
	case WM_CLOSE:
		EndDialog(hWin, 0);
		break;
	default:
		return FALSE;
	}
	return TRUE;
}


BOOL CALLBACK DlgExtras(HWND hWin, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static EXTRA_DLGPROC *DlgProc;
	static CListView *ListView, *PrevListView;
	static STATUS_BAR *StatusBar;
	static HMENU hMenu;
	RECT rc;
	POINT pt;

	switch (uMsg)
	{
	case WM_INITDIALOG:
		DlgProc = (EXTRA_DLGPROC *)lParam;
		SendMessage(hWin, WM_SETICON, NULL, (LPARAM)LoadIcon(hInstance,MAKEINTRESOURCE(IDI_ICON1)));
		ListView = new CListView(hWin);
		PrevListView = CurrentList;
		CurrentList = ListView;
		StatusBar = new STATUS_BAR;
		StatusBar->Initialize(hWin, L"");
		ListView->create(0, 0, 0, 0, settings.clr_back, settings.clr_front, 0);
		hMenu = CreatePopupMenu();
		DlgProc(hWin, uMsg, wParam, lParam, ListView, StatusBar, hMenu);
		SetWindowPos(hWin, HWND_TOP, GetSystemMetrics(SM_CXSCREEN)/8, GetSystemMetrics(SM_CYSCREEN)/8, GetSystemMetrics(SM_CXSCREEN)*3/4, GetSystemMetrics(SM_CYSCREEN)*3/4, SWP_NOREPOSITION);
		break;

	case WM_SIZE:
		if(wParam != SIZE_MINIMIZED)
		{
			ListView->resize(0, 0, LOWORD(lParam), HIWORD(lParam) - 25);
			GetClientRect(hWin, &rc);
			StatusBar->Resize(rc.left, rc.bottom - 25, rc.right - rc.left, rc.bottom - rc.top);
		}
		break;

	case WM_CLOSE:
		delete ListView;
		delete StatusBar;
		DestroyMenu(hMenu);
		CurrentList = PrevListView;
		return EndDialog(hWin, EXIT_SUCCESS);
		break;

	case WM_COMMAND:
		return DlgProc(hWin, uMsg, wParam, lParam, ListView, StatusBar, hMenu);
		break;

	case WM_NOTIFY:
		if (DlgProc)
		{
			if(((LPNMHDR)lParam)->code == LVN_COLUMNCLICK)
			{
				((LPNMLISTVIEW)lParam)->lParam = (LPARAM)ListView;
				ListView_SortItemsEx(((LPNMHDR)lParam)->hwndFrom, CListView::sort, (LPNMLISTVIEW)lParam);
			}
			else if (((LPNMHDR)lParam)->code == NM_RCLICK && ((LPNMHDR)lParam)->hwndFrom == ListView->getHwnd())
			{
				if	(!ListView->isRawSelected())
				{
					for (LONG n = 1; n < GetMenuItemCount(hMenu); ++n) 
					{
						EnableMenuItem(hMenu, GetMenuItemID(hMenu, n), MF_BYCOMMAND | MF_GRAYED);
					}
				}
				else 
				{
					for (LONG n = 1; n < GetMenuItemCount(hMenu); ++n) 
					{
						EnableMenuItem(hMenu, GetMenuItemID(hMenu, n), MF_BYCOMMAND | MF_ENABLED);
					}
				}
				GetCursorPos(&pt);
				TrackPopupMenu(hMenu, TPM_LEFTALIGN, pt.x, pt.y, NULL, hWin, NULL);
			}
			else
			{
				return DlgProc(hWin, uMsg, wParam, lParam, ListView, StatusBar, hMenu);
			}
		}
		else
		{
			return FALSE;
		}
		break;

	default:
		return FALSE;
	}
	return TRUE;
}


LRESULT CALLBACK GetMsgHookProc(int nCode, WPARAM wParam, LPARAM lParam)
{
    LPMSG lpMsg = (LPMSG)lParam;
    WCHAR ClassName[256] = L"";

    if (GetClassName(lpMsg->hwnd, ClassName, COF(ClassName)) && !wcsicmp(ClassName, WC_LISTVIEW))
    {
	    if (nCode >= 0)   
	    {
            TranslateAccelerator(gWin, hAccelerator, lpMsg);
	    }
    }
	return CallNextHookEx(g_hook, nCode, wParam, lParam);
}


BOOL CALLBACK DlgProc(HWND	hWin,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
    TC_ITEM	ItemStruct;
	LPDRAWITEMSTRUCT	DrStruct = (LPDRAWITEMSTRUCT)lParam;
    switch (uMsg)
    {
	case	WM_INITDIALOG:
		{
			HIMAGELIST himl;
			gWin = hWin;
			
			status.Initialize(hWin, L"");
			hTab = GetDlgItem(hWin, TAB);
			himl = ImageList_Create(GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), ILC_COLORDDB|ILC_MASK, 11, 0);
			for (ULONG c = 0; c <= 10; ++c)
			{
				ImageList_AddIcon(himl, LoadIcon(hInstance, icon_index[c]));
			};
			TabCtrl_SetImageList(hTab, himl);

			ItemStruct.mask = TCIF_TEXT | TCIF_IMAGE;
			for (ULONG c = 0; c <= 10; ++c)
			{
				ItemStruct.iImage = c;
				ItemStruct.pszText = tab_string[c];
				TabCtrl_InsertItem(hTab, c, &ItemStruct);
			};

			for (ULONG c = 0; c <= 10; ++c)
			{
				GlobalHandles[c] = CreateDialogParam(hInstance, dlg_index[c], hTab, dlg_proc[c], 0);
			};
			PrevSelTab = GlobalHandles[0];
			gFontHandle = (HGDIOBJ)SendMessage(GlobalHandles[0], WM_GETFONT, NULL, NULL);
			
			
			//
			// Init plugins
			//
			HMENU HwndMenu, HwndSubmenu;
			HwndMenu = GetMenu(hWin);
			HwndSubmenu = GetSubMenu(HwndMenu, 4);
            PluginMenuData = new std::vector<PLUGIN_DATA>;
			for (ULONG i = 0; i < PluginsCount; i++)
			{
                HMENU HwndPluginSubMenu = CreatePopupMenu();
                PPLUGIN_MENU PluginMenuList = PluginsList[i]->GetPluginMenuList();
                while (PluginMenuList->MenuTitle != PLUGIN_MENU_END)
                {
                    PLUGIN_DATA PluginData = {PluginsMenuCount, PluginMenuList->Callback};
                    PluginMenuData->push_back(PluginData);
                    AppendMenu(HwndPluginSubMenu, MF_STRING, PLUGIN_RES_BASE + PluginsMenuCount, PluginMenuList->MenuTitle);
                    PluginsMenuCount++;
                    PluginMenuList++;
                }
                AppendMenu(HwndSubmenu, MF_POPUP | MF_STRING, (UINT_PTR)HwndPluginSubMenu, PluginsList[i]->GetPluginName());
			}

			SendMessage(hWin, WM_SETICON,NULL, (LPARAM)LoadIcon(hInstance, MAKEINTRESOURCE(IDI_ICON1)));
			hAccelerator = LoadAccelerators(hInstance, L"ACCELERATOR");
			g_hook = SetWindowsHookEx(WH_GETMESSAGE, GetMsgHookProc, NULL, GetCurrentThreadId()); 
			ShowWindow(GlobalHandles[0], SW_SHOWNORMAL);
			SetWindowPos(hWin, HWND_TOP, GetSystemMetrics(SM_CXSCREEN)/8, GetSystemMetrics(SM_CYSCREEN)/8, GetSystemMetrics(SM_CXSCREEN)*3/4, GetSystemMetrics(SM_CYSCREEN)*3/4, SWP_NOREPOSITION);
			
			break;
		}
	case	WM_COMMAND:
		{
			if (LOWORD(wParam) == IDM_COPY)
			{
				CString LogBuffer;
				WCHAR ItemText[1024];

				HWND hwndHeader = ListView_GetHeader(CurrentList->getHwnd());
				int c = CurrentList->getSelCount() + CurrentList->getSelIndex();
				for (int i = CurrentList->getSelIndex(); i < c; i++)
				{
					int iColumn = Header_GetItemCount(hwndHeader);
					for (int k = 0; k < iColumn; k++)
					{
						CurrentList->getText(i, k, ItemText, 1024);
						LogBuffer += ItemText;
						if (k < iColumn - 1)
							LogBuffer += L"    |    ";
						else
							LogBuffer += L"    ";
					}
					LogBuffer += L"\r\n";
				}
				SetClipboard(LogBuffer.GetBuffer());
				break;
			}
			else if (LOWORD(wParam) == IDM_ALL)
			{
				for (int i = 0; i < CurrentList->getCount(); i++)
					ListView_SetItemState(CurrentList->getHwnd(), i, LVIS_FOCUSED | LVIS_SELECTED, LVIS_FOCUSED | LVIS_SELECTED);
				break;
			}
            else if (wParam == CONSOLE_PLUGIN)
            {
                DialogBoxParam(hInstance, MAKEINTRESOURCE(DLG_PLUGIN_CONSOLE), hWin, DlgConsole, NULL);
            }
			else if (wParam >= PLUGIN_RES_BASE && wParam < PLUGIN_RES_BASE + PluginsMenuCount)
			{
				ULONG Index = wParam - PLUGIN_RES_BASE;

                if (!IsBadCodePtr((FARPROC)PluginMenuData->at(Index).Callback))
                    PluginMenuData->at(Index).Callback();
				break;
			}

			switch(wParam)
			{
			case MAIN_EXIT:
				{
					EndDialog(hWin, 0);
					break;
				};
			case MAIN_SAVELIST:
				{
					if (CurrentList->getCount() == 0)
					{
						MessageBox(hWin, L"No data to save in the log file !", AppName, MB_OK | MB_ICONEXCLAMATION);
						break;
					}
					WCHAR *FilePath = (WCHAR *)DialogBoxParam(hInstance, MAKEINTRESOURCE(DLG_GETFILE), hWin, DlgSetFile, (LPARAM)L"Choose destination file ...");
					if (FilePath)
					{
						HANDLE hLog = CreateFile(FilePath, GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_ARCHIVE, NULL);
						if (hLog != INVALID_HANDLE_VALUE)
						{
							HWND hwndHeader = ListView_GetHeader(CurrentList->getHwnd());
							int iColumn = Header_GetItemCount(hwndHeader);
							int iRow = CurrentList->getCount();
							if (iRow)
							{
								CString LogBuffer(AppName);
								WCHAR ItemText[512];
								DWORD bw;
								SYSTEMTIME SystemTime;
								
								LogBuffer += L"\r\nhttp://www.at4re.com";
								LogBuffer += L"\r\n===============================================\r\n";
								GetLocalTime(&SystemTime);
								_snwprintf_s(ItemText, COF(ItemText), _TRUNCATE, L"%d-%d-%d %d:%d:%d", SystemTime.wYear, SystemTime.wMonth, SystemTime.wDay, SystemTime.wHour, SystemTime.wMinute, SystemTime.wSecond);
								LogBuffer += ItemText;
								LogBuffer += L"\r\n===============================================\r\n";
								_snwprintf_s(ItemText, COF(ItemText), _TRUNCATE, L"Current NT Build Number = %d", NtBuildNumber);
								LogBuffer += ItemText;
								LogBuffer += L"\r\n===============================================\r\n\r\n";
								for (int i = 0; i < iRow; i++)
								{
									for (int k = 0; k < iColumn; k++)
									{
										LVCOLUMN lvc;
										WCHAR ColText[512];
										lvc.mask = LVCF_TEXT;
										lvc.cchTextMax = 512;
										lvc.pszText = ColText;
										ListView_GetColumn(CurrentList->getHwnd(), k, &lvc);
										_snwprintf_s(ItemText, COF(ItemText), _TRUNCATE, L"%-20s", ColText);
										LogBuffer += ItemText;
										LogBuffer += L": ";
										CurrentList->getText(i, k, ItemText, 512);
										LogBuffer += ItemText;
										LogBuffer += L"\r\n";
									}
									LogBuffer += L"\r\n\r\n";
								}
								SetFilePointer(hLog, 0, NULL, FILE_BEGIN);
								SetEndOfFile(hLog);
								WriteFile(hLog, LogBuffer.GetBuffer(), LogBuffer.GetLength() * sizeof(WCHAR), &bw, NULL);
								ShellExecute(hWin, NULL, L"notepad", FilePath, NULL, SW_SHOWNORMAL);
							}
							CloseHandle(hLog);
						}
						else
						{
							Err(L"Cannot open log file !");
						}
						delete[] FilePath;
					}
				}
				break;
			case MAIN_CLR:
				{
					DialogBoxParam(hInstance, MAKEINTRESOURCE(DLG_CLR), hWin, DlgClr, 0);
					break;
				}
			case MENU_ABOUT:
				{
					DialogBoxParam(hInstance, L"ABOUTBOX", hWin, DlgAbout, 0);
					break;
				}
			case EXTRA_UNLOADEDDRIVERS:
				{
					DialogBoxParam(hInstance, MAKEINTRESOURCE(DLG_EXTRAS), hWin, DlgExtras, (LPARAM)DlgUnloadedDrivers);
					break;
				}
			case EXTRA_KTIMERS:
				{
					DialogBoxParam(hInstance, MAKEINTRESOURCE(DLG_EXTRAS), hWin, DlgExtras, (LPARAM)DlgKTimer);
					break;
				}
			case EXTRA_OBJECTTYPES:
				{
					DialogBoxParam(hInstance, MAKEINTRESOURCE(DLG_EXTRAS), hWin, DlgExtras, (LPARAM)DlgObjectTypes);
					break;
				}
			case EXTRA_NOTIFYCALLBACKS:
				{
					DialogBoxParam(hInstance, MAKEINTRESOURCE(DLG_EXTRAS), hWin, DlgExtras, (LPARAM)DlgNotifyCallbacks);
					break;
				}
			case FILEKILLER_DELETE:
				{
					WCHAR *FilePath = (WCHAR *)DialogBoxParam(hInstance, MAKEINTRESOURCE(DLG_GETFILE), hWin, DlgGetFile, (LPARAM)L"Choose file to delete ...");
					if (FilePath)
					{
						if (FileDelete(FilePath, FALSE))
						{
							MessageBox(hWin, L"File deleted successfully", AppName, MB_OK | MB_ICONINFORMATION);
						}
						else
						{
							MessageBox(hWin, L"File cannot be deleted normally !", AppName, MB_OK | MB_ICONERROR);
						}
						delete[] FilePath;
					}
					break;
				}
			case FILEKILLER_FORCEDELETE:
				{
					WCHAR *FilePath = (WCHAR *)DialogBoxParam(hInstance, MAKEINTRESOURCE(DLG_GETFILE), hWin, DlgGetFile, (LPARAM)L"Choose file to delete ...");
					if (FilePath)
					{
						if (FileDelete(FilePath, TRUE))
						{
							MessageBox(hWin, L"File deleted successfully", AppName, MB_OK | MB_ICONINFORMATION);
						}
						else
						{
							MessageBox(hWin, L"File cannot be deleted !", AppName, MB_OK | MB_ICONERROR);
						}
						delete[] FilePath;
					}
					break;
				}
			case FILEKILLER_COPY:
				{
					WCHAR *SrcPath = (WCHAR *)DialogBoxParam(hInstance, MAKEINTRESOURCE(DLG_GETFILE), hWin, DlgGetFile, (LPARAM)L"Choose source file ...");
					if (SrcPath)
					{
						WCHAR *DestPath = (WCHAR *)DialogBoxParam(hInstance, MAKEINTRESOURCE(DLG_GETFILE), hWin, DlgSetFile, (LPARAM)L"Choose destination file ...");
						if (DestPath)
						{
                            if (FileCopy(SrcPath, DestPath))
							{
								MessageBox(hWin, L"File copied successfully", AppName, MB_OK | MB_ICONINFORMATION);
							}
							else
							{
								MessageBox(hWin, L"File cannot be copied !", AppName, MB_OK | MB_ICONERROR);
							}
							delete[] DestPath;
						}
						delete[] SrcPath;
					}
					break;
				}
			case PHYSICALMEM_DUMPALL:
				{
					DialogBoxParam(hInstance, L"PROGRESSBOX", hWin, DlgDumpPhysicalMemory, NULL);
					break;
				}
			};
			break;
		};
	case WM_SIZE:
		{
			if(wParam != SIZE_MINIMIZED)
			{
				int y, x = 4;
				RECT rect;
				MoveWindow(hTab, 2, 2, LOWORD(lParam) - 2, HIWORD(lParam) - 34, TRUE);
				GetClientRect(hTab, &rect);
				y = rect.top + (TabCtrl_GetRowCount(hTab) * 22);
				for (int i = 0; i < sizeof(GlobalHandles)/sizeof(HWND); i++)
					MoveWindow(GlobalHandles[i], x, y, LOWORD(lParam) - x * 2, rect.bottom - rect.top - (TabCtrl_GetRowCount(hTab) * 22), TRUE);
				GetClientRect(hWin, &rect);
				status.Resize(rect.left, rect.bottom - 20, rect.right - rect.left, rect.bottom - rect.top);
			}
			break;
		}
    case	WM_NOTIFY :
        if	((wParam == TAB)&&(((LPNMHDR)lParam)->code == TCN_SELCHANGE))
        {
            SwitchTab();
        }
        break;
    case	WM_CLOSE:
		UnhookWindowsHookEx(g_hook);
        delete PluginMenuData;
        EndDialog(hWin,NULL);
        break;
    }
    return 0;
};


void STATUS_BAR::Initialize(HWND Parent, PWCHAR string)
{
	this->hStatus = CreateStatusWindow(WS_VISIBLE|WS_CHILD, string, Parent, 0);
};

void STATUS_BAR::Resize(int x, int y, int xc, int yc)
{
	MoveWindow(this->hStatus, x, y, xc, yc, TRUE);
};

int STATUS_BAR::Format(PWCHAR format, ...)
{
	int nSize = 0;
	WCHAR buff[512];
	RtlZeroMemory(buff, sizeof(buff));
	va_list args;
	va_start(args, format);
	nSize = _vsnwprintf_s(buff, sizeof(buff)/sizeof(WCHAR) - 1, format, args);
	SendMessage(this->hStatus, SB_SETTEXT, 0, (LPARAM)buff);
	return nSize;
};

int STATUS_BAR::Append(PWCHAR string)
{
	SIZE_T nCount = SendMessage(this->hStatus, SB_GETTEXTLENGTH, 0, 0) + wcslen(string);
	PWCHAR buffer = new WCHAR[nCount + 1];
	SendMessage(this->hStatus, SB_GETTEXT, 0, (LPARAM)buffer);
	wcsncat_s(buffer, nCount, string, _TRUNCATE);
	SendMessage(this->hStatus, SB_SETTEXT, 0, (LPARAM)buffer);
	delete [] buffer;
	return _tcslen(buffer);
};


LRESULT CALLBACK GenericEditboxProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_VSCROLL:
	case WM_HSCROLL:
	case WM_PASTE:
	case WM_CHAR:
	case WM_PRINT:
	case WM_PAINT:
		InvalidateRect(hwnd, NULL, TRUE);
		break;
	}
	return CallWindowProc((WNDPROC)GetWindowLongPtr(hwnd, GWLP_USERDATA), hwnd, uMsg, wParam, lParam);
}


WNDPROC SubclassEditBox(HWND hwnd)
{
	WNDPROC PreviousWndProc = (WNDPROC)SetWindowLongPtr(hwnd, GWLP_WNDPROC, (ULONG)GenericEditboxProc);
	SetWindowLongPtr(hwnd, GWLP_USERDATA, (ULONG)PreviousWndProc);
	return PreviousWndProc;
}