
void EnumDlls(ULONG eProcess, CListView *Listv);
extern CListView *List_Module;

typedef struct _DLL_INFO {
	PVOID		BaseAddress;
	PVOID		EntryPoint;
	ULONG		SizeOfImage;
	WCHAR		FullDllName[MAX_PATH];
}DLL_INFO,*LPDLL_INFO;