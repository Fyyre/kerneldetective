#include	"Kernel Detective.h"
#include	"Disassemble.h"
#include	"dumper.h"
#include	"Dll.h"
#include	<psapi.h>



CListView *List_Module;
HMENU Menu_Module;



void EnumDlls(PVOID ProcessObject, CListView *Listv)
{
	WCHAR Temp[BUFFER_LEN];
	PDLL_ENTRY Dlls;
    ULONG Count;
	
	Listv->beginRefresh();
	__try
	{
        Count = EnumerateDlls(ProcessObject, &Dlls);
		Listv->clear();
		if (Dlls && Count != 0)
		{
			for (ULONG i = 0; i < Count; i++)
			{
				decodefilepath(Dlls[i].FullDllName, COF(Dlls[i].FullDllName));
				Listv->insertRaw(Dlls[i].FullDllName, TRUE);

				_snwprintf_s(Temp, COF(Temp), L"0x%p",Dlls[i].BaseAddress);
				Listv->insertRaw(Temp, FALSE);

				_snwprintf_s(Temp, COF(Temp), L"0x%p",Dlls[i].EntryPoint);
				Listv->insertRaw(Temp, FALSE);

				_snwprintf_s(Temp, COF(Temp), L"%ld", Dlls[i].SizeOfImage);
				Listv->insertRaw(Temp, FALSE);
			}
			delete[] Dlls;
		}
	}
	__except(1)
	{};

	Listv->endRefresh();
	status.Format(L"Total Modules :: %ld", Count);
};


ULONG InjectLibrary(PPROCESS_ENTRY Process, PWCHAR path)
{
    PVOID mem = AllocateVirtualMemory(Process->ProcessObject, 0x1000);
	ULONG exitcode = 0;
	if (mem)
	{
		if (KiWriteVirtualMemory(Process->ProcessObject, (PVOID)mem, path, wcslen(path)*sizeof(WCHAR)))
		{
            HANDLE handle = GetProcessHandle(Process->ProcessObject);
			if (handle)
			{
				ULONG threadId;
				HANDLE hThread = CreateRemoteThread(handle, 0, 0, 
					(LPTHREAD_START_ROUTINE)GetProcAddress(GetModuleHandle(L"kernel32.dll"), "LoadLibraryW"),
					(PVOID)mem, 0, &threadId);
				if (hThread)
				{
					for (int i = 0; i < 10; ++i)
					{
						Sleep(200);
						if (GetExitCodeThread(hThread, &exitcode))
						{
							if (STILL_ACTIVE == exitcode) continue;
							break;
						}
					};
					CloseHandle(hThread);
				};
			};
			CloseHandle(handle);
		};
		FreeVirtualMemory(Process->ProcessObject, mem, 0);
	};
	return exitcode;
};


BOOL UnloadLibrary(PPROCESS_ENTRY Process, ULONG Base)
{
	ULONG exitcode = 0;
    HANDLE handle = GetProcessHandle(Process->ProcessObject);
	if (handle)
	{
		ULONG threadId;
		HANDLE hThread = CreateRemoteThread(handle, 0, 0, 
			(LPTHREAD_START_ROUTINE)GetProcAddress(GetModuleHandle(L"kernel32.dll"), "FreeLibrary"),
			(PVOID)Base, 0, &threadId);
		if (hThread)
		{
			for (int i = 0; i < 10; ++i)
			{
				Sleep(200);
				if (GetExitCodeThread(hThread, &exitcode))
				{
					if (STILL_ACTIVE == exitcode) continue;
					break;
				}
			};
			CloseHandle(hThread);
		};
		CloseHandle(handle);
	};
	return exitcode;
};


void CALLBACK Dll_Cmd(HWND hWin, WPARAM wParam, LPARAM lParam, CListView *Listv)
{
	ULONG		offset = 0;
	int			szCmd = 0;
	int			Pos = 0;
	DWORD		eProcess = 0;

	switch	(wParam)
	{
	case	DLL_REFRESH:
		{
			EnumDlls(KiCurrentProcess.ProcessObject, Listv);
			break;
		}
	case	DLL_EP:
		{
			UpdateCommonBuffer(Listv->getSelUlong(2, 16), 0x400);
			if (KiReadVirtualMemory(KiCurrentProcess.ProcessObject, GetCommonReadAddress(), GetCommonReadBuffer(), GetCommonReadSize()))
				PrintDisasm(GetCommonReadBuffer(), GetCommonReadAddress(), GetCommonReadSize());
			break;
		}
	case	DLL_DUMP:
		{
            dumper dumpfile(KiCurrentProcess.ProcessObject, Listv->getSelUlong(1, 16));
			dumpfile.dump_process(0, 0);
            break;
		}
	case	DLL_INJECT:
		{
			WCHAR dllpath[MAX_PATH] = L"";
			OPENFILENAME ofn;
			RtlZeroMemory(&ofn, sizeof(OPENFILENAME));
			ofn.lStructSize = sizeof(OPENFILENAME);
			ofn.hwndOwner = hWin;
			ofn.lpstrFilter = L"Dynamic Library Files(*.dll)\0*.dll\0All Files(*.*)\0*.*\0\0";
			ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_LONGNAMES;
			ofn.nMaxFile = MAX_PATH;
			ofn.lpstrFile = dllpath;
			ofn.lpstrTitle = L"Load Library ...";
			if (GetSaveFileName(&ofn))
			{
				if (0 == InjectLibrary(&KiCurrentProcess, dllpath))
					Err(L"Cannot inject library !");
				else
					Msg(L"Library injected successfully !");
                EnumDlls(KiCurrentProcess.ProcessObject, Listv);
			};
            break;
		}
	case	DLL_UNLOAD:
		{
			if (0 == UnloadLibrary(&KiCurrentProcess, Listv->getSelUlong(1, 16)))
				Err(L"Cannot free library !");
			else
				Msg(L"Library freed successfully !");
            EnumDlls(KiCurrentProcess.ProcessObject, Listv);
            break;
		}
	case DLL_PROPERTIES:
		{
			WCHAR FileName[MAX_PATH];
			Listv->getSelText(0, FileName, sizeof(FileName));
			ShowFilePropertiesDlg(FileName);
			break;
		}
	case DLL_UNMAPMEMORY:
		{
            UnmapSection(KiCurrentProcess.ProcessObject, (void *)Listv->getSelUlong(1, 16));
			UnloadLibrary(&KiCurrentProcess, Listv->getSelUlong(1, 16));
            EnumDlls(KiCurrentProcess.ProcessObject, Listv);
			break;
		}
	case DLL_ZEROMEMORY:
		{
			unsigned long size = Listv->getSelUlong(3, 10);
			void *buffer = malloc(size);
			ZeroMemory(buffer, size);
            KiWriteVirtualMemory(KiCurrentProcess.ProcessObject, (void *)Listv->getSelUlong(1, 16), buffer, size);
			free(buffer);
            EnumDlls(KiCurrentProcess.ProcessObject, Listv);
			break;
		}
	case DLL_DELETE:
		{
			WCHAR FileName[MAX_PATH];
			Listv->getSelText(0, FileName, MAX_PATH);
			if (FileDelete(FileName, FALSE))
			{
				MessageBox(hWin, L"File deleted successfully", AppName, MB_OK | MB_ICONINFORMATION);
			}
			else
			{
				UINT msgID = MessageBox(hWin, L"Cannot delete file normally !\r\nDo you want to force delete the file ?", AppName, MB_YESNO | MB_ICONERROR);
				if (msgID == IDYES)
				{
					SendMessage(hWin, WM_COMMAND, DLL_FORCEDELETE, 0);
				}
			}
			break;
		}
	case DLL_FORCEDELETE:
		{
			WCHAR FileName[MAX_PATH];
			Listv->getSelText(0, FileName, MAX_PATH);
			if (FileDelete(FileName, TRUE))
			{
				MessageBox(hWin, L"File deleted successfully", AppName, MB_OK | MB_ICONINFORMATION);
			}
			else
			{
				MessageBox(hWin, L"File cannot be deleted !", AppName, MB_OK | MB_ICONERROR);
			}
			break;
		}
	case DLL_VERIFY:
		{
			WCHAR FileName[MAX_PATH];
			Listv->getSelText(0, FileName, MAX_PATH);
			if (IsFileDigitallySigned(FileName))
			{
				MessageBox(hWin, L"File was verified successfully", AppName, MB_OK | MB_ICONINFORMATION);
			}
			else
			{
				MessageBox(hWin, L"File cannot be verified", AppName, MB_OK | MB_ICONEXCLAMATION);
			}
			break;
		}
	}
    return;
};


BOOL CALLBACK DlgModule(HWND hWin,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
    POINT		XY;
	static CListView List_Module(hWin);

	::List_Module = &List_Module;

    switch (uMsg)
    {
    case	WM_INITDIALOG :
		List_Module.create(0, 0, 0, 0, settings.clr_back, settings.clr_front, 1);
		List_Module.insertColumn(L"Path", 500);
        List_Module.insertColumn(L"Image Base", 80);
		List_Module.insertColumn(L"Entry Point", 80);
		List_Module.insertColumn(L"Size", 80);
        Menu_Module = GetSubMenu(LoadMenu(hInstance,MAKEINTRESOURCE(MENU_MODULE)),0);
        break;
	case	WM_SHOWWINDOW:
		if (wParam)
		{
            EnumDlls(KiCurrentProcess.ProcessObject, &List_Module);
			CurrentList = &List_Module;
		}
		break;
    case	WM_COMMAND :
		Dll_Cmd(hWin, wParam, lParam, &List_Module);
        break;
	case WM_SIZE:
		{
			if(wParam != SIZE_MINIMIZED)
				List_Module.resize(0, 0, LOWORD(lParam),HIWORD(lParam));
			break;
		}
    case	WM_NOTIFY :
		if	(((LPNMHDR)lParam)->hwndFrom == List_Module.getHwnd()  &&  ((LPNMHDR)lParam)->code == NM_RCLICK)
        {
			if	(0 == List_Module.isRawSelected())	break;
            GetCursorPos(&XY);
            TrackPopupMenu(Menu_Module,TPM_LEFTALIGN,XY.x,XY.y,NULL,hWin,NULL);
        }
		if(((LPNMHDR)lParam)->code == LVN_COLUMNCLICK)
		{
			((LPNMLISTVIEW)lParam)->lParam = (LPARAM)&List_Module;
			ListView_SortItemsEx(((LPNMHDR)lParam)->hwndFrom, CListView::sort, (LPNMLISTVIEW)lParam);
			return TRUE;
		}
		if(((LPNMHDR)lParam)->code == NM_CUSTOMDRAW)
		{
			PWCHAR warn = L"0x00000000";
			SetWindowLong(hWin, DWL_MSGRESULT, (LONG)Listview_handler((LPNMLVCUSTOMDRAW)lParam, &warn, 1, 2, &List_Module));
			return TRUE;
		}
        break;
    }
    return 0;
};
