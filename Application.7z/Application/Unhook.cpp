#include	"Kernel Detective.h"
#include	"Disassemble.h"
#include	"Unhook.h"
#include	<DbgHelp.h>


HMENU		Menu_Unhook;


const PWCHAR HookState[]	=
{
	L"Code Modification", 
	L"Relative Jump", 
	L"Far Jump", 
	L"Relative Call", 
	L"Far Call", 
	L"Direct Jump", 
	L"Direct Call", 
	L"IAT Modification", 
	L"EAT Modification"
};


const PWCHAR HookDescription[] =
{
	L"%s :: jmp 0x%p", 
	L"%s :: call 0x%p"
};




VOID ShowHooks(CListView *Listv, PHOOK_ENTRY hook_info)
{
    WCHAR Temp[BUFFER_LEN] = L"";
    WCHAR Temp2[BUFFER_LEN] = L"";

    _snwprintf_s(Temp, COF(Temp), L"0x%p", hook_info->ImageBase+hook_info->Rva);
    Listv->insertRaw(Temp, true);

    GetModulePath(hook_info->ImageBase+hook_info->Rva, Temp2, BUFFER_LEN);
    _snwprintf_s(Temp, COF(Temp), L"%s", PathToFileName(Temp2));
    Listv->insertRaw(Temp, false);

    RtlZeroMemory(Temp, sizeof(Temp));
    _snwprintf_s(Temp, COF(Temp), L"%ld", hook_info->Size);
    Listv->insertRaw(Temp, false);

    RtlZeroMemory(Temp, sizeof(Temp));
    switch (hook_info->State)
    {
    case 1:
        _snwprintf_s(Temp, COF(Temp), HookDescription[0], HookState[1], hook_info->Parameter1);
        break;
    case 2:
        _snwprintf_s(Temp, COF(Temp), HookDescription[0], HookState[2], hook_info->Parameter1);
        break;
    case 3:
        _snwprintf_s(Temp, COF(Temp), HookDescription[1], HookState[3], hook_info->Parameter1);
        break;
    case 4:
        _snwprintf_s(Temp, COF(Temp), HookDescription[1], HookState[4], hook_info->Parameter1);
        break;
    case 5:
        _snwprintf_s(Temp, COF(Temp), HookDescription[0], HookState[5], hook_info->Parameter1);
        break;
    case 6:
        _snwprintf_s(Temp, COF(Temp), HookDescription[1], HookState[6], hook_info->Parameter1);
        break;
    case 7:
        GetModulePath(hook_info->Parameter1, Temp2, BUFFER_LEN);
        _snwprintf_s(Temp, COF(Temp), L"%s :: 0x%p -> %s", HookState[7], hook_info->Parameter1, PathToFileName(Temp2));
        break;
    case 8:
        GetModulePath(hook_info->Parameter1, Temp2, BUFFER_LEN);
        _snwprintf_s(Temp, COF(Temp), L"%s :: 0x%p -> %s", HookState[8], hook_info->Parameter1, PathToFileName(Temp2));
        break;
    default:
        _snwprintf_s(Temp, COF(Temp), L"%s", HookState[0]);
    }
    Listv->insertRaw(Temp, false);

    RtlZeroMemory(Temp, sizeof(Temp));
    for (ULONG k = 0; k < hook_info->Size && k < 32; k++)
    {
        _snwprintf_s(Temp2, COF(Temp2), L"%.2X ", hook_info->Current[k]);
        wcsncat_s(Temp, Temp2, 3);
    }
    Listv->insertRaw(Temp, false);

    RtlZeroMemory(Temp, sizeof(Temp));
    for (ULONG k = 0; k<hook_info->Size && k<32; k++)
    {
        _snwprintf_s(Temp2, COF(Temp2), L"%.2X ", hook_info->Origin[k]);
        wcsncat_s(Temp, Temp2, 3);
    }
    Listv->insertRaw(Temp, false);

    wcscpy_s(Temp, L"-");
    if (hook_info->Parameter2)
    {
        GetModulePath(hook_info->Parameter2, Temp2, BUFFER_LEN);
        if (!_wcsnicmp(Temp2, L"\\??\\", 4))
            _snwprintf_s(Temp, COF(Temp), L"0x%p :: %s", hook_info->Parameter2, Temp2 + 4);
        else
            _snwprintf_s(Temp, COF(Temp), L"0x%p :: %s", hook_info->Parameter2, QueryEnvironmentString(Temp2, Temp2, BUFFER_LEN));
    }
    Listv->insertRaw(Temp, false);
}


void EnumHooks(CListView *Listv)
{
	WCHAR Temp[BUFFER_LEN] = L"";
	WCHAR Temp2[BUFFER_LEN] = L"";
	PHOOK_ENTRY hook_info;
	ULONG count, total = 0;
	ULONG j, i;
	ULONG flags;


	Listv->beginRefresh();

	Listv->clear();
	UPDATE_MODULES();
	for (j = 0; j < COF(FullKernelModulesPath); ++j) 
	{
		status.Format(L"Scanning %s ...", PathToFileName(FullKernelModulesPath[j]));
		flags = KRNL_SCAN_EAT | KRNL_SCAN_IAT;
		if (j != 2) flags |= KRNL_SCAN_SECTIONS; // Skip hal.dll
        count = EnumerateKernelHooks(FullKernelModulesPath[j], &hook_info, flags);
		if (0 != hook_info)
		{
			total += count;
			for (i = 0; i < count; i++)
			{
				ShowHooks(Listv, &hook_info[i]);
            }
			delete[] hook_info;
		}
	}

	Listv->endRefresh();
	status.Format(L"Total kernel hooks :: %ld", total);
}


void ScanSpecificModule(CListView *Listv, WCHAR *ModuleName)
{
	WCHAR Temp[BUFFER_LEN] = L"";
	WCHAR Temp2[BUFFER_LEN] = L"";
	PHOOK_ENTRY hook_info;
	ULONG count, total = 0;
	ULONG i;
	ULONG flags;


	wcsncpy_s(Temp, L"\\Systemroot\\system32\\", COF(Temp));
	wcsncpy_s(Temp2, L"\\Systemroot\\system32\\drivers\\", COF(Temp2));
	wcsncat_s(Temp, ModuleName, COF(Temp));
	wcsncat_s(Temp2, ModuleName, COF(Temp2));
	Listv->beginRefresh();
	Listv->clear();
	UPDATE_MODULES();
	status.Format(L"Scanning %s ...", PathToFileName(ModuleName));
	flags = KRNL_SCAN_EAT | KRNL_SCAN_IAT | KRNL_SCAN_SECTIONS;
	count = EnumerateKernelHooks(ModuleName, &hook_info, flags);
	if (!count)
        count = EnumerateKernelHooks(Temp, &hook_info, flags);
    if (!count)
        count = EnumerateKernelHooks(Temp2, &hook_info, flags);
    if (count)
    {
        total += count;
        for (i = 0; i < count; i++)
        {
            ShowHooks(Listv, &hook_info[i]);
        }
        delete[] hook_info;
    }

	Listv->endRefresh();
	status.Format(L"Total hooks found in %s :: %ld", PathToFileName(ModuleName), total);
}



void CALLBACK Unhook_Cmd(HWND hWin, WPARAM wParam, LPARAM lParam, CListView *Listv)
{

	switch	(wParam)
	{
	case	UNHOOK_REFRESH:
		{
			EnumHooks(Listv);
			break;
		}
	case UNHOOK_SCAN_MODULE:
		{
			WCHAR *FilePath = GETMODULENAMEDLG(L"Input the driver name [example : atapi.sys]");
			if (FilePath)
			{
				ScanSpecificModule(Listv, FilePath);
				delete[] FilePath;
			}
			break;
		}
	case	UNHOOK_RESTORE:
		{
			int c = Listv->getSelCount() + Listv->getSelIndex();
			for (int i = Listv->getSelIndex(); i < c; i++)
			{
                KI_PACKET KiPacket;
                KiPacket.Parameters.Common.Parameter1 = Listv->getUlong(i, 0, 16);
                KiPacket.Parameters.Common.Parameter2 = Listv->getUlong(i, 2, 10);
				Syscall(IOCTL_UNHOOK_KERNEL, &KiPacket);
			}
			EnumHooks(Listv);
			break;
		}
	case	UNHOOK_ALL:
		for (int i = 0; i < Listv->getCount(); ++i)
		{
            KI_PACKET KiPacket;
            KiPacket.Parameters.Common.Parameter1 = Listv->getUlong(i, 0, 16);
            KiPacket.Parameters.Common.Parameter2 = Listv->getUlong(i, 2, 10);
			Syscall(IOCTL_UNHOOK_KERNEL, &KiPacket);
		}
		EnumHooks(Listv);
		break;
	case	UNHOOK_GOTO:
		void *RW = UpdateCommonBuffer(Listv->getSelUlong(0, 16), 0x400);
        if	(KiReadVirtualMemory(KiCurrentProcess.ProcessObject, GetCommonReadAddress(), RW, GetCommonReadSize()))
			PrintDisasm(RW, GetCommonReadAddress(), GetCommonReadSize());
		break;
	}
    return;
}




BOOL CALLBACK DlgUnhook(HWND hWin, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    POINT		XY;
	static CListView List_Unhook(hWin);

    switch (uMsg)
    {
    case	WM_INITDIALOG :
        List_Unhook.create(0, 0, 0, 0, settings.clr_back, settings.clr_front, 3);
		List_Unhook.insertColumn(L"Address", 80);
		List_Unhook.insertColumn(L"Location", 140);
		List_Unhook.insertColumn(L"Len", 30);
		List_Unhook.insertColumn(L"State", 120);
		List_Unhook.insertColumn(L"Current Value", 80);
        List_Unhook.insertColumn(L"Original Value", 80);
		List_Unhook.insertColumn(L"Destination Module", 300);
        Menu_Unhook = GetSubMenu(LoadMenu(hInstance, MAKEINTRESOURCE(MENU_UNHOOK)), 0);
        break;
	case	WM_SHOWWINDOW:
		if (wParam)
		{
			EnumHooks(&List_Unhook);
			CurrentList = &List_Unhook;
		}
    case	WM_COMMAND :
		Unhook_Cmd(hWin, wParam, lParam, &List_Unhook);
        break;
	case WM_SIZE:
		{
			if(wParam != SIZE_MINIMIZED)
				List_Unhook.resize(0, 0, LOWORD(lParam), HIWORD(lParam));
			break;
		}
    case	WM_NOTIFY :
		if	(((LPNMHDR)lParam)->hwndFrom == List_Unhook.getHwnd()  &&  ((LPNMHDR)lParam)->code == NM_RCLICK)
        {
			if	(0 == List_Unhook.isRawSelected()) {
				for (long n = 2; n < GetMenuItemCount(Menu_Unhook); ++n) {
					EnableMenuItem(Menu_Unhook, GetMenuItemID(Menu_Unhook, n), MF_BYCOMMAND | MF_GRAYED);
				}
			} else {
				for (long n = 2; n < GetMenuItemCount(Menu_Unhook); ++n) {
					EnableMenuItem(Menu_Unhook, GetMenuItemID(Menu_Unhook, n), MF_BYCOMMAND | MF_ENABLED);
				}
			}
            GetCursorPos(&XY);
            TrackPopupMenu(Menu_Unhook, TPM_LEFTALIGN, XY.x, XY.y, NULL, hWin, NULL);
        }
		if(((LPNMHDR)lParam)->code == LVN_COLUMNCLICK)
		{
			((LPNMLISTVIEW)lParam)->lParam = (LPARAM)&List_Unhook;
			ListView_SortItemsEx(((LPNMHDR)lParam)->hwndFrom, CListView::sort, (LPNMLISTVIEW)lParam);
			return true;
		}
		if(((LPNMHDR)lParam)->code == NM_CUSTOMDRAW)
		{
			SetWindowLong(hWin, DWL_MSGRESULT, (LONG)Listview_handler((LPNMLVCUSTOMDRAW)lParam, 0, 0, 0, &List_Unhook));
			return TRUE;
		}
        break;
    }
    return 0;
}
