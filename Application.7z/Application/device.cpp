#include <stdio.h>
#include "device.h"
#include "shadow_service_strings.h"
#include "Help.h"
#include <Dbghelp.h>
#include <psapi.h>
#include <shlwapi.h>
#pragma comment(lib, "dbghelp.lib")



WCHAR FixedKernelName[260];

PWCHAR BasicKernelFiles[] = {
	L"\\Systemroot\\system32\\ntoskrnl.exe",
	L"\\Systemroot\\system32\\win32k.sys",
	L"\\Systemroot\\system32\\hal.dll",
	L"\\Systemroot\\system32\\drivers\\afd.sys",
	L"\\Systemroot\\system32\\drivers\\tcpip.sys",
	L"\\Systemroot\\system32\\drivers\\tdi.sys",
	L"\\Systemroot\\system32\\drivers\\wanarp.sys",
	L"\\Systemroot\\system32\\drivers\\disk.sys",
	L"\\Systemroot\\system32\\drivers\\fastfat.sys",
	L"\\Systemroot\\system32\\drivers\\ntfs.sys",
	L"\\Systemroot\\system32\\drivers\\cdfs.sys",
	L"\\Systemroot\\system32\\drivers\\dmio.sys",
	L"\\Systemroot\\system32\\drivers\\ftdisk.sys",
	L"\\Systemroot\\system32\\drivers\\fltmgr.sys",
	L"\\Systemroot\\system32\\drivers\\classpnp.sys",
	L"\\Systemroot\\system32\\drivers\\atapi.sys",
	L"\\Systemroot\\system32\\drivers\\ndis.sys",
	L"\\Systemroot\\system32\\drivers\\http.sys",
	L"\\Systemroot\\system32\\drivers\\scsiport.sys",
	L"\\Systemroot\\system32\\drivers\\kbdclass.sys"
};

ULONG nBasicKernelFiles = sizeof(BasicKernelFiles)/sizeof(PWCHAR);



WCHAR *kernels_path[] = {

	// user libraries

	L"\\ntdll.dll",		//0
	L"\\kernel32.dll",	//1
	L"\\user32.dll",		//2
	L"\\gdi32.dll",		//3
	L"\\advapi32.dll",	//4
	L"\\shell32.dll",	//5
	L"\\ole32.dll",		//6

	// kernel drivers

	L"\\ntoskrnl.exe",	//7
	L"\\ntkrnlpa.exe",	//8
	L"\\win32k.sys",
	L"\\hal.dll",
	L"\\drivers\\afd.sys",
	L"\\drivers\\tcpip.sys",
	L"\\drivers\\tdi.sys",
	L"\\drivers\\wanarp.sys",
	L"\\drivers\\disk.sys",
	L"\\drivers\\fastfat.sys",
	L"\\drivers\\ntfs.sys",
	L"\\drivers\\cdfs.sys",
	L"\\drivers\\dmio.sys",
	L"\\drivers\\ftdisk.sys",
	L"\\drivers\\fltmgr.sys",
	L"\\drivers\\classpnp.sys",
	L"\\drivers\\atapi.sys",
	L"\\drivers\\ndis.sys",
	L"\\drivers\\http.sys",
	L"\\drivers\\scsiport.sys",
	L"\\drivers\\kbdclass.sys"
};

WCHAR *kernels_file[] = {
	L"ntdll.dll",
	L"kernel32.dll",
	L"user32.dll",
	L"gdi32.dll",
	L"advapi32.dll",
	L"shell32.dll",
	L"ole32.dll",
	L"ntoskrnl.exe",
	L"ntkrnlpa.exe",
	L"win32k.sys",
	L"hal.dll",
	L"afd.sys",
	L"tcpip.sys",
	L"tdi.sys",
	L"wanarp.sys",
	L"disk.sys",
	L"fastfat.sys",
	L"ntfs.sys",
	L"cdfs.sys",
	L"dmio.sys",
	L"ftdisk.sys",
	L"fltmgr.sys",
	L"classpnp.sys",
	L"atapi.sys",
	L"ndis.sys",
	L"http.sys",
	L"scsiport.sys",
	L"kbdclass.sys"
};

ULONG kernels_base[sizeof(kernels_file) / sizeof(PWCHAR)];
WCHAR **sym_strings;
unsigned long *sym_addresses;
unsigned long sym_count = 0;


WCHAR *pathToFileName(WCHAR *str)
{
	for	(int i = wcslen(str);i>0;i--)
		if	(str[i] == '\\')
			return str+i+1;
	return str;
};


void arrangeElements(void *array, long n, unsigned long size, unsigned long id_offset)
{
	void *element = malloc(size);

	for (long k = 0; k < n; ++k)
	{
		for (long j = 0; j < n - 1; ++j)
		{
			unsigned long id_1 = *(unsigned long *)((unsigned long)array + (size * j) + id_offset);
			unsigned long id_2 = *(unsigned long *)((unsigned long)array + (size * (j + 1)) + id_offset);
			if (id_1 > id_2)
			{
				RtlCopyMemory(element, (void *)((unsigned long)array + (size * (j + 1))), size);
				RtlCopyMemory((void *)((unsigned long)array + (size * (j + 1))), (void *)((unsigned long)array + (size * j)), size);
				RtlCopyMemory((void *)((unsigned long)array + (size * j)), element, size);
			};
		};
	};
	free(element);
};





device::device(WCHAR *device_name, WCHAR *driver_path, short NtBuild)
{
	this->NtBuildNumber = NtBuild;
	this->readbuffer = this->readaddress = this->readsize = this->processes_count = 0;
	this->processes = 0;
	this->handle = 0;
	this->hookdbg = false;
	RtlZeroMemory(this->errormsg, sizeof(this->errormsg));
	RtlZeroMemory(this->KernelFileName, sizeof(this->KernelFileName));
	if (device_name) wcsncpy_s(this->symbolic, countof(this->symbolic), device_name, _TRUNCATE);
	if (driver_path) wcsncpy_s(this->path, countof(this->path), driver_path, _TRUNCATE);
	this->RealIdt = new ULONG[256];

	if (2600 == this->NtBuildNumber)
	{
		this->NTmax = 284;
		this->GDImax = 667;
		this->ShadowServiceTable = ShadowServiceTableXp;
	}
	else if (6000 == this->NtBuildNumber || 6001 == this->NtBuildNumber || 6002 == this->NtBuildNumber)
	{
		this->NTmax = 398;
		if (6001 == this->NtBuildNumber || 6002 == this->NtBuildNumber) this->NTmax = 391;
		this->GDImax = 772;
		this->ShadowServiceTable = ShadowServiceTableVista;
	}
	else if (7600 == this->NtBuildNumber)
	{
		this->NTmax = 401;
		this->GDImax = 825;
		this->ShadowServiceTable = ShadowServiceTableSeven;
	};
	this->ServiceTable = this->getServiceNames();
	this->NT = new unsigned long [this->NTmax];
	this->GDI = new unsigned long [this->GDImax];
	//this->unload();
};


device::~device()
{
	delete[] this->RealIdt;
	delete[] this->NT;
	delete[] this->GDI;
	delete[] this->ServiceTable;
};




DWORD InstallDriver(PWCHAR ImagePath, PWCHAR SymbolicLink)
{
	DWORD Status, Ret = 1, Value;
	UNICODE_STRING usKey;
	HKEY hk;
	WCHAR wcBuffer[1024];


	_snwprintf_s(wcBuffer, countof(wcBuffer), L"SYSTEM\\CurrentControlSet\\Services\\%s", SymbolicLink);
	
	if(RegCreateKeyEx(HKEY_LOCAL_MACHINE, 
		wcBuffer, 
		0,
		NULL,
		REG_OPTION_NON_VOLATILE,
		KEY_ALL_ACCESS,
		NULL,
		&hk,
		NULL)!=ERROR_SUCCESS)
	{
		//printf("Error with RegCreateKeyEx : %d\n", GetLastError());
		return 0;
	}

	_snwprintf_s(wcBuffer, countof(wcBuffer), L"\\??\\%s", ImagePath);
	if(RegSetValueEx(hk, L"ImagePath", 0, REG_EXPAND_SZ, (const PBYTE)wcBuffer, lstrlen(wcBuffer)*sizeof(WCHAR)) != ERROR_SUCCESS)
	{
		//printf("Error with RegSetValueEx : %d\n", GetLastError());
		Ret = 0;
		goto cleanup;
	}

	Value = SERVICE_KERNEL_DRIVER;
	if(RegSetValueEx(hk, L"Type", 0, REG_DWORD, (LPBYTE)&Value, sizeof(DWORD)) != ERROR_SUCCESS)
	{
		//printf("Error with RegSetValueEx : %d\n", GetLastError());
		Ret = 0;
		goto cleanup;
	}
	
	Value = SERVICE_DEMAND_START;
	if(RegSetValueEx(hk, L"Start", 0, REG_DWORD, (LPBYTE)&Value, sizeof(DWORD)) != ERROR_SUCCESS)
	{
		//printf("Error with RegSetValueEx : %d\n", GetLastError());
		Ret = 0;
		goto cleanup;
	}

	Value = SERVICE_ERROR_NORMAL;
	if(RegSetValueEx(hk, L"ErrorControl", 0, REG_DWORD, (LPBYTE)&Value, sizeof(DWORD)) != ERROR_SUCCESS)
	{
		//printf("Error with RegSetValueEx : %d\n", GetLastError());
		Ret = 0;
		goto cleanup;
	}

	_snwprintf_s(wcBuffer, countof(wcBuffer), L"\\Registry\\Machine\\System\\CurrentControlSet\\Services\\%s", SymbolicLink);
	RtlInitUnicodeString(&usKey, wcBuffer);

	Status = ZwLoadDriver(&usKey);
	if(Status != STATUS_SUCCESS)
	{	
		//printf("Error with NtLoadDriver : 0x%x : %d \n", Status, RtlNtStatusToDosError(Status));
		Ret = 0;
	}

	SHDeleteKey(hk, L"Enum");
	SHDeleteKey(hk, L"Security");

cleanup:

	RegCloseKey(hk); 

	return Ret; 
}


DWORD UninstallDriver(PWCHAR SymbolicLink)
{
	DWORD Status, Ret = 1, Value = SERVICE_KERNEL_DRIVER;
	UNICODE_STRING usKey;
	HKEY hk;
	WCHAR wcBuffer[1024];

	_snwprintf_s(wcBuffer, countof(wcBuffer), L"\\Registry\\Machine\\System\\CurrentControlSet\\Services\\%s", SymbolicLink);
	RtlInitUnicodeString(&usKey, wcBuffer);

	Status = ZwUnloadDriver(&usKey);

	if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"SYSTEM\\CurrentControlSet\\Services", 0, KEY_ALL_ACCESS, &hk) != ERROR_SUCCESS)
	{
		//printf("Error with RegOpenKey : %d\n", GetLastError());
		return 0;
	}

	/*
	Deletes a subkey and all its descendants. 
	The function will remove the key and all of the key's values from the registry. 
	*/
	if(SHDeleteKey(hk, SymbolicLink) != ERROR_SUCCESS)
	{
		//printf("Error with SHDeleteKey : %d\n", GetLastError());
		Ret = 0;
	}

	RegCloseKey(hk); 

	return Ret;
}



BOOL device::load(BOOL hookDbgService)
{
	if (this->NtBuildNumber != 2600 && 
		this->NtBuildNumber != 6000 && 
		this->NtBuildNumber != 6001 && 
		this->NtBuildNumber != 6002 && 
		this->NtBuildNumber != 7600)
	{
		wcsncpy_s(this->errormsg, countof(this->errormsg), L"[Running OS is not supported]", _TRUNCATE);
		return false;
	};

	//SetThreadAffinityMask(GetCurrentThread(), 1);

	this->hookdbg = hookDbgService;

	UninstallDriver(this->symbolic);
	if (!InstallDriver(this->path, this->symbolic))
	{
		_snwprintf_s(this->errormsg, countof(this->errormsg), L"Cannot load the kernel driver !");
		return false;
	}
	
	WCHAR symb[countof(this->symbolic) + 4] = L"";
	_snwprintf_s(symb, countof(symb), L"\\\\.\\%s", this->symbolic);
	this->handle = CreateFile(symb, GENERIC_READ | GENERIC_WRITE, 0, 0, OPEN_EXISTING, 0, 0);
	if (INVALID_HANDLE_VALUE == this->handle)
	{
		_snwprintf_s(this->errormsg, countof(this->errormsg), L"Cannot open the kernel driver !");
		return false;
	}
	
	if (false == this->initiateDevice(hookDbgService))
	{
		_snwprintf_s(this->errormsg, countof(this->errormsg), L"Cannot initialize the kernel driver !");
		this->unload();
		return false;
	};
	return true;
};


void device::unload()
{
	if (this->handle && this->handle != INVALID_HANDLE_VALUE)
		CloseHandle(this->handle);
	UninstallDriver(this->symbolic);
};


long __fastcall device::syscall(IOCTL ioctl, void *buffer, BOOL naked)
{
	DWORD dwRet;
	UCHAR IoStatus[8];
	IO_INPUT_BUFFER IoBuffer;

	RtlZeroMemory(&IoBuffer, sizeof(IoBuffer));
	IoBuffer.Key = GetTickCount() + 'SIBA';
	IoBuffer.ControlCode[IoBuffer.Index] = (ULONG)ioctl ^ IoBuffer.Key;
	IoBuffer.InputBuffer[IoBuffer.Index] = (PVOID)((ULONG)buffer ^ IoBuffer.Key);

	if (naked == false) return DeviceIoControl(this->handle, CODE(CORE_IOCTL_INDEX), 0, 0, &IoBuffer, 0, &dwRet, 0);
	else return ZwDeviceIoControlFile(this->handle, 0, 0, 0, &IoStatus, CODE(CORE_IOCTL_INDEX), 0, 0, &IoBuffer, 0);
};


BOOL device::initiateDevice(BOOL hookDbgService)
{
	#define INIT_SUCCESS				0
	#define INIT_UNSUPPORTED_OS			1
	#define INIT_CANNOT_LOCATE_ITEMS	2
	#define INIT_CANNOT_LOCATE_KERNEL	3
	#define INIT_CANNOT_LOAD_KERNEL		4
#pragma pack(1)
	struct {
		PULONG IDT;
		PULONG NT;
		PULONG GDI;
		ULONG hookDbg;
		ULONG BuildNumber;
		PWCHAR KernelFileName;
		PWCHAR SystemrootPath;
	}INITIALIZE_BUFFER;
#pragma pack()
	WCHAR SystemrootPath[MAX_PATH];

	GetWindowsDirectoryW(SystemrootPath, MAX_PATH);
	INITIALIZE_BUFFER.IDT = this->RealIdt;
	INITIALIZE_BUFFER.NT = this->NT;
	INITIALIZE_BUFFER.GDI = this->GDI;
	INITIALIZE_BUFFER.hookDbg = hookDbgService;
	INITIALIZE_BUFFER.BuildNumber = this->NtBuildNumber;
	INITIALIZE_BUFFER.KernelFileName = this->KernelFileName;
	INITIALIZE_BUFFER.SystemrootPath = SystemrootPath;
	long result = this->syscall(IOCTL_INITIALIZE, &INITIALIZE_BUFFER, true);
	switch (result)
	{
	case INIT_SUCCESS:
		{
			_snwprintf_s(FixedKernelName, countof(FixedKernelName), L"\\Systemroot\\system32\\%s", this->KernelFileName);
			BasicKernelFiles[0] = FixedKernelName;
			return true;
		};
	case INIT_UNSUPPORTED_OS:
		{
			wcsncpy_s(this->errormsg, countof(this->errormsg), L"[Running OS is not supported]", _TRUNCATE);
			return false;
		};
	case INIT_CANNOT_LOCATE_ITEMS:
		{
			wcsncpy_s(this->errormsg, countof(this->errormsg), L"[Cannot locate essential kernel variables]", _TRUNCATE);
			return false;
		};
	case INIT_CANNOT_LOCATE_KERNEL:
		{
			wcsncpy_s(this->errormsg, countof(this->errormsg), L"[Cannot find kernel BaseAddress]", _TRUNCATE);
			return false;
		};
	case INIT_CANNOT_LOAD_KERNEL:
		{
			wcsncpy_s(this->errormsg, countof(this->errormsg), L"[Cannot load/open kernel file]", _TRUNCATE);
			return false;
		};
	default:
		wcsncpy_s(this->errormsg, countof(this->errormsg), L"[Unknown error]", _TRUNCATE);
		return false;
	};
};


WCHAR **device::getServiceNames(void)
{
	//__asm int 3;
	unsigned long ntdll = (unsigned long)GetModuleHandle(L"ntdll.dll");
	PIMAGE_NT_HEADERS nt = (PIMAGE_NT_HEADERS)
		(ntdll + ((PIMAGE_DOS_HEADER)ntdll)->e_lfanew);
	void *rc = malloc(nt->OptionalHeader.SizeOfImage);
	RtlCopyMemory(rc, (void *)ntdll, nt->OptionalHeader.SizeOfHeaders);
	PIMAGE_SECTION_HEADER sec = IMAGE_FIRST_SECTION(nt);
	WCHAR systempath[MAX_PATH] = L"";
	GetSystemDirectory(systempath, sizeof(systempath));
	wcsncat_s(systempath, countof(systempath), L"\\ntdll.dll", _TRUNCATE);
	HANDLE handle = CreateFile(systempath, GENERIC_READ, FILE_SHARE_READ, 0, OPEN_EXISTING, 0, 0);
	if (INVALID_HANDLE_VALUE == handle) return 0;
	unsigned long FileCopy = (unsigned long)malloc(GetFileSize(handle, 0));
	unsigned long dwret;
	ReadFile(handle, (void *)FileCopy, GetFileSize(handle, 0), &dwret, 0);
	CloseHandle(handle);
	for (int c = 0; c < nt->FileHeader.NumberOfSections; ++c)
	{
		RtlCopyMemory(
			(PVOID)((unsigned long)rc + sec[c].VirtualAddress),
			(PVOID)(FileCopy + sec[c].PointerToRawData),
			sec[c].SizeOfRawData);
	};
	ntdll = (unsigned long)rc;
	free((void *)FileCopy);

	WCHAR **result = new WCHAR*[this->NTmax];
	for (unsigned long i = 0; i < this->NTmax; ++i) result[i] = L"Unknown Service !";
	PIMAGE_NT_HEADERS ntheader = (PIMAGE_NT_HEADERS)(((PIMAGE_DOS_HEADER)ntdll)->e_lfanew + ntdll);
	PIMAGE_EXPORT_DIRECTORY exp = (PIMAGE_EXPORT_DIRECTORY)(ntheader->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress + ntdll);
	CHAR **stringRva = (CHAR **)(exp->AddressOfNames + ntdll);
	unsigned short *ordinals = (unsigned short *)(exp->AddressOfNameOrdinals + ntdll);
	unsigned long *exportRva = (unsigned long *)(exp->AddressOfFunctions + ntdll);
	for (unsigned long i = 0; i < exp->NumberOfNames; ++i)
	{
		unsigned long function = exportRva[ordinals[i]] + ntdll;
		CHAR *string = stringRva[i] + ntdll;
		if (*((unsigned char *)function) == 0xb8 && *((unsigned char *)function + 5) == 0xba && 
			*((unsigned char *)function + 10) == 0xff && *((unsigned char *)function + 11) == 0x12 &&
			(*((unsigned char *)function + 12)&0xc0) == 0xc0)
		{
			if (string[0] == 'N' && string[1] == 't')
			{
				unsigned long serviceId = *(unsigned long *)(function + 1);
				if (serviceId < this->NTmax)
				{
					result[serviceId] = new WCHAR [100];
					_snwprintf_s(result[serviceId], 100, _TRUNCATE, L"%S", string);
				}
			};
		};
	};
	return result;
};


LPSDT device::enumSdt(long &count)
{
	struct {LPSDT sdt; long count;}pm = {0,0};
	LPSDT sdt;
	this->syscall(IOCTL_ENUM_SSDT, &pm);
	sdt = new SDT[pm.count];
	RtlCopyMemory(sdt, pm.sdt, sizeof(SDT)*pm.count);
	count = pm.count;
	VirtualFree(pm.sdt, 0, MEM_RELEASE);
	return sdt;
};


LPSDT device::enumSdtShadow(long &count)
{
	struct {LPSDT sdt; long count;}pm = {0,0};
	LPSDT sdt;
	this->syscall(IOCTL_ENUM_SHADOW_SSDT, &pm);
	sdt = new SDT[pm.count];
	RtlCopyMemory(sdt, pm.sdt, sizeof(SDT)*pm.count);
	count = pm.count;
	VirtualFree(pm.sdt, 0, MEM_RELEASE);
	return sdt;
};


LPPROCESS device::enumProcesses(long &count, unsigned long uflags)
{
	struct {LPPROCESS processes; long count; unsigned long uflags;}pm = {0,0,uflags};
	if (this->processes) VirtualFree(this->processes, 0, MEM_RELEASE);
	this->syscall(IOCTL_ENUM_PROCESS, &pm);
	this->processes = pm.processes;
	this->processes_count = count = pm.count;
	return this->processes;
};


LPTHREAD_INFO device::enumThreads(unsigned long process, ULONG &count, unsigned long uflags)
{
	struct {LPTHREAD_INFO threads; unsigned long process; long count; unsigned long uflags;}pm = {0,process,0,uflags};
	LPTHREAD_INFO threads;
	this->syscall(IOCTL_ENUM_THREADS, &pm);
	threads = new THREAD_INFO[pm.count];
	RtlCopyMemory(threads, pm.threads, sizeof(THREAD_INFO) * pm.count);
	count = pm.count;
	VirtualFree(pm.threads, 0, MEM_RELEASE);
	return threads;
};


LPDRIVER device::enumDrivers(long &count)
{
	struct {LPDRIVER drivers; long count;}pm = {0,0};
	LPDRIVER drivers;
	this->syscall(IOCTL_ENUM_DRIVER, &pm);
	drivers = new DRIVER[pm.count];
	RtlCopyMemory(drivers, pm.drivers, sizeof(DRIVER)*pm.count);
	count = pm.count;
	VirtualFree(pm.drivers, 0, MEM_RELEASE);
	return drivers;
};


void **device::enumDevices(long &count)
{
	struct {void **devices; long count;}pm = {0,0};
	PVOID *devices;
	this->syscall(IOCTL_ENUM_DEVICES, &pm);
	devices = new PVOID[pm.count];
	RtlCopyMemory(devices, pm.devices, sizeof(PVOID)*pm.count);
	count = pm.count;
	VirtualFree(pm.devices, 0, MEM_RELEASE);
	return devices;
};


LPDRIVER device::getDriverInfo(unsigned long driver)
{
	DRIVER DriverInfo = {0};
	struct {unsigned long driver; DRIVER *DriverInfo;}pm = {driver, &DriverInfo};
	if (this->syscall(IOCTL_GET_DRIVER_INFO, &pm))
	{
		DRIVER *dwResult = new DRIVER;
		*dwResult = DriverInfo;
		return dwResult;
	}
	else
	{
		return NULL;
	}
};


wchar_t *device::getObjectName(unsigned long object)
{
	struct {unsigned long object; wchar_t *objectName;}pm = {object, 0};
	wchar_t *objectName = new wchar_t[MAX_PATH];
	RtlZeroMemory(objectName, MAX_PATH * sizeof(wchar_t));
	pm.objectName = objectName;
	if (this->syscall(IOCTL_GET_OBJECT_NAME, &pm))
	{
		return objectName;
	}
	else
	{
		delete[] objectName;
		return NULL;
	}
};


LPHOOKED_BLOCK device::enumKernelHooks(WCHAR * path, ULONG &count, unsigned long uflags)
{
	struct {LPHOOKED_BLOCK hook_info; long count; WCHAR *path; unsigned long uflags;}pm = {0,0,path,uflags};
	LPHOOKED_BLOCK hook_info;
	this->syscall(IOCTL_ENUM_HOOKS, &pm);
	hook_info = new HOOKED_BLOCK[pm.count];
	RtlCopyMemory(hook_info, pm.hook_info, sizeof(HOOKED_BLOCK)*pm.count);
	count = pm.count;
	VirtualFree(pm.hook_info, 0, MEM_RELEASE);
	return hook_info;
};


PKIDTENTRY device::enumIdt(long cpu)
{
	void *pm = 0;
	PKIDTENTRY idt;
	DWORD_PTR Affinity;

	Affinity = SetThreadAffinityMask(GetCurrentThread(), 1 << cpu);
	this->syscall(IOCTL_ENUM_IDT, &pm);
	SetThreadAffinityMask(GetCurrentThread(), Affinity);
	idt = new KIDTENTRY[256];
	RtlCopyMemory(idt, pm, sizeof(KIDTENTRY)*256);
	VirtualFree(pm, 0, MEM_RELEASE);
	return idt;
};


PHANDLE_INFORMATION device::enumHandles(unsigned long process, long &count)
{
	struct {PHANDLE_INFORMATION handles; unsigned long process; long count;}pm = {0,process,0};
	PHANDLE_INFORMATION handles;
	if (!this->syscall(IOCTL_ENUM_HANDLES, &pm)) return 0;
	handles = new HANDLE_INFORMATION[pm.count];
	RtlCopyMemory(handles, pm.handles, sizeof(HANDLE_INFORMATION)*pm.count);
	count = pm.count;
	VirtualFree(pm.handles, 0, MEM_RELEASE);
	return handles;
};


ULONG __inline alignNumber(ULONG number, ULONG alignment)
{
	return (ULONG)(ceil(number / (alignment + 0.0)) * alignment);
}


BOOL device::readVM(unsigned long process, void *address, void *buffer, unsigned long size)
{
	struct {
		unsigned long	process;
		void			*address;
		void			*buffer;
		unsigned long	size;
		unsigned long	*lpNumberOfBytesRW;
	} param;
	param.process = process;
	param.address = address;
	param.buffer = buffer;
	param.size = size;
	param.lpNumberOfBytesRW = 0;
	RtlZeroMemory(buffer, size);
	return this->syscall(IOCTL_VM_READ, &param);
};


BOOL device::writeVM(unsigned long process, void *address, void *buffer, unsigned long size)
{
	struct {
		unsigned long	process;
		void			*address;
		void			*buffer;
		unsigned long	size;
		unsigned long	*lpNumberOfBytesRW;
	} param;
	param.process = process;
	param.address = address;
	param.buffer = buffer;
	param.size = size;
	param.lpNumberOfBytesRW = 0;
	return this->syscall(IOCTL_VM_WRITE, &param);
};


BOOL device::readPhysicalPages(PLARGE_INTEGER pfn, void *buffer, unsigned long nPages)
{
	unsigned long param[3] = {(unsigned long)pfn, (unsigned long)buffer, nPages};
	return this->syscall(IOCTL_PHYSICAL_PAGE_READ, &param);
};


BOOL device::writePhysicalPages(PLARGE_INTEGER pfn, void *buffer, unsigned long nPages)
{
	unsigned long param[3] = {(unsigned long)pfn, (unsigned long)buffer, nPages};
	return this->syscall(IOCTL_PHYSICAL_PAGE_WRITE, &param);
};


void *device::updateVM(unsigned long address, unsigned long size)
{
	if (this->readbuffer) delete[] (void *) this->readbuffer;
	this->readbuffer = (unsigned long) new unsigned char[alignNumber(size, 16)];
	this->readaddress = address;
	this->readsize = alignNumber(size, 16);
	return (void *) this->readbuffer;
};


void *device::getVMaddress()
{
	return (void *)this->readaddress;
};


unsigned long device::getVMsize()
{
	return this->readsize;
};


void *device::getVMbuffer()
{
	return (void *)this->readbuffer;
};


void *device::allocVM(unsigned long process, unsigned long size)
{
	unsigned long param[3] = {process, size, 0};
	this->syscall(IOCTL_ALLOCATE_PROCESS_VM, &param);
	return (void *)param[2];
};


void device::freeVM(unsigned long process, void *address, unsigned long size)
{
	unsigned long param[3] = {process, (unsigned long)address, size};
	this->syscall(IOCTL_DEALLOCATE_PROCESS_VM, &param);
};


BOOL device::protectVM(unsigned long process, void *address, unsigned long size, unsigned long newCode, unsigned long *oldCode)
{
	unsigned long param[5] = {process, (unsigned long)address, size, newCode, (unsigned long)oldCode};
	return this->syscall(IOCTL_PROTECT_PROCESS_VM, &param);
};


BOOL device::queryVM(unsigned long process, void *address, PMEMORY_BASIC_INFORMATION buffer, unsigned long size)
{
	unsigned long param[4] = {process, (unsigned long)address, (unsigned long)buffer, size};
	return this->syscall(IOCTL_QUERY_PROCESS_VM, &param);
};


BOOL device::unmapSection(unsigned long process, void *base)
{
	unsigned long param[2] = {process, (unsigned long)base};
	return this->syscall(IOCTL_UNMAP_SECTION, &param);
};


HANDLE device::getProcessHandle(unsigned long process, unsigned long pid)
{
	unsigned long param[3] = {process, pid, 0};
	this->syscall(IOCTL_PROCESS_OPEN, &param);
	return (HANDLE)param[2];
};


HANDLE device::getThreadHandle(unsigned long thread, unsigned long tid)
{
	unsigned long param[3] = {thread, tid, 0};
	this->syscall(IOCTL_THREAD_OPEN, &param);
	return (HANDLE)param[2];
};


WCHAR *device::getObjectType(void *object, WCHAR *objectname)
{
	void *param[2] = {object, objectname};
	this->syscall(IOCTL_GET_OBJECT_TYPE, &param);
	return objectname;
};


LPTHREAD_INFO device::threadToProcess(unsigned long thread, LPPROCESS process, LPTHREAD_INFO thread_info)
{
	struct {unsigned long thread; LPPROCESS process; LPTHREAD_INFO thread_info;}pm = {thread,process,thread_info};
	this->syscall(IOCTL_THREAD_TO_PROCESS, &pm);
	return thread_info;
};


BOOL device::closeHandle(HANDLE handle, unsigned long process, unsigned long pid)
{
	struct {HANDLE handles; unsigned long process; unsigned long pid;}pm = {handle,process,pid};
	return this->syscall(IOCTL_CLOSE_HANDLE, &pm);
};


unsigned long device::getEntrypoint(unsigned long process, unsigned long imagebase)
{
	unsigned long ntoffset = 0;
	unsigned long ep = 0;
	if (this->readVM(process, (void *)(imagebase + 0x3c), &ntoffset, sizeof(ntoffset)))
	{
		this->readVM(process, (void *)(imagebase + ntoffset + 0x28), &ep, sizeof(ep));
		return (ep + imagebase);
	};
	return 0;
};


BOOL device::forceKillProcess(unsigned long process)
{
	return this->syscall(IOCTL_PROCESS_KILL_FORCE, &process);
};


BOOL device::forceKillThread(unsigned long thread)
{
	return this->syscall(IOCTL_THREAD_KILL_FORCE, &thread);
};


BOOL device::suspendProcess(unsigned long process)
{
	return this->syscall(IOCTL_PROCESS_SUSPEND, &process);
};


BOOL device::suspendThread(unsigned long thread)
{
	return this->syscall(IOCTL_THREAD_SUSPEND, &thread);
};


BOOL device::resumeProcess(unsigned long process, BOOL force)
{
	struct {unsigned long process; LONG force;}u = {process, force};
	return this->syscall(IOCTL_PROCESS_RESUME, &u);
};


BOOL device::resumeThread(unsigned long thread, BOOL force)
{
	struct {unsigned long thread; LONG force;}u = {thread, force};
	return this->syscall(IOCTL_THREAD_RESUME, &u);
};


BOOL device::captureStackContext(unsigned long thread, PCONTEXT Context)
{
	struct {unsigned long thread; PCONTEXT Context;}u = {thread, Context};
	return syscall(IOCTL_ENUM_THREAD_TRACE, &u);
};


BOOL device::getThreadContext(unsigned long thread, PCONTEXT context)
{
	struct {unsigned long thread; PCONTEXT context;}u = {thread, context};
	return syscall(IOCTL_GET_THREAD_CONTEXT, &u);
};


BOOL device::setThreadContext(unsigned long thread, PCONTEXT context)
{
	struct {unsigned long thread; PCONTEXT context;}u = {thread, context};
	return syscall(IOCTL_SET_THREAD_CONTEXT, &u);
};


BOOL device::deleteFile(WCHAR *filename, BOOL forcedelete)
{
	struct {WCHAR *filename; LONG forcedelete;}u = {filename, forcedelete};
	return this->syscall(IOCTL_DELETE_FILE, &u); 
};


BOOL device::copyFile(WCHAR *source, WCHAR *dest)
{
	struct {WCHAR *source; WCHAR *dest;}u = {source, dest};
	return this->syscall(IOCTL_COPY_FILE, &u); 
};


void *device::hookIntOffset(long index, void *address, unsigned char cpu)
{
	unsigned long param[2] = {index, (unsigned long)address};
	DWORD_PTR Affinity;

	Affinity = SetThreadAffinityMask(GetCurrentThread(), 1 << cpu);
	this->syscall(IOCTL_IDT_OFFSET, &param);
	SetThreadAffinityMask(GetCurrentThread(), Affinity);
	return (void *)param[1];
};


void *device::hookIntSelector(long index, void *selector, unsigned char cpu)
{
	unsigned long param[2] = {index, (unsigned long)selector};
	DWORD_PTR Affinity;

	Affinity = SetThreadAffinityMask(GetCurrentThread(), 1 << cpu);
	this->syscall(IOCTL_IDT_SELECTOR, &param);
	SetThreadAffinityMask(GetCurrentThread(), Affinity);
	return (void *)param[1];
};


unsigned long device::getNTcount() 
{
	return this->NTmax;
};


unsigned long device::getGDIcount()
{
	return this->GDImax;
};


BOOL device::isdbghooked()
{
	return this->hookdbg;
};


WCHAR *device::getModulePath(unsigned long address, WCHAR *module, unsigned long nCount)
{
	WCHAR *buffer = new WCHAR[512];
	WCHAR *symbol = new WCHAR[512];
	unsigned long disp;

	RtlZeroMemory(buffer, sizeof(WCHAR) * 512);
	RtlZeroMemory(symbol, sizeof(WCHAR) * 512);
	RtlZeroMemory(module, sizeof(WCHAR) * nCount);
	((PULONG)buffer)[0] = address;
	((PULONG)buffer)[1] = FALSE;
	this->syscall(IOCTL_GET_MODULE, buffer);
	if (buffer[0] != '-' && this->decodesymbol(address, disp, symbol))
	{
		_snwprintf_s(module, nCount, _TRUNCATE, disp ? L"%s::%s+%x" : L"%s::%s", buffer, symbol, disp);
	}
	else if (this->decodesymbol(address, disp, symbol))
	{
		_snwprintf_s(module, nCount, _TRUNCATE, disp ? L"%s+%x" : L"%s", symbol, disp);
	}
	else
	{
		wcsncpy_s(module, nCount, buffer, _TRUNCATE);
	}
	delete[] buffer;
	delete[] symbol;
	return module;
};


WCHAR *device::getError()
{
	return this->errormsg;
};


BOOL CALLBACK SymEnumSymbolsProc(PCWSTR SymbolName, ULONG SymbolAddress, ULONG SymbolSize, PVOID UserContext)
{
	if (((PCHAR)SymbolName)[1] != '\0')
	{
		PCHAR SymbolNameA = (PCHAR)SymbolName;
		unsigned long lstr = strlen(SymbolNameA) + 1;
		WCHAR *string = new WCHAR [lstr];
		RtlZeroMemory(string, lstr * sizeof(WCHAR));
		++sym_count;
		sym_strings = (WCHAR **)realloc(sym_strings, 4 * sym_count);
		sym_addresses = (unsigned long *)realloc(sym_addresses, 4 * sym_count);
		_snwprintf_s(string, lstr, _TRUNCATE, L"%S", SymbolNameA);
		sym_strings[sym_count - 1] = string;
		sym_addresses[sym_count - 1] = SymbolAddress;
	}
	else
	{
		unsigned long lstr = wcslen(SymbolName) + 1;
		WCHAR *string = new WCHAR [lstr];
		RtlZeroMemory(string, lstr * sizeof(WCHAR));
		++sym_count;
		sym_strings = (WCHAR **)realloc(sym_strings, 4 * sym_count);
		sym_addresses = (unsigned long *)realloc(sym_addresses, 4 * sym_count);
		wcsncpy_s(string, lstr, SymbolName, _TRUNCATE);
		sym_strings[sym_count - 1] = string;
		sym_addresses[sym_count - 1] = SymbolAddress;
	}
	return true;
};


BOOL device::decodesymbol(unsigned long address, unsigned long &disp, WCHAR *symbol, BOOL decodemodule)
{
	WCHAR buffer[MAX_SYM_NAME + sizeof(SYMBOL_INFO)] = {0};
	PSYMBOL_INFO lpSymbol = (PSYMBOL_INFO)buffer;
	IMAGEHLP_MODULEW ModuleInfo;


	RtlZeroMemory(&ModuleInfo, sizeof(ModuleInfo));
	ModuleInfo.SizeOfStruct = sizeof(ModuleInfo);
	SymGetModuleInfoW(NtCurrentProcess(), address, &ModuleInfo);
	symbol[0] = '\0';
	disp = 0;
	if (!ModuleInfo.BaseOfImage) {
		WCHAR kernel_module[MAX_SYM_NAME];
		((PULONG)kernel_module)[0] = address;
		((PULONG)kernel_module)[1] = TRUE;
		this->syscall(IOCTL_GET_MODULE, kernel_module);
		if (kernel_module[0] == '-') return false;
		wcsncpy_s(symbol, MAX_PATH, kernel_module, _TRUNCATE);
		return true;
	};

	lpSymbol->SizeOfStruct = sizeof(SYMBOL_INFOW);
	lpSymbol->MaxNameLen = MAX_SYM_NAME;
	for (unsigned long c = 0; c < this->NTmax; ++c)
	{
		if (address >= this->NT[c] && address < this->NT[c] + 16)
		{
			if (decodemodule) _snwprintf_s(symbol, 512, _TRUNCATE, L"%s.%s", ModuleInfo.ModuleName, this->ServiceTable[c]);
			else _snwprintf_s(symbol, 512, _TRUNCATE, L"%s", this->ServiceTable[c]);
			disp = address - this->NT[c];
			return true;
		};
	};

	for (unsigned long c = 0; c < this->GDImax; ++c)
	{
		if (address >= this->GDI[c] && address < this->GDI[c] + 16)
		{
			if (decodemodule) _snwprintf_s(symbol, 512, _TRUNCATE, L"%s.%s", ModuleInfo.ModuleName, this->ShadowServiceTable[c]);
			else _snwprintf_s(symbol, 512, _TRUNCATE, L"%s", this->ShadowServiceTable[c]);
			disp = address - this->GDI[c];
			return true;
		};
	};

	
	unsigned long temp_ptr = 0;
	BOOL temp_found = false;
	for (unsigned long c = 0; c < sym_count; ++c)
	{
		if (address >= sym_addresses[c] && address < sym_addresses[c] + 16)
		{
			if (!temp_found) {
				temp_found = true;
				temp_ptr = c;
			} else {
				if (sym_addresses[temp_ptr]-address > sym_addresses[c]-address) temp_ptr = c;
			};
		};
	};

	if (temp_found)
	{
		if (decodemodule) _snwprintf_s(symbol, 512, _TRUNCATE, L"%s.%s", ModuleInfo.ModuleName, sym_strings[temp_ptr]);
		else _snwprintf_s(symbol, 512, _TRUNCATE, L"%s", sym_strings[temp_ptr]);
		disp = address - sym_addresses[temp_ptr];
		return true;
	};
	

	return false;
};


DWORD64
WINAPI
SymLoadModuleW(
    __in HANDLE hProcess,
    __in_opt HANDLE hFile,
    __in_opt PCWSTR ImageNameW,
    __in_opt PCWSTR ModuleNameW,
    __in DWORD64 BaseOfDll,
    __in DWORD SizeOfDll
    )
{
	CHAR ImageName[512] = "";
	CHAR ModuleName[512] = "";

	_snprintf_s(ImageName, countof(ImageName), _TRUNCATE, "%S", ImageNameW);
	_snprintf_s(ModuleName, countof(ModuleName), _TRUNCATE, "%S", ModuleNameW);
	return SymLoadModule64(hProcess, hFile, ImageName, ModuleName, BaseOfDll, SizeOfDll);
}


void device::initiate_symbols(void)
{
	void *driverBase[1024] = {0};
	unsigned long dummy = 0;
	unsigned long count = 0;
	unsigned long k = 0;
	WCHAR Systempath[MAX_PATH] = L"";
	WCHAR ModulePath[1024];
	PVOID SymInitializeA;


	sym_strings = (WCHAR **)malloc(0);
	sym_addresses = (unsigned long *)malloc(0);
	SymSetOptions(SYMOPT_FAIL_CRITICAL_ERRORS | SYMOPT_UNDNAME);
	SymInitializeA = GetProcAddress(GetModuleHandle(L"dbghelp.dll"), "SymInitialize");
	if (!SymInitializeA) return;
	__asm
	{
		push FALSE
		push NULL
		push -1
		call SymInitializeA
	}
	EnumDeviceDrivers((PVOID *)&driverBase, sizeof(driverBase), &dummy);
	count = dummy / sizeof(ULONG);
	GetSystemDirectory(Systempath, sizeof(Systempath));
	for (int c = 0; c < sizeof(kernels_file) / sizeof(WCHAR *); ++c)
	{
		if (c < 7)
		{
			_snwprintf_s(ModulePath, sizeof(ModulePath), L"%s%s", Systempath, kernels_path[c]);
			kernels_base[c] = (ULONG)LoadLibrary(ModulePath);
			SymLoadModuleW(NtCurrentProcess(), 0, ModulePath, 0, kernels_base[c], 0);
			SymEnumerateSymbolsW(NtCurrentProcess(), kernels_base[c], SymEnumSymbolsProc, 0);
		} 
		else
		{
			for (unsigned long j = 0; j < count; ++j)
			{
				WCHAR devicefile[64] = L"";
				GetDeviceDriverBaseName(driverBase[j], devicefile, sizeof(devicefile));
				if (!_wcsnicmp(devicefile, kernels_file[c], wcslen(kernels_file[c])))
				{
					kernels_base[c] = (unsigned long)driverBase[j];
					_snwprintf_s(ModulePath, sizeof(ModulePath), L"%s%s", Systempath, kernels_path[c]);
					SymLoadModuleW(NtCurrentProcess(), 0, ModulePath, 0, kernels_base[c], 0);
					SymEnumerateSymbolsW(NtCurrentProcess(), kernels_base[c], SymEnumSymbolsProc, 0);
					break;
				};
			};
		};
	};
};


void device::free_symbols(void)
{
	for (int c = 0; c < sizeof(kernels_file) / sizeof(WCHAR *); ++c)
	{
		SymUnloadModule64(NtCurrentProcess(), kernels_base[c]);
	};

	for (unsigned long c = 0; c < sym_count; ++c)
	{
		free(sym_strings[c]);
	};

	free(sym_addresses);
	free(sym_strings);

	SymCleanup(NtCurrentProcess());
};