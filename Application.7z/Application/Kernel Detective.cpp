#include	"Kernel Detective.h"
#include	"disasm.h"
#include	"SSDT.h"
#include	"ShadowSSDT.h"
#include	"IDT.h"
#include	"DebugView.h"
#include	"pdk.h"


HINSTANCE	hInstance;
opts		settings;
HWND		gWin;
HWND		hTab;
STATUS_BAR	status;




BOOL EnablePriv(PWCHAR lpszPriv)
{
    HANDLE hToken;
    LUID luid;
    TOKEN_PRIVILEGES tkprivs;
    ZeroMemory(&tkprivs, sizeof(tkprivs));
  
    if(!OpenProcessToken(GetCurrentProcess(), (TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY), &hToken))
        return FALSE;
  
    if(!LookupPrivilegeValue(NULL, lpszPriv, &luid))
	{
        CloseHandle(hToken);
		return FALSE;
    };
  
    tkprivs.PrivilegeCount = 1;
    tkprivs.Privileges[0].Luid = luid;
    tkprivs.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
  
    BOOL bRet = AdjustTokenPrivileges(hToken, FALSE, &tkprivs, sizeof(tkprivs), NULL, NULL);
    CloseHandle(hToken);
    return bRet;
}


int GenerateDump(EXCEPTION_POINTERS* pExceptionPointers)
{
    WCHAR szFileName[MAX_PATH];
    HANDLE hDumpFile;
    SYSTEMTIME stLocalTime;
    MINIDUMP_EXCEPTION_INFORMATION ExpParam;

    GetLocalTime(&stLocalTime);

    _snwprintf(szFileName, MAX_PATH,
               AppName L" Minidump [%04d-%02d-%02d]-[%02d-%02d-%02d].dmp",
               stLocalTime.wYear, stLocalTime.wMonth, stLocalTime.wDay, 
               stLocalTime.wHour, stLocalTime.wMinute, stLocalTime.wSecond);
    hDumpFile = CreateFile(szFileName, GENERIC_READ|GENERIC_WRITE, 
                FILE_SHARE_WRITE|FILE_SHARE_READ, 0, CREATE_ALWAYS, 0, 0);

    ExpParam.ThreadId = GetCurrentThreadId();
    ExpParam.ExceptionPointers = pExceptionPointers;
    ExpParam.ClientPointers = TRUE;

    PWCHAR errMsg = L"Unhandled exception raised, Kernel Detective will generate crash dump file\r\n"
                    L"Please send this file to author\r\n";
    MessageBox(NULL, errMsg, AppName, MB_OK | MB_ICONERROR);
    MiniDumpWriteDump(GetCurrentProcess(), GetCurrentProcessId(), hDumpFile, MiniDumpWithDataSegs, &ExpParam, NULL, NULL);

    return EXCEPTION_EXECUTE_HANDLER;
}




void rundialog()
{
	__try 
	{
		__try
		{
            InitializeSymbols();
			InitializePlugins();
			DialogBox(hInstance, MAKEINTRESOURCE(DLG_MAIN), 0, DlgProc);
		}
		__finally
		{
			DestroyPlugins();
            KeCleanup();
			CleanupSymbols();
		}
	}
    __except(GenerateDump(GetExceptionInformation()))
	{
		//Err(L"Unhandled exception raised, please contact author !\r\nKernel Detective will shutdown !");
	}
}


int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrevInstance,LPSTR lpCmdLine, int nCmdShow)
{
	int argc = 0;
	int debugv = FALSE;
	LPWSTR *argv = CommandLineToArgvW(GetCommandLineW(), &argc);
	WCHAR directory[MAX_PATH];


	hInstance = hInst;

	CreateMutex(NULL, FALSE, L"KeSiba");
	if (GetLastError() == ERROR_ALREADY_EXISTS)
	{
		Msg(L"Another instance of Kernel Detective is already running !");
		return EXIT_FAILURE;
	}

	for (long argn = 0; argn < argc; ++argn)
	{
		if (0 == wcsicmp(argv[argn], L"/Debugv"))
		{
			debugv = TRUE;
			break;
		}
	};

	// Raise Privilege
	if (!EnablePriv(L"SeDebugPrivilege")) Err(L"Cannot gain SeDebugPrivilege !");
	if (!EnablePriv(L"SeLoadDriverPrivilege")) Err(L"Cannot gain SeLoadDriverPrivilege !");

	// set disasm settings
	lowercase ++;
	farcalls ++;
	extraspace ++;
	showmemsize ++;
	decodevxd ++;
	privileged ++;
	iocommand  ++;
	extraprefix ++;
	lockedbus ++;
	badshift ++;
	stackalign ++;
	iswindowsnt ++;
	symbolic ++;
	
	

    WCHAR SysPath[MAX_PATH] = L"", DeviceName[MAX_PATH] = L"", RndDeviceName[MAX_PATH] = L"";
    GetModuleFileName(NULL, directory, COF(directory));
    _wsplitpath(directory, NULL, NULL, DeviceName, NULL);
    //Msg(DeviceName);
	POINT RndPoint;
	GetCursorPos(&RndPoint);
    GUID guid;
    if (S_OK == CoCreateGuid(&guid))
        _swprintf(RndDeviceName, L"{%08X-%04X-%04X-%02X%02X-%02X%02X%02X%02X%02X%02X}", guid.Data1, guid.Data2, guid.Data3, guid.Data4[0], guid.Data4[1], guid.Data4[2], guid.Data4[3], guid.Data4[4], guid.Data4[5], guid.Data4[6], guid.Data4[7]);
    else
        _swprintf(RndDeviceName, L"{%08X-%04X-%04X-%04X-%08X%04X}", GetTickCount(), GetCurrentThreadId() & 0xFFFF, GetCurrentProcessId() & 0xFFFF, GetTickCount() & 0xFFFF, RndPoint.y | RndPoint.x << 16, (RndPoint.x | RndPoint.y << 16)  & 0xFFFF);



	BOOL load_success;
//#define FINAL_VER
#ifdef FINAL_VER
	ULONG dwRet;
	GetModuleFileName(NULL, directory, COF(directory));
    _snwprintf(SysPath, COF(SysPath), L"%s%s.sys", PathToDirectory(directory), DeviceName);
	PVOID SYSFILE = LockResource(LoadResource(hInstance, FindResource(hInstance, L"DRV", L"BIN")));
	ULONG szSYS = SizeofResource(hInstance, FindResource(hInstance, L"DRV", L"BIN"));
	HANDLE hFile = CreateFile(SysPath, GENERIC_WRITE, 0, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
	if (hFile == INVALID_HANDLE_VALUE)
    {
        GetModuleFileName(NULL, directory, COF(directory));
        _snwprintf(SysPath, COF(SysPath), L"%s%s.sys", PathToDirectory(directory), RndDeviceName);
        hFile = CreateFile(SysPath, GENERIC_WRITE, 0, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
    }
    if (hFile != INVALID_HANDLE_VALUE && SYSFILE && szSYS)
	{
		WriteFile(hFile, SYSFILE, szSYS, &dwRet, 0);
		CloseHandle(hFile);
		load_success = KeInitialize(DeviceName, SysPath, debugv);
		DeleteFile(SysPath);
	}
	else
	{
		Err(L"Cannot extract the kernel-mode driver !");
		return EXIT_FAILURE;
	}
#else
	GetModuleFileName(NULL, directory, COF(directory));
    _snwprintf(SysPath, COF(SysPath), L"%s%s.sys", PathToDirectory(directory), L"KeDetective");
    load_success = KeInitialize(DeviceName, SysPath, debugv);
#endif

    if (load_success == INIT_CANNOT_LOAD_DRIVER)
    {
        KeCleanup();
        load_success = KeInitialize(RndDeviceName, SysPath, debugv);
    }
	if	(load_success != INIT_SUCCESS)
	{
        Err(ErrorMsg);
		return EXIT_FAILURE;
	}
	InitCommonControls();
	rundialog();
    return EXIT_SUCCESS;
}