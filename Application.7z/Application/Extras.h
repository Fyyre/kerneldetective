#pragma once
#include "Kernel Detective.h"


typedef INT_PTR (CALLBACK EXTRA_DLGPROC)(HWND, UINT, WPARAM, LPARAM, CListView *, STATUS_BAR *, HMENU);

EXTRA_DLGPROC DlgUnloadedDrivers;
EXTRA_DLGPROC DlgKTimer;
EXTRA_DLGPROC DlgObjectTypes;
EXTRA_DLGPROC DlgNotifyCallbacks;


#define ADD_MENU(_ID, _NAME) AppendMenu(HwndMenu, MF_STRING, _ID, _NAME)

#define ADD_MENU_SEP() AppendMenu(HwndMenu, MF_SEPARATOR, 0, NULL)

#define GOTO_ADDRESS(_ADDRESS)\
	{\
		if (_ADDRESS)\
		{\
            UpdateCommonBuffer(_ADDRESS, 0x400);\
            if (KiReadVirtualMemory(KiCurrentProcess.ProcessObject, GetCommonReadAddress(), GetCommonReadBuffer(), GetCommonReadSize()))\
			{\
				PrintDisasm(GetCommonReadBuffer(), GetCommonReadAddress(), GetCommonReadSize());\
				EndDialog(hWnd, 0);\
			}\
		}\
	}