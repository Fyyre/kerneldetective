#include "Extras.h"
#include "Disassemble.h"
#include "pdk.h"




//
// Miscellaneous kernel functions
//

typedef enum _KBUGCHECK_CALLBACK_REASON
{
    KbCallbackInvalid,
    KbCallbackReserved1,
    KbCallbackSecondaryDumpData,
    KbCallbackDumpIo,
} KBUGCHECK_CALLBACK_REASON;

typedef struct _BUGCHECK_CALLBACK
{
    PVOID Record;
    PVOID Routine;
    PVOID Buffer;
    KBUGCHECK_CALLBACK_REASON State;
    WCHAR Name[256];
} BUGCHECK_CALLBACK, *PBUGCHECK_CALLBACK;


INT_PTR CALLBACK DlgUnloadedDrivers(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam, CListView * ListView, STATUS_BAR *StatusBar, HMENU HwndMenu)
{
    KI_PACKET KiPacket;
    ULONG Count;
    PDRIVER_ENTRY Drivers;
    WCHAR Buffer[260];

    switch (message)
    {
    case WM_INITDIALOG:
        SetWindowText(hWnd, L"Unloaded Drivers");
        ListView->insertColumn(L"ImageBase", 80);
        ListView->insertColumn(L"Size", 80);
        ListView->insertColumn(L"Name", 350);
        Syscall(IOCTL_ENUM_UNLOADED_DRIVERS, &KiPacket);
        Drivers = (PDRIVER_ENTRY)KiPacket.Parameters.Common.Parameter1;
        Count = KiPacket.Parameters.Common.Parameter2;
        for (ULONG i = 0; i < Count; ++i)
        {
            _snwprintf_s(Buffer, COF(Buffer), L"0x%p", Drivers[i].ImageBase);
            ListView->insertRaw(Buffer, TRUE);
            _snwprintf_s(Buffer, COF(Buffer), L"0x%p", Drivers[i].ImageSize);
            ListView->insertRaw(Buffer, FALSE);
            ListView->insertRaw(Drivers[i].ImagePath, FALSE);
        }
        VirtualFree(Drivers, 0, MEM_RELEASE);
        StatusBar->Format(L"Unloaded Drivers Count = %d", Count);
        break;
    case WM_NOTIFY:
        if(((LPNMHDR)lParam)->code == NM_CUSTOMDRAW)
        {
            SetWindowLong(hWnd, DWL_MSGRESULT, (LONG)Listview_handler((LPNMLVCUSTOMDRAW)lParam, NULL, 0, 0, ListView));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
        break;
    default:
        return FALSE;
    }
    return TRUE;
}


VOID EnumKernelTimers(CListView * ListView, STATUS_BAR *StatusBar)
{
    KI_PACKET KiPacket;
    ULONG Count;
    PTIMER_ENTRY Timers;
    WCHAR Buffer[260];
    ULONG Status;
    SYSTEM_BASIC_INFORMATION SBI;


    ListView->clear();
    pNtQuerySystemInformation(SystemBasicInformation, &SBI, sizeof(SBI), NULL);
    Syscall(IOCTL_ENUM_TIMERS, &KiPacket);
    Timers = (PTIMER_ENTRY)KiPacket.Parameters.Common.Parameter1;
    Count = KiPacket.Parameters.Common.Parameter2;
	if (Timers)
	{
		UPDATE_MODULES();
		for (ULONG i = 0; i < Count; ++i)
		{
			Status = 0;
			_snwprintf_s(Buffer, COF(Buffer), L"0x%p", Timers[i].Object);
			ListView->insertRaw(Buffer, TRUE);
			_snwprintf_s(Buffer, COF(Buffer), L"%.8x : %.8x", Timers[i].Timer.DueTime.HighPart, Timers[i].Timer.DueTime.LowPart);
			ListView->insertRaw(Buffer, FALSE);
			_snwprintf_s(Buffer, COF(Buffer), L"%d", Timers[i].Timer.Period);
			ListView->insertRaw(Buffer, FALSE);
			_snwprintf_s(Buffer, COF(Buffer), L"0x%p", Timers[i].Timer.Dpc);
			ListView->insertRaw(Buffer, FALSE);
			decodethreadaddr(Buffer, (ULONG)Timers[i].Dpc.DeferredRoutine);
			ListView->insertRaw(Buffer, FALSE);
			if (Timers[i].Dpc.DeferredRoutine > (PVOID)SBI.HighestUserAddress)
			{
				if ('-' == *GetModulePath((ULONG)Timers[i].Dpc.DeferredRoutine, Buffer, COF(Buffer)))
				{
					Status = 1;
				}
			}
			if (Timers[i].Thread)
			{
				PROCESS_ENTRY ProcessInfo;
				THREAD_ENTRY ThreadInfo;
				WCHAR ThreadName[260];
				GetThreadProcessInformation(Timers[i].Thread, &ProcessInfo, &ThreadInfo);
				decodethreadaddr(ThreadName, (ULONG)ThreadInfo.Address);
				_snwprintf_s(Buffer, COF(Buffer), L"0x%p :: %s :: %s", Timers[i].Thread, PathToFileName(ProcessInfo.Name), ThreadName);
				ListView->insertRaw(Buffer, FALSE);
				if (ThreadInfo.Address > (PVOID)SBI.HighestUserAddress)
				{
					if ('-' == *GetModulePath((ULONG)ThreadInfo.Address, Buffer, 260))
					{
						Status = 2;
					}
				}
			}
			else
			{
				ListView->insertRaw(L"0x00000000", FALSE);
			}
			_snwprintf_s(Buffer, COF(Buffer), Timers[i].Timer.Header.SignalState ? L"Yes" : L"No");
			ListView->insertRaw(Buffer, FALSE);
			if (Status == 2)
			{
				ListView->insertRaw(L"Associated Thread running in unknown module", FALSE);
			}
			else if (Status == 1)
			{
				ListView->insertRaw(L"Associated DPC running in unknown module", FALSE);
			}
			else
			{
				ListView->insertRaw(L"-", FALSE);
			}
		}
		VirtualFree(Timers, 0, MEM_RELEASE);
	}
    StatusBar->Format(L"Timer Objects Count = %d", Count);
}


INT_PTR CALLBACK DlgKTimer(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam, CListView * ListView, STATUS_BAR *StatusBar, HMENU HwndMenu)
{
    KI_PACKET KiPacket;
    int wmId;

    switch (message)
    {
    case WM_INITDIALOG:
        SetWindowText(hWnd, L"Timer Objects");
        ListView->insertColumn(L"KTIMER", 80);
        ListView->insertColumn(L"Due Time (High:Low)", 120);
        ListView->insertColumn(L"Period", 120);
        ListView->insertColumn(L"Dpc", 80);
        ListView->insertColumn(L"Dpc Routine", 200);
        ListView->insertColumn(L"Thread", 200);
        ListView->insertColumn(L"Signaled", 80);
        ListView->insertColumn(L"Status", 200);

        ADD_MENU(1, L"Refresh");
        ADD_MENU_SEP();
        ADD_MENU(2, L"Cancel Timer");
        ADD_MENU_SEP();
        ADD_MENU(3, L"View Thread Object");
        ADD_MENU(4, L"Disassemble Dpc Routine");
        ADD_MENU(5, L"View KTIMER");
        ADD_MENU(6, L"View KDPC");

        EnumKernelTimers(ListView, StatusBar);
        break;

    case WM_COMMAND:
        wmId = LOWORD(wParam);
        switch (wmId)
        {
        case 1:
            EnumKernelTimers(ListView, StatusBar);
            break;
        case 2:
            KiPacket.Parameters.Common.Parameter1 = ListView->getSelUlong(0, 16);
            Syscall(IOCTL_CANCEL_TIMER, &KiPacket);
            EnumKernelTimers(ListView, StatusBar);
            break;
        case 3:
            GOTO_ADDRESS(ListView->getSelUlong(5, 16));
            break;
        case 4:
            GOTO_ADDRESS(ListView->getSelUlong(4, 16));
            break;
        case 5:
            GOTO_ADDRESS(ListView->getSelUlong(0, 16));
            break;
        case 6:
            GOTO_ADDRESS(ListView->getSelUlong(3, 16));
            break;
        default:
            return FALSE;
        }
        break;

    case WM_NOTIFY:
        if(((LPNMHDR)lParam)->code == NM_CUSTOMDRAW)
        {
            PWCHAR Warn[] =
            {
                L"Associated Thread running in unknown module",
                L"Associated DPC running in unknown module"
            };
            SetWindowLong(hWnd, DWL_MSGRESULT, (LONG)Listview_handler((LPNMLVCUSTOMDRAW)lParam, Warn, 2, 7, ListView));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
        break;
    default:
        return FALSE;
    }
    return TRUE;
}


VOID EnumKernelObjectTypes(CListView * ListView, STATUS_BAR *StatusBar)
{
    POBJECT_TYPE_ENTRY ObjectTypes;
    ULONG Count, KernelSize;
    PVOID KernelBase;
    WCHAR Buffer[260];


    ListView->clear();
    KernelBase = KdGetKernelBase();
    KernelSize = KdGetKernelSize();
    Count = EnumerateObjectTypes(&ObjectTypes);
    UPDATE_MODULES();
    for (ULONG i = 0; i < Count; ++i)
    {
        _snwprintf_s(Buffer, COF(Buffer), L"%u", ObjectTypes[i].Index);
        ListView->insertRaw(Buffer, TRUE);
        ListView->insertRaw(ObjectTypes[i].Name, FALSE);
        _snwprintf_s(Buffer, COF(Buffer), L"0x%p", ObjectTypes[i].Address);
        ListView->insertRaw(Buffer, FALSE);
        _snwprintf_s(Buffer, COF(Buffer), L"%u", ObjectTypes[i].Count);
        ListView->insertRaw(Buffer, FALSE);
        decodethreadaddr(Buffer, (ULONG)ObjectTypes[i].ProcedureTable.DumpProcedure);
        ListView->insertRaw(Buffer, FALSE);
        decodethreadaddr(Buffer, (ULONG)ObjectTypes[i].ProcedureTable.OpenProcedure);
        ListView->insertRaw(Buffer, FALSE);
        decodethreadaddr(Buffer, (ULONG)ObjectTypes[i].ProcedureTable.CloseProcedure);
        ListView->insertRaw(Buffer, FALSE);
        decodethreadaddr(Buffer, (ULONG)ObjectTypes[i].ProcedureTable.DeleteProcedure);
        ListView->insertRaw(Buffer, FALSE);
        decodethreadaddr(Buffer, (ULONG)ObjectTypes[i].ProcedureTable.ParseProcedure);
        ListView->insertRaw(Buffer, FALSE);
        decodethreadaddr(Buffer, (ULONG)ObjectTypes[i].ProcedureTable.SecurityProcedure);
        ListView->insertRaw(Buffer, FALSE);
        decodethreadaddr(Buffer, (ULONG)ObjectTypes[i].ProcedureTable.QueryNameProcedure);
        ListView->insertRaw(Buffer, FALSE);
        decodethreadaddr(Buffer, (ULONG)ObjectTypes[i].ProcedureTable.OkayToCloseProcedure);
        ListView->insertRaw(Buffer, FALSE);

        if ((!_wcsicmp(ObjectTypes[i].Name, L"Thread")) ||
                (!_wcsicmp(ObjectTypes[i].Name, L"Job")) ||
                (!_wcsicmp(ObjectTypes[i].Name, L"Timer")) ||
                (!_wcsicmp(ObjectTypes[i].Name, L"Process")) ||
                (!_wcsicmp(ObjectTypes[i].Name, L"Section")) ||
                (!_wcsicmp(ObjectTypes[i].Name, L"File")) ||
                (!_wcsicmp(ObjectTypes[i].Name, L"Driver")) ||
                (!_wcsicmp(ObjectTypes[i].Name, L"Device")) ||
                (!_wcsicmp(ObjectTypes[i].Name, L"Key")))
        {

            if (ObjectTypes[i].ProcedureTable.OpenProcedure && !(ObjectTypes[i].ProcedureTable.OpenProcedure > KernelBase && ObjectTypes[i].ProcedureTable.OpenProcedure < (PVOID)((ULONG_PTR)KernelBase + KernelSize)))
            {
                ListView->insertRaw(L"Open Procedure Hooked !", FALSE);
            }
            else if (ObjectTypes[i].ProcedureTable.DeleteProcedure && !(ObjectTypes[i].ProcedureTable.DeleteProcedure > KernelBase && ObjectTypes[i].ProcedureTable.DeleteProcedure < (PVOID)((ULONG_PTR)KernelBase + KernelSize)))
            {
                ListView->insertRaw(L"Delete Procedure Hooked !", FALSE);
            }
            else if (ObjectTypes[i].ProcedureTable.CloseProcedure && !(ObjectTypes[i].ProcedureTable.CloseProcedure > KernelBase && ObjectTypes[i].ProcedureTable.CloseProcedure < (PVOID)((ULONG_PTR)KernelBase + KernelSize)))
            {
                ListView->insertRaw(L"Close Procedure Hooked !", FALSE);
            }
            else if (ObjectTypes[i].ProcedureTable.ParseProcedure && !(ObjectTypes[i].ProcedureTable.ParseProcedure > KernelBase && ObjectTypes[i].ProcedureTable.ParseProcedure < (PVOID)((ULONG_PTR)KernelBase + KernelSize)))
            {
                ListView->insertRaw(L"Parse Procedure Hooked !", FALSE);
            }
            else if (ObjectTypes[i].ProcedureTable.SecurityProcedure && !(ObjectTypes[i].ProcedureTable.SecurityProcedure > KernelBase && ObjectTypes[i].ProcedureTable.SecurityProcedure < (PVOID)((ULONG_PTR)KernelBase + KernelSize)))
            {
                ListView->insertRaw(L"Security Procedure Hooked !", FALSE);
            }
            else if (ObjectTypes[i].ProcedureTable.QueryNameProcedure && !(ObjectTypes[i].ProcedureTable.QueryNameProcedure > KernelBase && ObjectTypes[i].ProcedureTable.QueryNameProcedure < (PVOID)((ULONG_PTR)KernelBase + KernelSize)))
            {
                ListView->insertRaw(L"Query Name Procedure Hooked !", FALSE);
            }
            else
            {
                ListView->insertRaw(L"-", FALSE);
            }
        }
        else
        {
            ListView->insertRaw(L"-", FALSE);
        }
    }
    VirtualFree(ObjectTypes, 0, MEM_RELEASE);
    StatusBar->Format(L"Object Types Count = %d", Count);
}


INT_PTR CALLBACK DlgObjectTypes(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam, CListView * ListView, STATUS_BAR *StatusBar, HMENU HwndMenu)
{
    KI_PACKET KiPacket;
    int wmId;

    switch (message)
    {
    case WM_INITDIALOG:
        SetWindowText(hWnd, L"Object Types");

        ListView->insertColumn(L"Index", 60);
        ListView->insertColumn(L"Name", 150);
        ListView->insertColumn(L"Address", 80);
        ListView->insertColumn(L"TotalObjects", 80);
        ListView->insertColumn(L"DumpProcedure", 150);
        ListView->insertColumn(L"OpenProcedure", 150);
        ListView->insertColumn(L"CloseProcedure", 150);
        ListView->insertColumn(L"DeleteProcedure", 150);
        ListView->insertColumn(L"ParseProcedure", 150);
        ListView->insertColumn(L"SecurityProcedure", 150);
        ListView->insertColumn(L"QueryNameProcedure", 150);
        ListView->insertColumn(L"OkayToCloseProcedure", 150);
        ListView->insertColumn(L"Status", 200);

        ADD_MENU(1, L"Refresh");
        ADD_MENU_SEP();
        ADD_MENU(2, L"Disable DumpProcedure");
        ADD_MENU(3, L"Disable OpenProcedure");
        ADD_MENU(4, L"Disable CloseProcedure");
        ADD_MENU(5, L"Disable DeleteProcedure");
        ADD_MENU(6, L"Disable ParseProcedure");
        ADD_MENU(7, L"Disable SecurityProcedure");
        ADD_MENU(8, L"Disable QueryNameProcedure");
        ADD_MENU(9, L"Disable OkayToCloseProcedure");
        ADD_MENU(10, L"Disable All Procedures");
        ADD_MENU_SEP();
        ADD_MENU(11, L"Change DumpProcedure");
        ADD_MENU(12, L"Change OpenProcedure");
        ADD_MENU(13, L"Change CloseProcedure");
        ADD_MENU(14, L"Change DeleteProcedure");
        ADD_MENU(15, L"Change ParseProcedure");
        ADD_MENU(16, L"Change SecurityProcedure");
        ADD_MENU(17, L"Change QueryNameProcedure");
        ADD_MENU(18, L"Change OkayToCloseProcedure");

        EnumKernelObjectTypes(ListView, StatusBar);
        break;

    case WM_COMMAND:
        wmId = LOWORD(wParam);
        switch (wmId)
        {
        case 1:
            EnumKernelObjectTypes(ListView, StatusBar);
            break;
        case 2:
            KiPacket.Parameters.Common.Parameter1 = 0;
            KiPacket.Parameters.Common.Parameter2 = ListView->getSelUlong(2, 16);
            KiPacket.Parameters.Common.Parameter3 = NULL;
            Syscall(IOCTL_CHANGE_OBJECT_PROC, &KiPacket);
            EnumKernelObjectTypes(ListView, StatusBar);
            break;
        case 3:
            KiPacket.Parameters.Common.Parameter1 = 1;
            KiPacket.Parameters.Common.Parameter2 = ListView->getSelUlong(2, 16);
            KiPacket.Parameters.Common.Parameter3 = NULL;
            Syscall(IOCTL_CHANGE_OBJECT_PROC, &KiPacket);
            EnumKernelObjectTypes(ListView, StatusBar);
            break;
        case 4:
            KiPacket.Parameters.Common.Parameter1 = 2;
            KiPacket.Parameters.Common.Parameter2 = ListView->getSelUlong(2, 16);
            KiPacket.Parameters.Common.Parameter3 = NULL;
            Syscall(IOCTL_CHANGE_OBJECT_PROC, &KiPacket);
            EnumKernelObjectTypes(ListView, StatusBar);
            break;
        case 5:
            KiPacket.Parameters.Common.Parameter1 = 3;
            KiPacket.Parameters.Common.Parameter2 = ListView->getSelUlong(2, 16);
            KiPacket.Parameters.Common.Parameter3 = NULL;
            Syscall(IOCTL_CHANGE_OBJECT_PROC, &KiPacket);
            EnumKernelObjectTypes(ListView, StatusBar);
            break;
        case 6:
            KiPacket.Parameters.Common.Parameter1 = 4;
            KiPacket.Parameters.Common.Parameter2 = ListView->getSelUlong(2, 16);
            KiPacket.Parameters.Common.Parameter3 = NULL;
            Syscall(IOCTL_CHANGE_OBJECT_PROC, &KiPacket);
            EnumKernelObjectTypes(ListView, StatusBar);
            break;
        case 7:
            KiPacket.Parameters.Common.Parameter1 = 5;
            KiPacket.Parameters.Common.Parameter2 = ListView->getSelUlong(2, 16);
            KiPacket.Parameters.Common.Parameter3 = NULL;
            Syscall(IOCTL_CHANGE_OBJECT_PROC, &KiPacket);
            EnumKernelObjectTypes(ListView, StatusBar);
            break;
        case 8:
            KiPacket.Parameters.Common.Parameter1 = 6;
            KiPacket.Parameters.Common.Parameter2 = ListView->getSelUlong(2, 16);
            KiPacket.Parameters.Common.Parameter3 = NULL;
            Syscall(IOCTL_CHANGE_OBJECT_PROC, &KiPacket);
            EnumKernelObjectTypes(ListView, StatusBar);
            break;
        case 9:
            KiPacket.Parameters.Common.Parameter1 = 7;
            KiPacket.Parameters.Common.Parameter2 = ListView->getSelUlong(2, 16);
            KiPacket.Parameters.Common.Parameter3 = NULL;
            Syscall(IOCTL_CHANGE_OBJECT_PROC, &KiPacket);
            EnumKernelObjectTypes(ListView, StatusBar);
            break;
        case 10:
            KiPacket.Parameters.Common.Parameter2 = ListView->getSelUlong(2, 16);
            KiPacket.Parameters.Common.Parameter3 = NULL;
            for (int i = 0; i <= 7; ++i)
            {
                KiPacket.Parameters.Common.Parameter1 = i;
                Syscall(IOCTL_CHANGE_OBJECT_PROC, &KiPacket);
            }
            EnumKernelObjectTypes(ListView, StatusBar);
            break;
        case 11:
            KiPacket.Parameters.Common.Parameter1 = 0;
            KiPacket.Parameters.Common.Parameter2 = ListView->getSelUlong(2, 16);
            if (GetAddress(ListView->getSelUlong(4, 16), &KiPacket.Parameters.Common.Parameter3))
            {
                Syscall(IOCTL_CHANGE_OBJECT_PROC, &KiPacket);
                EnumKernelObjectTypes(ListView, StatusBar);
            }
            break;
        case 12:
            KiPacket.Parameters.Common.Parameter1 = 1;
            KiPacket.Parameters.Common.Parameter2 = ListView->getSelUlong(2, 16);
            if (GetAddress(ListView->getSelUlong(5, 16), &KiPacket.Parameters.Common.Parameter3))
            {
                Syscall(IOCTL_CHANGE_OBJECT_PROC, &KiPacket);
                EnumKernelObjectTypes(ListView, StatusBar);
            }
            break;
        case 13:
            KiPacket.Parameters.Common.Parameter1 = 2;
            KiPacket.Parameters.Common.Parameter2 = ListView->getSelUlong(2, 16);
            if (GetAddress(ListView->getSelUlong(6, 16), &KiPacket.Parameters.Common.Parameter3))
            {
                Syscall(IOCTL_CHANGE_OBJECT_PROC, &KiPacket);
                EnumKernelObjectTypes(ListView, StatusBar);
            }
            break;
        case 14:
            KiPacket.Parameters.Common.Parameter1 = 3;
            KiPacket.Parameters.Common.Parameter2 = ListView->getSelUlong(2, 16);
            if (GetAddress(ListView->getSelUlong(7, 16), &KiPacket.Parameters.Common.Parameter3))
            {
                Syscall(IOCTL_CHANGE_OBJECT_PROC, &KiPacket);
                EnumKernelObjectTypes(ListView, StatusBar);
            }
            break;
        case 15:
            KiPacket.Parameters.Common.Parameter1 = 4;
            KiPacket.Parameters.Common.Parameter2 = ListView->getSelUlong(2, 16);
            if (GetAddress(ListView->getSelUlong(8, 16), &KiPacket.Parameters.Common.Parameter3))
            {
                Syscall(IOCTL_CHANGE_OBJECT_PROC, &KiPacket);
                EnumKernelObjectTypes(ListView, StatusBar);
            }
            break;
        case 16:
            KiPacket.Parameters.Common.Parameter1 = 5;
            KiPacket.Parameters.Common.Parameter2 = ListView->getSelUlong(2, 16);
            if (GetAddress(ListView->getSelUlong(9, 16), &KiPacket.Parameters.Common.Parameter3))
            {
                Syscall(IOCTL_CHANGE_OBJECT_PROC, &KiPacket);
                EnumKernelObjectTypes(ListView, StatusBar);
            }
            break;
        case 17:
            KiPacket.Parameters.Common.Parameter1 = 6;
            KiPacket.Parameters.Common.Parameter2 = ListView->getSelUlong(2, 16);
            if (GetAddress(ListView->getSelUlong(10, 16), &KiPacket.Parameters.Common.Parameter3))
            {
                Syscall(IOCTL_CHANGE_OBJECT_PROC, &KiPacket);
                EnumKernelObjectTypes(ListView, StatusBar);
            }
            break;
        case 18:
            KiPacket.Parameters.Common.Parameter1 = 7;
            KiPacket.Parameters.Common.Parameter2 = ListView->getSelUlong(2, 16);
            if (GetAddress(ListView->getSelUlong(11, 16), &KiPacket.Parameters.Common.Parameter3))
            {
                Syscall(IOCTL_CHANGE_OBJECT_PROC, &KiPacket);
                EnumKernelObjectTypes(ListView, StatusBar);
            }
            break;
        default:
            return FALSE;
        }
        break;

    case WM_NOTIFY:
        if(((LPNMHDR)lParam)->code == NM_CUSTOMDRAW)
        {
            PWCHAR Warn[] =
            {
                L"Open Procedure Hooked !", L"Delete Procedure Hooked !",
                L"Close Procedure Hooked !", L"Parse Procedure Hooked !",
                L"Security Procedure Hooked !", L"Query Name Procedure Hooked !"
            };
            SetWindowLong(hWnd, DWL_MSGRESULT, (LONG)Listview_handler((LPNMLVCUSTOMDRAW)lParam, Warn, 6, 12, ListView));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
        break;
    default:
        return FALSE;
    }
    return TRUE;
}


VOID EnumCallbacks(CListView * ListView, STATUS_BAR *StatusBar)
{
    KI_PACKET KiPacket;
    PULONG_PTR Callbacks;
    ULONG Count = 0;
    ULONG TotalCount = 0;
    WCHAR Buffer[260];

    ListView->clear();
    UPDATE_MODULES();

    //
    // enumerate ImageLoadNotify routines
    //
    RtlZeroMemory(&KiPacket, sizeof(KiPacket));
    Syscall(IOCTL_ENUM_IMAGE_NOTIFY, &KiPacket);
    Callbacks = (PULONG_PTR)KiPacket.Parameters.Common.Parameter1;
    Count = KiPacket.Parameters.Common.Parameter2;
    if (Callbacks)
    {
        for (ULONG i = 0; i < Count; ++i)
        {
            ListView->insertRaw(L"ImageLoad", TRUE);

            decodethreadaddr(Buffer, Callbacks[i]);
            ListView->insertRaw(Buffer, FALSE);

            if ('-' == *GetModulePath(Callbacks[i], Buffer, 260))
            {
                ListView->insertRaw(L"Callback routine exists in unknown module", FALSE);
            }
            else
            {
                ListView->insertRaw(L"-", FALSE);
            }
        }
        TotalCount += Count;
        VirtualFree(Callbacks, 0, MEM_RELEASE);
    }

    //
    // enumerate CreateProcessNotify routines
    //
    RtlZeroMemory(&KiPacket, sizeof(KiPacket));
    Syscall(IOCTL_ENUM_PROCESS_NOTIFY, &KiPacket);
    Callbacks = (PULONG_PTR)KiPacket.Parameters.Common.Parameter1;
    Count = KiPacket.Parameters.Common.Parameter2;
    if (Callbacks)
    {
        for (ULONG i = 0; i < Count; ++i)
        {
            ListView->insertRaw(L"CreateProcess", TRUE);

            decodethreadaddr(Buffer, Callbacks[i]);
            ListView->insertRaw(Buffer, FALSE);

            if ('-' == *GetModulePath(Callbacks[i], Buffer, 260))
            {
                ListView->insertRaw(L"Callback routine exists in unknown module", FALSE);
            }
            else
            {
                ListView->insertRaw(L"-", FALSE);
            }
        }
        TotalCount += Count;
        VirtualFree(Callbacks, 0, MEM_RELEASE);
    }

    //
    // enumerate CreateThreadNotify routines
    //
    RtlZeroMemory(&KiPacket, sizeof(KiPacket));
    Syscall(IOCTL_ENUM_THREAD_NOTIFY, &KiPacket);
    Callbacks = (PULONG_PTR)KiPacket.Parameters.Common.Parameter1;
    Count = KiPacket.Parameters.Common.Parameter2;
    if (Callbacks)
    {
        for (ULONG i = 0; i < Count; ++i)
        {
            ListView->insertRaw(L"CreateThread", TRUE);

            decodethreadaddr(Buffer, Callbacks[i]);
            ListView->insertRaw(Buffer, FALSE);

            if ('-' == *GetModulePath(Callbacks[i], Buffer, 260))
            {
                ListView->insertRaw(L"Callback routine exists in unknown module", FALSE);
            }
            else
            {
                ListView->insertRaw(L"-", FALSE);
            }
        }
        TotalCount += Count;
        VirtualFree(Callbacks, 0, MEM_RELEASE);
    }

    //
    // enumerate LegoNotify routines
    //
    RtlZeroMemory(&KiPacket, sizeof(KiPacket));
    Syscall(IOCTL_ENUM_LEGO_NOTIFY, &KiPacket);
    Callbacks = (PULONG_PTR)KiPacket.Parameters.Common.Parameter1;
    Count = KiPacket.Parameters.Common.Parameter2;
    if (Callbacks)
    {
        for (ULONG i = 0; i < Count; ++i)
        {
            ListView->insertRaw(L"Lego", TRUE);

            decodethreadaddr(Buffer, Callbacks[i]);
            ListView->insertRaw(Buffer, FALSE);

            if ('-' == *GetModulePath(Callbacks[i], Buffer, 260))
            {
                ListView->insertRaw(L"Callback routine exists in unknown module", FALSE);
            }
            else
            {
                ListView->insertRaw(L"-", FALSE);
            }
        }
        TotalCount += Count;
        VirtualFree(Callbacks, 0, MEM_RELEASE);
    }

    //
    // enumerate RegistryCallbacks routines
    //
    RtlZeroMemory(&KiPacket, sizeof(KiPacket));
    Syscall(IOCTL_ENUM_CM_NOTIFY, &KiPacket);
    Callbacks = (PULONG_PTR)KiPacket.Parameters.Common.Parameter1;
    Count = KiPacket.Parameters.Common.Parameter2;
    if (Callbacks)
    {
        for (ULONG i = 0; i < Count; ++i)
        {
            ListView->insertRaw(L"CmCallback (Registry)", TRUE);

            decodethreadaddr(Buffer, Callbacks[i]);
            ListView->insertRaw(Buffer, FALSE);

            if ('-' == *GetModulePath(Callbacks[i], Buffer, 260))
            {
                ListView->insertRaw(L"Callback routine exists in unknown module", FALSE);
            }
            else
            {
                ListView->insertRaw(L"-", FALSE);
            }
        }
        TotalCount += Count;
        VirtualFree(Callbacks, 0, MEM_RELEASE);
    }

    //
    // enumerate BugCheckCallback routines
    //
    RtlZeroMemory(&KiPacket, sizeof(KiPacket));
    Syscall(IOCTL_ENUM_BUGCHECK, &KiPacket);
    Callbacks = (PULONG_PTR)KiPacket.Parameters.Common.Parameter1;
    Count = KiPacket.Parameters.Common.Parameter2;
    PBUGCHECK_CALLBACK BugcheckRecord = (PBUGCHECK_CALLBACK)Callbacks;
    if (BugcheckRecord)
    {
        WCHAR Buffer2[260];
        for (ULONG i = 0; i < Count; ++i)
        {
            ListView->insertRaw(L"BugCheckCallback", TRUE);

            decodethreadaddr(Buffer, (ULONG)BugcheckRecord[i].Routine);
            _snwprintf_s(Buffer2, COF(Buffer2), L"%s :: %s", Buffer, BugcheckRecord[i].Name);
            ListView->insertRaw(Buffer2, FALSE);

            if ('-' == *GetModulePath((ULONG)BugcheckRecord[i].Routine, Buffer, 260))
            {
                ListView->insertRaw(L"Callback routine exists in unknown module", FALSE);
            }
            else
            {
                ListView->insertRaw(L"-", FALSE);
            }
        }
        TotalCount += Count;
        VirtualFree(Callbacks, 0, MEM_RELEASE);
    }
    

    //
    // enumerate BugCheckReasonCallback routines
    //
    RtlZeroMemory(&KiPacket, sizeof(KiPacket));
    Syscall(IOCTL_ENUM_BUGCHECK_REASON, &KiPacket);
    Callbacks = (PULONG_PTR)KiPacket.Parameters.Common.Parameter1;
    Count = KiPacket.Parameters.Common.Parameter2;
    PBUGCHECK_CALLBACK BugcheckReasonRecord = (PBUGCHECK_CALLBACK)Callbacks;
    if (BugcheckReasonRecord)
    {
        WCHAR Buffer2[260];
        for (ULONG i = 0; i < Count; ++i)
        {
            if (BugcheckReasonRecord[i].State == KbCallbackSecondaryDumpData)
            {
                ListView->insertRaw(L"BugCheckSecondaryDumpDataCallback", TRUE);
            }
            else if (BugcheckReasonRecord[i].State == KbCallbackDumpIo)
            {
                ListView->insertRaw(L"BugCheckDumpIoCallback", TRUE);
            }
            else
            {
                ListView->insertRaw(L"BugCheckReasonCallback", TRUE);
            }

            decodethreadaddr(Buffer, (ULONG)BugcheckReasonRecord[i].Routine);
            _snwprintf_s(Buffer2, COF(Buffer2), L"%s :: %s", Buffer, BugcheckReasonRecord[i].Name);
            ListView->insertRaw(Buffer2, FALSE);

            if ('-' == *GetModulePath((ULONG)BugcheckReasonRecord[i].Routine, Buffer, 260))
            {
                ListView->insertRaw(L"Callback routine exists in unknown module", FALSE);
            }
            else
            {
                ListView->insertRaw(L"-", FALSE);
            }
        }
        TotalCount += Count;
        VirtualFree(Callbacks, 0, MEM_RELEASE);
    }

    StatusBar->Format(L"Callbacks Count = %d", TotalCount);
}


INT_PTR CALLBACK DlgNotifyCallbacks(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam, CListView * ListView, STATUS_BAR *StatusBar, HMENU HwndMenu)
{
    KI_PACKET KiPacket;
    int wmId;
    WCHAR Buffer[260];

    switch (message)
    {
    case WM_INITDIALOG:
        SetWindowText(hWnd, L"System Notify Callbacks");
        ListView->insertColumn(L"Callback Type", 220);
        ListView->insertColumn(L"Callback Routine", 300);
        ListView->insertColumn(L"Status", 200);

        ADD_MENU(1, L"Refresh");
        ADD_MENU_SEP();
        ADD_MENU(2, L"Delete Callback");
        ADD_MENU_SEP();
        ADD_MENU(3, L"Disassemble Callback Routine");

        EnumCallbacks(ListView, StatusBar);
        break;

    case WM_COMMAND:
        wmId = LOWORD(wParam);
        switch (wmId)
        {
        case 1:
            EnumCallbacks(ListView, StatusBar);
            break;
        case 2:
            KiPacket.Parameters.Common.Parameter1 = ListView->getSelUlong(1, 16);
            ListView->getSelText(0, Buffer, 260);
            if (!wcscmp(Buffer, L"ImageLoad")) // ImageLoad
            {
                KiPacket.Parameters.Common.Parameter2 = 1;
            }
            else if (!wcscmp(Buffer, L"CreateProcess")) // CreateProcess
            {
                KiPacket.Parameters.Common.Parameter2 = 2;
            }
            else if (!wcscmp(Buffer, L"CreateThread")) // CreateThread
            {
                KiPacket.Parameters.Common.Parameter2 = 3;
            }
            else if (!wcscmp(Buffer, L"Lego")) // Lego
            {
                KiPacket.Parameters.Common.Parameter2 = 4;
            }
            else if (!wcscmp(Buffer, L"CmCallback (Registry)")) // Cm
            {
                KiPacket.Parameters.Common.Parameter2 = 5;
            }
            else if (!wcscmp(Buffer, L"BugCheckCallback")) // Bugcheck
            {
                KiPacket.Parameters.Common.Parameter2 = 6;
            }
            else if (!wcscmp(Buffer, L"BugCheckSecondaryDumpDataCallback")) // BugcheckReason
            {
                KiPacket.Parameters.Common.Parameter2 = 7;
            }
            else if (!wcscmp(Buffer, L"BugCheckDumpIoCallback")) // BugcheckReason
            {
                KiPacket.Parameters.Common.Parameter2 = 7;
            }
            else if (!wcscmp(Buffer, L"BugCheckReasonCallback")) // BugcheckReason
            {
                KiPacket.Parameters.Common.Parameter2 = 7;
            }
            Syscall(IOCTL_DELETE_NOTIFY, &KiPacket);
            EnumCallbacks(ListView, StatusBar);
            break;
        case 3:
            GOTO_ADDRESS(ListView->getSelUlong(1, 16));
            break;
        default:
            return FALSE;
        }
        break;

    case WM_NOTIFY:
        if(((LPNMHDR)lParam)->code == NM_CUSTOMDRAW)
        {
            PWCHAR Warn = L"Callback routine exists in unknown module";
            SetWindowLong(hWnd, DWL_MSGRESULT, (LONG)Listview_handler((LPNMLVCUSTOMDRAW)lParam, &Warn, 1, 2, ListView));
            return TRUE;
        }
        else
        {
            return FALSE;
        }
        break;
    default:
        return FALSE;
    }
    return TRUE;
}