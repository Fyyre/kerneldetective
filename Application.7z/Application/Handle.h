void EnumHandles(PPROCESS_ENTRY process, CListView *Listv);
