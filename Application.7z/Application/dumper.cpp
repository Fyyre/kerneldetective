/*
 * Copyright (c) 2008 Arab Team 4 Reverse Engineering. All rights reserved.
 *
 * Module Name:
 *
 *		dumper.cpp
 *
 * Abstract:
 *
 *		This module implements the process dumping routines.
 *
 * Author:
 *
 *		GamingMasteR
 *
 */


#include "Kernel Detective.h"
#include "dumper.h"


dumper::dumper(PVOID ProcessObject, ULONG_PTR Base)
{
	this->eProcess = (ULONG)ProcessObject;
	this->ImageBase = (PVOID)Base;
}


dumper::~dumper()
{
	//CloseHandle(this->hDump);
}


BOOL dumper::dump_process(PWCHAR DumpPath, SIZE_T Size)
{
	HANDLE hDump;
	PIMAGE_DOS_HEADER dosheader;
	PIMAGE_DOS_HEADER dump_dosheader;
	PIMAGE_NT_HEADERS ntheader;
	PIMAGE_NT_HEADERS dump_ntheader;
	HANDLE hMap;
	ULONG ImageSize;
	ULONG HeaderSize;
	PVOID filemap;
	ULONG nSections;
	PIMAGE_SECTION_HEADER pSection;
	BOOL rc = false;

    if (ImageBase == NULL)
        return false;

	//
	// Create the dump file
	//
	KFILE dump;
	if (!dump.KCreateFile(gWin, DumpPath))
		return false;
	hDump = dump.KGetHandle();

	if (Size == 0)
	{
        if (readushort(ImageBase) != 'ZM')
            return false;
		HeaderSize = readulong(&((PIMAGE_NT_HEADERS)(readulong(&((PIMAGE_DOS_HEADER)ImageBase)->e_lfanew) + (ULONG)ImageBase))->OptionalHeader.SizeOfHeaders);
		dosheader = (PIMAGE_DOS_HEADER)new char[HeaderSize];
		readmemory(this->ImageBase, dosheader, HeaderSize);
		ntheader = (PIMAGE_NT_HEADERS)(dosheader->e_lfanew + (ULONG)dosheader);
		ImageSize = ntheader->OptionalHeader.SizeOfImage;
	}
	else
	{
		ImageSize = Size;
	}

	//
	// Create dump file map
	//
	hMap = CreateFileMapping(hDump, 0, PAGE_READWRITE, 0, ImageSize, 0);
	if (NULL != hMap)
	{
		filemap = MapViewOfFile(hMap, FILE_MAP_WRITE, 0, 0, ImageSize);
		if (NULL != filemap)
		{
			try
			{
				if (Size == 0)
				{
					//
					// Copy file header to dump file
					//
					memcpy(filemap, dosheader, HeaderSize);
					dump_dosheader = (PIMAGE_DOS_HEADER)filemap;
					dump_ntheader = (PIMAGE_NT_HEADERS)(dump_dosheader->e_lfanew + (ULONG)filemap);
					nSections = dump_ntheader->FileHeader.NumberOfSections;
					pSection = IMAGE_FIRST_SECTION(dump_ntheader);

					//
					// Walk through every section and dump data to file
					//
					for (unsigned long i = 0; i < nSections; i++)
					{
						readmemory((PVOID)((ULONG)ImageBase + pSection[i].VirtualAddress),
							(PVOID)((ULONG)filemap + pSection[i].VirtualAddress),
							pSection[i].Misc.VirtualSize);

						//
						// Fix section raw offset and size
						//
						pSection[i].SizeOfRawData = pSection[i].Misc.VirtualSize;
						pSection[i].PointerToRawData = pSection[i].VirtualAddress;
					}
				}
				else
				{
					readmemory(ImageBase, filemap, Size);
				}
			}
			catch(...)
			{
				Err(L"Memory dump failed !");
			}

			//
			// Free file map
			//
			UnmapViewOfFile(filemap);

			rc++;
		}
		CloseHandle(hMap);
	}
	delete [HeaderSize] dosheader;
	CloseHandle(hDump);
	return rc;
}


BOOL dumper::dump_memory(PWCHAR DumpPath, SIZE_T Size)
{
	HANDLE hDump;
	PIMAGE_DOS_HEADER dosheader;
	PIMAGE_DOS_HEADER dump_dosheader;
	PIMAGE_NT_HEADERS ntheader;
	PIMAGE_NT_HEADERS dump_ntheader;
	HANDLE hMap;
	ULONG ImageSize;
	ULONG HeaderSize;
	PVOID filemap;
	ULONG nSections;
	PIMAGE_SECTION_HEADER pSection;
	BOOL rc = false;

    if (ImageBase == NULL)
        return false;
	//
	// Create the dump file
	//
	KFILE dump;
	if (!dump.KCreateFile(gWin, DumpPath))
		return false;
	hDump = dump.KGetHandle();

	if (Size == 0)
	{
        if (readushort(ImageBase) != 'ZM')
            return false;
		HeaderSize = readulong(&((PIMAGE_NT_HEADERS)(readulong(&((PIMAGE_DOS_HEADER)ImageBase)->e_lfanew) + (ULONG)ImageBase))->OptionalHeader.SizeOfHeaders);
		dosheader = (PIMAGE_DOS_HEADER)new char[HeaderSize];
		readmemory(this->ImageBase, dosheader, HeaderSize);
		ntheader = (PIMAGE_NT_HEADERS)(dosheader->e_lfanew + (ULONG)dosheader);
		ImageSize = ntheader->OptionalHeader.SizeOfImage;
	}
	else
	{
		ImageSize = Size;
	}

	//
	// Create dump file map
	//
	hMap = CreateFileMapping(hDump, 0, PAGE_READWRITE, 0, ImageSize, 0);
	if (NULL != hMap)
	{
		filemap = MapViewOfFile(hMap, FILE_MAP_WRITE, 0, 0, ImageSize);
		if (NULL != filemap)
		{
			try
			{
				if (Size == 0)
				{
					//
					// Copy file header to dump file
					//
					memcpy(filemap, dosheader, HeaderSize);
					dump_dosheader = (PIMAGE_DOS_HEADER)filemap;
					dump_ntheader = (PIMAGE_NT_HEADERS)(dump_dosheader->e_lfanew + (ULONG)filemap);
					nSections = dump_ntheader->FileHeader.NumberOfSections;
					pSection = IMAGE_FIRST_SECTION(dump_ntheader);

					//
					// Walk through every section and dump data to file
					//
					for (unsigned long i = 0; i < nSections; i++)
					{
						readmemory((PVOID)((ULONG)ImageBase + pSection[i].VirtualAddress),
							(PVOID)((ULONG)filemap + pSection[i].VirtualAddress),
							pSection[i].Misc.VirtualSize);

						//
						// Fix section raw offset and size
						//
						pSection[i].SizeOfRawData = pSection[i].Misc.VirtualSize;
						pSection[i].PointerToRawData = pSection[i].VirtualAddress;
					}
				}
				else
				{
					readmemory(ImageBase, filemap, Size);
				}
			}
			catch(...)
			{
				Err(L"Memory dump failed !");
			}

			//
			// Free file map
			//
			UnmapViewOfFile(filemap);

			rc++;
		}
		CloseHandle(hMap);
	}
	delete [HeaderSize] dosheader;
	CloseHandle(hDump);
	return rc;
}


BOOL dumper::readmemory(PVOID Address, PVOID Buffer, SIZE_T szBuffer)
{
	return KiReadVirtualMemory((PVOID)this->eProcess, Address, Buffer, szBuffer);
}


ULONG dumper::readulong(PVOID Address)
{
	ULONG val;
	this->readmemory(Address, &val, sizeof(ULONG));
	return val;
}


USHORT dumper::readushort(PVOID Address)
{
	USHORT val;
	this->readmemory(Address, &val, sizeof(USHORT));
	return val;
}


UCHAR dumper::readuchar(PVOID Address)
{
	UCHAR val;
	this->readmemory(Address, &val, sizeof(UCHAR));
	return val;
}