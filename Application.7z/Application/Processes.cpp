#include "Kernel Detective.h"
#include "Dll.h"
#include "Disassemble.h"
#include "dumper.h"
#include "processes.h"
#include "pdk.h"


HMENU Menu_Process;

WCHAR* Process_Status[] =
{
    L"Invisible",
    L"Inaccessible from user-mode",
    L"Critical Process"
};


void CALLBACK Process_Cmd(HWND hWin,WPARAM wParam,LPARAM lParam, CListView *Listv)
{
    ULONG		offset = 0;
    int			szCmd = 0;
    int			Pos = 0;
    DWORD		eProcess = 0;

    switch	(wParam)
    {
    case PROCESS_TERMINATE_USER:
    {
        int c = Listv->getSelCount() + Listv->getSelIndex();
        for (int i = Listv->getSelIndex(); i < c; i++)
        {
            eProcess = Listv->getUlong(i, 1, 10);
            eProcess = (DWORD)OpenProcess(PROCESS_TERMINATE, FALSE, eProcess);
            if (eProcess)
            {
                TerminateProcess((HANDLE)eProcess, EXIT_FAILURE);
                CloseHandle((HANDLE)eProcess);
            }
        }
        Sleep(500);
        GetAllProcesses(Listv);
        break;
    }
    case PROCESS_TERMINATE_KERNEL:
    {
        if (IDYES == MessageBox(hWin, L"This operation may cause BSOD !\r\n\r\nAre you sure ?", AppName, MB_ICONEXCLAMATION|MB_YESNO))
        {
            int c = Listv->getSelCount() + Listv->getSelIndex();
            for (int i = Listv->getSelIndex(); i < c; i++)
            {
                ProcessKill((PVOID)Listv->getUlong(i, 3, 16), FALSE);
            }
            Sleep(500);
            GetAllProcesses(Listv);
        }
        break;
    }
    case PROCESS_TERMINATE_FORCE:
    {
        if (IDYES == MessageBox(hWin, L"This operation may cause BSOD !\r\n\r\nAre you sure ?", AppName, MB_ICONEXCLAMATION|MB_YESNO))
        {
            int c = Listv->getSelCount() + Listv->getSelIndex();
            for (int i = Listv->getSelIndex(); i < c; i++)
            {
                ProcessKill((PVOID)Listv->getUlong(i, 3, 16), TRUE);
            }
            Sleep(500);
            GetAllProcesses(Listv);
        }
        break;
    }
    case PROCESS_READMEMORY:
    {
        range_address = Listv->getSelUlong(6, 16);
        range_size = 0x400;
        if	(DialogBoxParam(hInstance, MAKEINTRESOURCE(DLG_RANGE), gWin, (DLGPROC)DlgRange, 0))
        {
            UpdateCommonBuffer(range_address, range_size);
            if (KiReadVirtualMemory(KiCurrentProcess.ProcessObject, GetCommonReadAddress(), GetCommonReadBuffer(), GetCommonReadSize()))
				PrintDisasm(GetCommonReadBuffer(), GetCommonReadAddress(), GetCommonReadSize());
        }
        break;
    }
    case PROCESS_DUMPMEMORY:
    {
        dumper dumpfile(KiCurrentProcess.ProcessObject, KiCurrentProcess.ImageBase);
        dumpfile.dump_process(0, 0);
        break;
    }
    case PROCESS_REFRESH:
    {
        GetAllProcesses(Listv);
        break;
    }
    case PROCESS_SUSPEND:
    {
        int c = Listv->getSelCount() + Listv->getSelIndex();
        for (int i = Listv->getSelIndex(); i < c; i++)
        {
            PVOID process = (PVOID)Listv->getUlong(i, 3, 16);
            ProcessSuspend(process);
        }
        break;
    }
    case PROCESS_RESUME:
    {
        int c = Listv->getSelCount() + Listv->getSelIndex();
        for (int i = Listv->getSelIndex(); i < c; i++)
        {
            PVOID process = (PVOID)Listv->getUlong(i, 3, 16);
            ProcessResume(process, FALSE);
        }
        break;
    }
    case PROCESS_RESUME_FORCE:
    {
        int c = Listv->getSelCount() + Listv->getSelIndex();
        for (int i = Listv->getSelIndex(); i < c; i++)
        {
            PVOID process = (PVOID)Listv->getUlong(i, 3, 16);
            ProcessResume(process, TRUE);
        }
        break;
    }
    case PROCESS_PROPERTIES:
    {
        WCHAR FileName[MAX_PATH];
        Listv->getSelText(0, FileName, sizeof(FileName));
        ShowFilePropertiesDlg(FileName);
        break;
    }
    case PROCESS_DELETE:
    {
        WCHAR FileName[MAX_PATH];
        Listv->getSelText(0, FileName, MAX_PATH);
        if (FileDelete(FileName, FALSE))
        {
            MessageBox(hWin, L"File deleted successfully", AppName, MB_OK | MB_ICONINFORMATION);
        }
        else
        {
            UINT msgID = MessageBox(hWin, L"Cannot delete file normally !\r\nDo you want to force delete the file ?", AppName, MB_YESNO | MB_ICONERROR);
            if (msgID == IDYES)
            {
                SendMessage(hWin, WM_COMMAND, PROCESS_FORCEDELETE, 0);
            }
        }
        break;
    }
    case PROCESS_FORCEDELETE:
    {
        WCHAR FileName[MAX_PATH];
        Listv->getSelText(0, FileName, MAX_PATH);
        if (FileDelete(FileName, TRUE))
        {
            MessageBox(hWin, L"File deleted successfully", AppName, MB_OK | MB_ICONINFORMATION);
        }
        else
        {
            MessageBox(hWin, L"File cannot be deleted !", AppName, MB_OK | MB_ICONERROR);
        }
        break;
    }
    case PROCESS_VERIFY:
    {
        WCHAR FileName[MAX_PATH];
        Listv->getSelText(0, FileName, MAX_PATH);
        if (IsFileDigitallySigned(FileName))
        {
            MessageBox(hWin, L"File was verified successfully", AppName, MB_OK | MB_ICONINFORMATION);
        }
        else
        {
            MessageBox(hWin, L"File cannot be verified", AppName, MB_OK | MB_ICONEXCLAMATION);
        }
        break;
    }
    }
}


BOOL CALLBACK DlgProcess(HWND hWin,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
    POINT		XY;
    WCHAR		Temp[BUFFER_LEN];
    static CListView List_Process(hWin);

    switch (uMsg)
    {
    case	WM_INITDIALOG :
        List_Process.create(0,0,0,0, settings.clr_back, settings.clr_front, 1);
        List_Process.insertColumn(L"Process Path", 300);
        List_Process.insertColumn(L"ID", 40);
        List_Process.insertColumn(L"Parent ID", 60);
        List_Process.insertColumn(L"KPROCESS", 80);
        List_Process.insertColumn(L"PEB", 80);
        List_Process.insertColumn(L"Image Base", 80);
        List_Process.insertColumn(L"Entry Point", 80);
        List_Process.insertColumn(L"Virtual Size", 80);
        List_Process.insertColumn(L"Status", 100);
        Menu_Process = GetSubMenu(LoadMenu(hInstance,MAKEINTRESOURCE(MENU_PROCESS)),0);
        break;
    case	WM_COMMAND :
        Process_Cmd(hWin,wParam,lParam, &List_Process);
        break;
    case	WM_SHOWWINDOW:
        if ((BOOL)wParam)
        {
            GetAllProcesses(&List_Process);
            CurrentList = &List_Process;
        }
        break;
    case WM_SIZE:
    {
        if(wParam != SIZE_MINIMIZED)
            List_Process.resize(0, 0, LOWORD(lParam),HIWORD(lParam));
        break;
    }
    case	WM_NOTIFY :
        if(((LPNMHDR)lParam)->code == NM_CUSTOMDRAW)
        {
            PWCHAR warn = Process_Status[0];
            SetWindowLong(hWin, DWL_MSGRESULT, (LONG)Listview_handler((LPNMLVCUSTOMDRAW)lParam, &warn, 1, 8, &List_Process));
            return TRUE;
        }
        if(((LPNMHDR)lParam)->code == LVN_COLUMNCLICK)
        {
            ((LPNMLISTVIEW)lParam)->lParam = (LPARAM)&List_Process;
            ListView_SortItemsEx(((LPNMHDR)lParam)->hwndFrom, CListView::sort, (LPNMLISTVIEW)lParam);
            return TRUE;
        }
        if	(((LPNMHDR)lParam)->hwndFrom == List_Process.getHwnd() && ((LPNMHDR)lParam)->code == LVN_ITEMCHANGED)
        {
            WCHAR h[BUFFER_LEN];
            if (0 == List_Process.getSelText(0, h, BUFFER_LEN)) break;
            wcsncpy_s(Temp, COF(Temp), AppName L" :: ", _TRUNCATE);
            wcsncat_s(Temp, COF(Temp), PathToFileName(h), _TRUNCATE);
            SetWindowText(gWin,Temp);
            List_Process.getSelText(3, h, BUFFER_LEN);
            if (KiProcessList)
            {
                for	(ULONG i = 0; i < KiProcessCount; ++i)
                {
                    if	(KiProcessList[i].ProcessObject == (PVOID)wcstoul(h,NULL,16))
                    {
                        KiCurrentProcess = KiProcessList[i];
                        KdCallOnProcessChange(&KiCurrentProcess);
                        //range_address = List_Process.getSelUlong(6, 16);
                        //range_size = 0x400;
                        break;
                    }
                }
            }
        }
        if	(((LPNMHDR)lParam)->code == NM_RCLICK)
        {
            //if (CurProcess->pid == 0 && CurProcess->parent == 0 && !_tcscmp((LPSTR)CurProcess->Name,L"System Idle Process")))	break;
            GetCursorPos(&XY);
            TrackPopupMenu(Menu_Process,TPM_LEFTALIGN,XY.x,XY.y,NULL,hWin,NULL);
        }
        break;
    }
    return 0;
}

LPSTR
ExtractFileName(
    LPSTR str
)
{
    int i;
    for	(i = strlen(str); i>0; i--)
        if	(str[i] == '\\')
            return str+i+1;
    return str;
}



void GetAllProcesses(CListView *Listv)
{
    WCHAR		Temp[BUFFER_LEN];
    ULONG		j;
    ULONG		pc = 0;
    ULONG		Count;
    ULONG		hidden = 0;
    PVOID		Buffer;
    PSYSTEM_PROCESSES lpBuffer;
    HICON hIcon;
    PPROCESS_ENTRY ProcessList;


    Count = EnumerateProcesses(&ProcessList);
    if (!ProcessList || Count == 0)
        return;

    pNtQuerySystemInformation(SystemProcessesAndThreadsInformation, &pc, 0, &pc);
    Buffer = malloc(pc);
    pNtQuerySystemInformation(SystemProcessesAndThreadsInformation, Buffer, pc, 0);

    Listv->beginRefresh();
    Listv->clear();
    HIMAGELIST hImageList = ImageList_Create(GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), ILC_COLORDDB|ILC_MASK, Count, 0);
    ImageList_SetBkColor(hImageList, settings.clr_back);
    for (j = 0; j < Count; ++j)
    {
        RtlZeroMemory(Temp, sizeof(Temp));
        decodefilepath(ProcessList[j].Name, COF(ProcessList[j].Name));
        //QueryEnvironmentString(ProcessList[j].Name, ProcessList[j].Name, 260);
        Listv->insertRaw(ProcessList[j].Name, TRUE);

        SHFILEINFO fi= {0};
        SHGetFileInfo(ProcessList[j].Name, 0, &fi, sizeof(fi), SHGFI_ICON);

        hIcon = fi.hIcon;
        if (hIcon)
        {
            ImageList_AddIcon(hImageList, hIcon);
            DestroyIcon(hIcon);
        }
        else
        {
            ImageList_AddIcon(hImageList, LoadIcon(NULL, IDI_WINLOGO));
        }


        _snwprintf_s(Temp, COF(Temp), L"%ld",ProcessList[j].Pid);
        Listv->insertRaw(Temp, FALSE);

        _snwprintf_s(Temp, COF(Temp),L"%ld",ProcessList[j].ParentId);
        Listv->insertRaw(Temp, FALSE);

        _snwprintf_s(Temp, COF(Temp),L"0x%p",ProcessList[j].ProcessObject);
        Listv->insertRaw(Temp, FALSE);

        _snwprintf_s(Temp, COF(Temp),L"0x%p",ProcessList[j].Peb);
        Listv->insertRaw(Temp, FALSE);

        _snwprintf_s(Temp, COF(Temp),L"0x%p",ProcessList[j].ImageBase);
        Listv->insertRaw(Temp, FALSE);

        _snwprintf_s(Temp, COF(Temp),L"0x%p", GetProcessEntryPoint(ProcessList[j].ProcessObject, ProcessList[j].ImageBase));
        Listv->insertRaw(Temp, FALSE);

        _snwprintf_s(Temp, COF(Temp),L"%ld KB",(ProcessList[j].Cb)/1024);
        Listv->insertRaw(Temp, FALSE);

        lpBuffer = (PSYSTEM_PROCESSES)Buffer;
        do
        {
            if (lpBuffer->ProcessId == ProcessList[j].Pid && !_wcsnicmp(lpBuffer->ProcessName.Buffer, PathToFileName(ProcessList[j].Name), lpBuffer->ProcessName.Length))
                break;
            if (!lpBuffer->NextEntryDelta)
                break;
            lpBuffer = (PSYSTEM_PROCESSES)((ULONG)lpBuffer + lpBuffer->NextEntryDelta);
        }
        while (TRUE);

        wcsncpy_s(Temp, L"-", wcslen(L"-"));
        if (wcsncmp(L"System Idle Process", ProcessList[j].Name, wcslen(L"System Idle Process")))
        {
            HANDLE hproc = OpenProcess(PROCESS_ALL_ACCESS, FALSE, ProcessList[j].Pid);
            CloseHandle(hproc);
            if (lpBuffer->ProcessId != ProcessList[j].Pid || lpBuffer->InheritedFromProcessId != ProcessList[j].ParentId)
            {
                wcsncpy_s(Temp, Process_Status[0], COF(Temp));
                ++hidden;
            }
            else if (0 == hproc)
            {
                wcsncpy_s(Temp, Process_Status[1], COF(Temp));
            }
            else if (ProcessList[j].Status == 2)
            {
                wcsncpy_s(Temp, Process_Status[2], COF(Temp));
            }
        }
        Listv->insertRaw(Temp, FALSE);
    }

    ListView_SetImageList(Listv->getHwnd(), hImageList, LVSIL_SMALL);

    Listv->endRefresh();
    //CurProcess = &ProcessList[--j];
    List_Disasm->clear();
    SetDlgItemText(GetParent(List_Disasm->getHwnd()), DISASM_DUMP, L"");
    wcsncpy_s(Temp, AppName L" :: ", COF(Temp));
    wcsncat_s(Temp, PathToFileName(KiCurrentProcess.Name), COF(Temp));
    SetWindowText(gWin,Temp);
    free(Buffer);
    status.Format(L"Processes :: %ld  -  Hidden :: %ld", Count, hidden);
}