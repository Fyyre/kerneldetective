
void EnumThreads(PPROCESS_ENTRY Process, CListView *Listv);
extern CListView *List_Thread;


