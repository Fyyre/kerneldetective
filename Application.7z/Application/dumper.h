/*
 * Copyright (c) 2008 Arab Team 4 Reverse Engineering. All rights reserved.
 *
 * Module Name:
 *
 *		dumper.h
 *
 * Abstract:
 *
 *		This module defines the process dumping class.
 *
 * Author:
 *
 *		GamingMasteR
 *
 */



class dumper
{
public:
	dumper(PVOID ProcessObject, ULONG_PTR Base);
	~dumper();
	BOOL dump_process(PWCHAR DumpPath, SIZE_T Size);
    BOOL dump_memory(PWCHAR DumpPath, SIZE_T Size);
private:
	BOOL readmemory(PVOID Address, PVOID Buffer, SIZE_T szBuffer);
	ULONG readulong(PVOID Address);
	USHORT readushort(PVOID Address);
	UCHAR readuchar(PVOID Address);
	ULONG eProcess;
	PVOID ImageBase;
};