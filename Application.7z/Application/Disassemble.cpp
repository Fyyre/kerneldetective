#include	"Kernel Detective.h"
#include	"Disassemble.h"
#include	"disasm.h"

#pragma comment (lib, "psapi.lib")
#pragma comment (lib, "dbghelp.lib")



HMENU Menu_Disasm;
WNDPROC Hexa_hex_winproc;
HWND Hexa_hex_hwnd;
CListView *List_Disasm;
ULONG range_address;
ULONG range_size;
HWND DlgDisasmHwnd;


void CALLBACK Disassembler_Cmd(HWND hWin, WPARAM wParam, LPARAM lParam, CListView *Listv)
{
    WCHAR Temp[BUFFER_LEN];
    CHAR Asmline[BUFFER_LEN];
    t_disasm da;
    t_asmmodel sa;
    ULONG offset = 0;
    ULONG szCmd = 0;
    ULONG Pos = 0;
    DWORD eProcess = 0;

    switch	(wParam)
    {
    case	DISASM_ASSEMBLE:
    {
        DialogBoxParam(hInstance, MAKEINTRESOURCE(DLG_ASSEMBLE), gWin, (DLGPROC)DlgAssemble, 0);
        break;
    };
    case	DISASM_FOLLOW:
    {
        List_Disasm->getSelText(0, Temp, sizeof(Temp));
        offset = wcstoul(Temp, 0, 16) - (ULONG)GetCommonReadAddress();
        Disasm((PBYTE)GetCommonReadBuffer() + offset, GetCommonReadSize() - offset, (ULONG)GetCommonReadAddress() + offset, &da, DISASM_DATA);
        if	(da.adrconst)
        {
            UpdateCommonBuffer(da.adrconst, 0x400);
            if	(KiReadVirtualMemory(KiCurrentProcess.ProcessObject, GetCommonReadAddress(), (PBYTE)GetCommonReadBuffer(), GetCommonReadSize()))
                PrintDisasm((PCHAR)GetCommonReadBuffer(), GetCommonReadAddress(), GetCommonReadSize());
            break;
        }
        else if (da.jmpconst)
        {
            UpdateCommonBuffer(da.jmpconst, 0x400);
            if	(KiReadVirtualMemory(KiCurrentProcess.ProcessObject, GetCommonReadAddress(), (PBYTE)GetCommonReadBuffer(), GetCommonReadSize()))
                PrintDisasm((PCHAR)GetCommonReadBuffer(), GetCommonReadAddress(), GetCommonReadSize());
            break;
        }
        else if (da.immconst)
        {
            UpdateCommonBuffer(da.immconst, 0x400);
            if	(KiReadVirtualMemory(KiCurrentProcess.ProcessObject, GetCommonReadAddress(), (PBYTE)GetCommonReadBuffer(), GetCommonReadSize()))
                PrintDisasm((PCHAR)GetCommonReadBuffer(), GetCommonReadAddress(), GetCommonReadSize());
            break;
        }
        break;
    };
    case	DISASM_GOTO:
    {
        if	(DialogBoxParam(hInstance, MAKEINTRESOURCE(DLG_RANGE), gWin, (DLGPROC)DlgRange, 0))
        {
            UpdateCommonBuffer(range_address, range_size);
            if	(KiReadVirtualMemory(KiCurrentProcess.ProcessObject, GetCommonReadAddress(), (PBYTE)GetCommonReadBuffer(), GetCommonReadSize()))
                PrintDisasm((PCHAR)GetCommonReadBuffer(), GetCommonReadAddress(), GetCommonReadSize());
        }
        break;
    };
    case	DISASM_BINARY_EDIT:
    {
        DialogBoxParam(hInstance, MAKEINTRESOURCE(DLG_HEXA), gWin, (DLGPROC)DlgHexa, 0);
        break;
    };
    case	DISASM_BINARY_ZERO:
    {
        int c = List_Disasm->getSelCount() + Listv->getSelIndex();
        for (int i = Listv->getSelIndex(); i < c; i++)
        {
            offset = Listv->getUlong(i, 0, 16) - (ULONG)GetCommonReadAddress();
            szCmd = Disasm((PBYTE)GetCommonReadBuffer() + offset, GetCommonReadSize() - offset, (ULONG)GetCommonReadAddress() + offset, &da, DISASM_SIZE);
            RtlZeroMemory((PBYTE)GetCommonReadBuffer() + offset, szCmd);
            KiWriteVirtualMemory(KiCurrentProcess.ProcessObject, (PVOID)((ULONG)GetCommonReadAddress() + offset), (PBYTE)GetCommonReadBuffer() + offset, szCmd);
        }
        if	(KiReadVirtualMemory(KiCurrentProcess.ProcessObject, GetCommonReadAddress(), (PBYTE)GetCommonReadBuffer(), GetCommonReadSize()))
            PrintDisasm((PCHAR)GetCommonReadBuffer(), GetCommonReadAddress(), GetCommonReadSize());
        break;
    };
    case	DISASM_BINARY_NOP:
    {
        int c = List_Disasm->getSelCount() + Listv->getSelIndex();
        for (int i = Listv->getSelIndex(); i < c; i++)
        {
            offset = Listv->getUlong(i, 0, 16) - (ULONG)GetCommonReadAddress();
            szCmd = Disasm((PBYTE)GetCommonReadBuffer() + offset, GetCommonReadSize() - offset, (ULONG)GetCommonReadAddress() + offset, &da, DISASM_SIZE);
            memset((PBYTE)GetCommonReadBuffer() + offset, 0x90, szCmd);
            KiWriteVirtualMemory(KiCurrentProcess.ProcessObject, (PVOID)((ULONG)GetCommonReadAddress() + offset), (PBYTE)GetCommonReadBuffer() + offset, szCmd);
        }
        if	(KiReadVirtualMemory(KiCurrentProcess.ProcessObject, GetCommonReadAddress(), (PBYTE)GetCommonReadBuffer(), GetCommonReadSize()))
            PrintDisasm((PBYTE)GetCommonReadBuffer(), GetCommonReadAddress(), GetCommonReadSize());
        break;
    }
    case	DISASM_COPY_ADDRESS:
    {
        List_Disasm->getSelText(0, Temp, sizeof(Temp));
        SetClipboard(Temp);
        break;
    }
    case	DISASM_COPY_HEX:
    {
        List_Disasm->getSelText(1, Temp, sizeof(Temp));
        SetClipboard(Temp);
        break;
    }
    case	DISASM_COPY_COMMAND:
    {
        int c = List_Disasm->getSelCount() + Listv->getSelIndex();
        WCHAR* text = (WCHAR*)malloc(c*BUFFER_LEN);
        RtlZeroMemory(text, c*BUFFER_LEN);
        for (int i = Listv->getSelIndex(); i < c; i++)
        {
            wcscat(text, List_Disasm->getText(i, 2, Temp, sizeof(Temp)));
            wcscat(text, L"\r\n");
        }
        SetClipboard(text);
        free(text);
        break;
    }
    case	DISASM_COPY_ASM:
    {
        WCHAR ClpBuffer[512];
        List_Disasm->getSelText(0, Temp, sizeof(Temp));
        offset = wcstoul(Temp, 0, 16) - (ULONG)GetCommonReadAddress();
        szCmd = Disasm((PBYTE)GetCommonReadBuffer() + offset, GetCommonReadSize() - offset, (ULONG)GetCommonReadAddress() + offset, &da, DISASM_SIZE);
        ClpBuffer[0] = 0;
        Temp[0] = 0;
        for	(ULONG i = 0; i < szCmd; i++)
        {
            if ((*((PBYTE)GetCommonReadBuffer() + offset + i) >> 4) >= 0x0a)
                swprintf(Temp, i != szCmd - 1 ? L"0%02Xh, " : L"0%02Xh", *((PBYTE)GetCommonReadBuffer() + offset + i));
            else
                swprintf(Temp, i != szCmd - 1 ? L"%02Xh, " : L"%02Xh", *((PBYTE)GetCommonReadBuffer() + offset + i));
            wcscat(ClpBuffer, Temp);
        }
        SetClipboard(ClpBuffer);
        break;
    }
    case	DISASM_COPY_C:
    {
        WCHAR ClpBuffer[512];
        List_Disasm->getSelText(0, Temp, sizeof(Temp));
        offset = wcstoul(Temp, 0, 16) - (ULONG)GetCommonReadAddress();
        szCmd = Disasm((PBYTE)GetCommonReadBuffer() + offset, GetCommonReadSize() - offset, (ULONG)GetCommonReadAddress() + offset, &da, DISASM_SIZE);
        ClpBuffer[0] = 0;
        Temp[0] = 0;
        for	(ULONG i = 0; i < szCmd; i++)
        {
            swprintf(Temp, (i!=szCmd-1 ? L"0x%02X, " : L"0x%02X"), *((PBYTE)GetCommonReadBuffer() + offset + i));
            wcscat(ClpBuffer, Temp);
        }
        SetClipboard(ClpBuffer);
        break;
    }
    case	DISASM_COPY_DELPHI:
    {
        WCHAR ClpBuffer[512];
        List_Disasm->getSelText(0, Temp, sizeof(Temp));
        offset = wcstoul(Temp, 0, 16) - (ULONG)GetCommonReadAddress();
        szCmd = Disasm((PBYTE)GetCommonReadBuffer() + offset, GetCommonReadSize() - offset, (ULONG)GetCommonReadAddress() + offset, &da, DISASM_SIZE);
        ClpBuffer[0] = 0;
        Temp[0] = 0;
        for	(ULONG i = 0; i < szCmd; i++)
        {
            swprintf(Temp, (i!=szCmd-1 ? L"$%02X, " : L"$%02X"), *((PBYTE)GetCommonReadBuffer() + offset + i));
            wcscat(ClpBuffer, Temp);
        }
        SetClipboard(ClpBuffer);
        break;
    }
    case	RANGE_OK:
    {
        WCHAR* stopstring = 0;
        GetDlgItemText(hWin, RANGE_START, Temp, 11);
        range_address = wcstoul(Temp, &stopstring, 16);
        if	(stopstring[0])
        {
            Err(L"Invalid Address, make sure you write it in hex format !");
            break;
        }
        GetDlgItemText(hWin, RANGE_SIZE, Temp, 11);
        range_size = wcstoul(Temp, &stopstring, 16);
        if	(stopstring[0] || !range_size)
        {
            Err(L"Invalid Size, make sure you write it in hex format !");
            break;
        }
        else
        {
            if (range_size > 0x4000)
            {
                range_size = 0x4000;
                SetDlgItemText(hWin, RANGE_SIZE, L"0x4000");
            }
        }
        EndDialog(hWin, TRUE);
        break;
    };
    case	RANGE_EXIT:
    {
        EndDialog(hWin, FALSE);
        break;
    };
    case	ASSEMBLE_OK:
    {
        CHAR ErrText[512];
        Asmline[0] = 0;
        ULONG x, y, n=0, m=0, l;
        GetDlgItemTextA(hWin, ASSEMBLE_CMD, Asmline, 64);
        l = Assemble(Asmline, List_Disasm->getSelUlong(0, 16), &sa, 0, 0, ErrText);
        for (x = 0; x < 3; ++x)
        {
            for (y = 0; y <= 3; ++y)
            {
                szCmd = Assemble(Asmline, List_Disasm->getSelUlong(0, 16), &sa, x, y, ErrText);
                if	(szCmd <= 0) 
                    goto assemble;
                if (szCmd < l)
                {
                    l = szCmd;
                    n = x;
                    m = y;
                };
            };
        };
assemble:
        if (szCmd <= 0 && x == 0 && y == 0)
        {
            SetDlgItemTextA(hWin, ASSEMBLE_LOG, ErrText);
            break;
        };
        szCmd = Assemble(Asmline, List_Disasm->getSelUlong(0, 16), &sa, n, m, ErrText);
        offset = List_Disasm->getSelUlong(0, 16) - (ULONG)GetCommonReadAddress();
        for	(szCmd = 0; szCmd < (ULONG)sa.length; )
            szCmd += Disasm((PBYTE)GetCommonReadBuffer() + offset + szCmd, GetCommonReadSize()-offset-szCmd, (ULONG)GetCommonReadAddress() + offset + szCmd, &da, DISASM_SIZE);
        if	(IsDlgButtonChecked(hWin, ASSEMBLE_NOP) == BST_CHECKED)
        {
            memset((PBYTE)GetCommonReadBuffer() + offset, 0x90, szCmd);
            memcpy((PBYTE)GetCommonReadBuffer() + offset, sa.code, sa.length);
            KiWriteVirtualMemory(KiCurrentProcess.ProcessObject, (PVOID)((ULONG)GetCommonReadAddress() + offset), (PBYTE)GetCommonReadBuffer() + offset, szCmd);
        }
        else
        {
            memcpy((PBYTE)GetCommonReadBuffer() + offset, sa.code, sa.length);
            KiWriteVirtualMemory(KiCurrentProcess.ProcessObject, (PVOID)((ULONG)GetCommonReadAddress() + offset), (PBYTE)GetCommonReadBuffer() + offset, sa.length);
        }
        if	(KiReadVirtualMemory(KiCurrentProcess.ProcessObject, GetCommonReadAddress(), (PBYTE)GetCommonReadBuffer(), GetCommonReadSize()))
            PrintDisasm((PCHAR)GetCommonReadBuffer(), GetCommonReadAddress(), GetCommonReadSize());
        EndDialog(hWin, FALSE);
        break;
    }
    case	ASSEMBLE_EXIT:
    {
        EndDialog(hWin, FALSE);
        break;
    }
    case	HEXA_OK:
    {
        List_Disasm->getSelText(0, Temp, sizeof(Temp));
        offset = wcstoul(Temp, 0, 16) - (ULONG)GetCommonReadAddress();
        GetDlgItemText(hWin, HEXA_HEX, Temp, GetWindowTextLength(GetDlgItem(hWin, HEXA_HEX))+1);
        ConvertHexToBytes(Temp, (PBYTE)GetCommonReadBuffer() + offset, (UINT *)&szCmd);
        KiWriteVirtualMemory(KiCurrentProcess.ProcessObject, (PVOID)((ULONG)GetCommonReadAddress() + offset), (PBYTE)GetCommonReadBuffer() + offset, szCmd);
        if	(KiReadVirtualMemory(KiCurrentProcess.ProcessObject, GetCommonReadAddress(), (PBYTE)GetCommonReadBuffer(), GetCommonReadSize()))
            PrintDisasm((PBYTE)GetCommonReadBuffer(), GetCommonReadAddress(), GetCommonReadSize());
        EndDialog(hWin, FALSE);
        break;
    }
    case	HEXA_EXIT:
    {
        EndDialog(hWin, FALSE);
        break;
    }
    }
    return;
}







BOOL CALLBACK EditHex(HWND hWin, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    WCHAR	chCharCode = (WCHAR)wParam;
    LRESULT	result = FALSE;
    WCHAR	Temp[BUFFER_LEN] = L"";

    switch (uMsg)
    {
    case WM_CHAR:
        if	(!isxdigit(wParam) && wParam != VK_BACK)
        {
            return false;
        }
        InvalidateRect(hWin, NULL, TRUE);
        break;
    case WM_PASTE:
        return false;
    }
    return CallWindowProc(Hexa_hex_winproc, hWin, uMsg, wParam, lParam);
}




BOOL CALLBACK DlgAssemble(HWND hWin, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    WCHAR		Temp[BUFFER_LEN] = L"";
    t_disasm	da;
    DWORD offset;
    static HBRUSH backclr = 0;


    WCHAR	h[16];
    switch (uMsg)
    {
    case	WM_INITDIALOG:
    {
        backclr = CreateSolidBrush(settings.clr_back);
        offset = List_Disasm->getSelUlong(0, 16) - (ULONG)GetCommonReadAddress();
        Disasm((PBYTE)GetCommonReadBuffer() + offset, GetCommonReadSize() - offset, (ULONG)GetCommonReadAddress() + offset, &da, DISASM_FILE);
        SetDlgItemTextA(hWin, ASSEMBLE_CMD, da.result);
        wcscpy(Temp, L"Assemble @ ");
        wcscat(Temp, List_Disasm->getSelText(0, h, sizeof(h)));
        SetWindowText(hWin, Temp);
        CheckDlgButton(hWin, ASSEMBLE_NOP, BST_CHECKED);
        SubclassEditBox(GetDlgItem(hWin, ASSEMBLE_CMD));
        break;
    };
    case WM_DESTROY:
    {
        DeleteObject(backclr);
        break;
    };
    case WM_COMMAND:
    {
        Disassembler_Cmd(hWin, wParam, lParam, List_Disasm);
        break;
    };
    case WM_CTLCOLOREDIT:
    {
        if	((HWND)lParam == GetDlgItem(hWin, ASSEMBLE_CMD))
        {
            SetBkMode((HDC)wParam, TRANSPARENT);
            SetTextColor((HDC)wParam, settings.clr_front);
            SetBkColor((HDC)wParam, settings.clr_back);
            return (BOOL)backclr;
        }
        return false;
    };
    case WM_CTLCOLORSTATIC:
    {
        if	((HWND)lParam == GetDlgItem(hWin, ASSEMBLE_LOG))
        {
            SetBkMode((HDC)wParam, TRANSPARENT);
            SetTextColor((HDC)wParam, settings.clr_front);
            return (BOOL)backclr;
        }
        return false;
    };
    default:
        return false;
    };
    return true;
};




BOOL CALLBACK DlgDisasm(HWND hWin, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    POINT		XY;
    static CListView List_Disasm(hWin);
    ::List_Disasm = &List_Disasm;
    HFONT hFont;

    switch (uMsg)
    {
    case	WM_INITDIALOG :
        DlgDisasmHwnd = hWin;
        hFont = CreateFont(-13, 0,0,0,0,0,0,0,0,0,0,0,0, L"Courier New");
        SendDlgItemMessage(hWin, DISASM_DUMP, WM_SETFONT, (WPARAM)hFont, MAKELPARAM(TRUE, 0));
        List_Disasm.create(0, 0, 0, 0, settings.GetBackClr(), settings.GetFrontClr(), 0);
        List_Disasm.insertColumn(L"Address", 80);
        List_Disasm.insertColumn(L"Hex Dump", 100);
        List_Disasm.insertColumn(L"Disassembly", 400);
        List_Disasm.insertColumn(L"Comments", 400);
        Menu_Disasm = GetSubMenu(LoadMenu(hInstance, MAKEINTRESOURCE(MENU_DISASM)), 0);
        SubclassEditBox(GetDlgItem(hWin, DISASM_DUMP));
        break;
    case	WM_COMMAND :
    {
        Disassembler_Cmd(hWin, wParam, lParam, &List_Disasm);
        break;
    }
    case	WM_SHOWWINDOW:
    {
        if (wParam)
        {
            status.Format(L"");
            CurrentList = &List_Disasm;
        }
        break;
    }
    case WM_SIZE:
    {
        if(wParam != SIZE_MINIMIZED)
        {
            ULONG ListHight = (HIWORD(lParam)*1)/2;
            List_Disasm.resize(0, 0, LOWORD(lParam), ListHight);
            MoveWindow(GetDlgItem(hWin, DISASM_DUMP), 0, 2 + ListHight, LOWORD(lParam), HIWORD(lParam) - ListHight - 2, TRUE);
        }
        break;
    }
    case WM_CTLCOLORSTATIC:
    {
        if	((HWND)lParam == GetDlgItem(hWin, DISASM_DUMP))
        {
            SetBkMode((HDC)wParam, TRANSPARENT);
            SetTextColor((HDC)wParam, settings.clr_front);
            return (BOOL)CreateSolidBrush(settings.clr_back);
        }
        break;
    };
    case	WM_NOTIFY :
        if(((LPNMHDR)lParam)->code == NM_CUSTOMDRAW && ((LPNMHDR)lParam)->hwndFrom == List_Disasm.getHwnd())
        {
            SetWindowLong(hWin, DWL_MSGRESULT, (LONG)Listview_handler((LPNMLVCUSTOMDRAW)lParam, 0, 0, 0, &List_Disasm));
            return TRUE;
        }
        if	(((LPNMHDR)lParam)->hwndFrom == List_Disasm.getHwnd())
        {
            if	(((LPNMHDR)lParam)->code == NM_RCLICK)
            {
                MENUITEMINFO mii;
                mii.cbSize = sizeof(MENUITEMINFO);
                mii.fMask = MIIM_STATE;
                if	(0 == List_Disasm.isRawSelected())
                {
                    mii.fState = MFS_GRAYED;
                    for (long n = 1; n < GetMenuItemCount(Menu_Disasm); ++n)
                    {
                        SetMenuItemInfo(Menu_Disasm, n, TRUE, &mii);
                        //EnableMenuItem(Menu_Disasm, GetMenuItemID(Menu_Disasm, n), MF_BYCOMMAND | MF_GRAYED);
                    }
                }
                else
                {
                    mii.fState = MFS_ENABLED;
                    for (long n = 1; n < GetMenuItemCount(Menu_Disasm); ++n)
                    {
                        SetMenuItemInfo(Menu_Disasm, n, TRUE, &mii);
                        //EnableMenuItem(Menu_Disasm, GetMenuItemID(Menu_Disasm, n), MF_BYCOMMAND | MF_ENABLED);
                    }
                }
                GetCursorPos(&XY);
                TrackPopupMenu(Menu_Disasm, TPM_LEFTALIGN, XY.x, XY.y, NULL, hWin, NULL);
            }
            else if	(((LPNMHDR)lParam)->code == NM_DBLCLK && List_Disasm.isRawSelected())
            {
                Disassembler_Cmd(hWin, DISASM_ASSEMBLE, lParam, &List_Disasm);
            }
        }
        break;
    }
    return 0;
}



WCHAR HEX_FORMAT[] = L" %.2x %.2x %.2x %.2x"
                     L" %.2x %.2x %.2x %.2x"
                     L" %.2x %.2x %.2x %.2x"
                     L" %.2x %.2x %.2x %.2x";

WCHAR DUMP_FORMAT[] = L"................................ !\"#$%&'()*+,-./0123456789"
                      L":;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklm"
                      L"nopqrstuvwxyz{|}~...................................."
                      L"....................................................."
                      L"...................................................";
void PrintDisasm(void *lpData, void *lpAddress, SIZE_T cb)
{
    WCHAR Temp[BUFFER_LEN];
    WCHAR Symbol[BUFFER_LEN];
    t_disasm da;
    ULONG address = (ULONG)lpAddress;
    PUCHAR data = (PUCHAR)lpData;
    ULONG displacement;


    List_Disasm->beginRefresh();
    List_Disasm->clear();
    TabCtrl_SetCurSel(hTab, 5);
    SwitchTab();
    UPDATE_MODULES();
    for	(unsigned int offset = 0; offset < cb;)
    {
        offset += Disasm((PUCHAR)data + offset, cb - offset, address + offset, &da, DISASM_CODE);
        if (DecodeSymbol(da.ip, &displacement, Symbol, COF(Symbol), TRUE) && displacement == 0)
        {
            swprintf(Temp, L"0x%p %s", da.ip, Symbol);
        }
        else
        {
            swprintf(Temp, L"0x%p", da.ip);
        }
        List_Disasm->insertRaw(Temp, true);			// address

        if (da.error == DAE_CROSS)
        {
            swprintf(Temp, L"%S", da.dump);
            List_Disasm->insertRaw(Temp, false);		// hex dump

            List_Disasm->insertRaw(L"???", false);		// disasm

            swprintf(Temp, L"%S", da.comment);
            List_Disasm->insertRaw(Temp, false);		// comment
        }
        else
        {
            swprintf(Temp, L"%S", da.dump);
            List_Disasm->insertRaw(Temp, false);		// hex dump

            swprintf(Temp, L"%S", da.result);
            List_Disasm->insertRaw(Temp, false);		// disasm

            swprintf(Temp, L"%S", da.comment);
            List_Disasm->insertRaw(Temp, false);		// comment
        }
    };

    List_Disasm->endRefresh();

    PWCHAR HexDump = new WCHAR [alignNumber(cb, 16)*6 + 16*(alignNumber(cb, 16)/16)];
    HexDump[0] = 0;
    for (ULONG i = 0; i < cb; i += 16)
    {
        swprintf(Temp, L"0x%p :", i + address);
        wcscat(HexDump, Temp);
        swprintf(Temp, HEX_FORMAT,
                 data[i + 0x0], data[i + 0x1], data[i + 0x2], data[i + 0x3],
                 data[i + 0x4], data[i + 0x5], data[i + 0x6], data[i + 0x7],
                 data[i + 0x8], data[i + 0x9], data[i + 0xa], data[i + 0xb],
                 data[i + 0xc], data[i + 0xd], data[i + 0xe], data[i + 0xf]);
        wcscat(HexDump, Temp);
        for (ULONG a = 0; a < 16; ++a)
        {
            Temp[a] = DUMP_FORMAT[data[i + a]];
        }
        Temp[16] = 0;
        wcscat(HexDump, L"\t");
        wcscat(HexDump, Temp);
        wcscat(HexDump, L"\r\n");
    }
    SetDlgItemText(DlgDisasmHwnd, DISASM_DUMP, HexDump);
    delete[] HexDump;
};


BOOL CALLBACK DlgHexa(HWND hWin, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    WCHAR	Temp[BUFFER_LEN];
    WCHAR	h[MAXCMDSIZE*2];
    HFONT	hFont;

    switch (uMsg)
    {
    case	WM_INITDIALOG :
        hFont = CreateFont(-11, 0,0,0,FW_BOLD,0,0,0,0,0,0,0,0, L"Courier New");
        SendDlgItemMessage(hWin, HEXA_HEX, WM_SETFONT, (WPARAM)hFont, MAKELPARAM(TRUE, 0));
        List_Disasm->getSelText(1, Temp, sizeof(Temp));
        RtlZeroMemory(h, sizeof(h));
        for	(ULONG i = 0, k = 0; i < wcslen(Temp); i++)
        {
            if	(Temp[i]!=' ')
            {
                h[k] = Temp[i];
                k++;
            }
        }
        SetDlgItemText(hWin, HEXA_HEX, h);
        wcscpy(Temp, L"Hex Editing @ ");
        wcscat(Temp, List_Disasm->getSelText(0, h, sizeof(h)));
        SetWindowText(hWin, Temp);
        Hexa_hex_winproc = (WNDPROC)SetWindowLong(Hexa_hex_hwnd=GetDlgItem(hWin, HEXA_HEX), GWL_WNDPROC, (LONG)EditHex);
        break;
    case	WM_COMMAND :
        Disassembler_Cmd(hWin, wParam, lParam, List_Disasm);
        break;
    case	WM_CTLCOLOREDIT:
        if	(((HWND)lParam == GetDlgItem(hWin, HEXA_ASCII))||((HWND)lParam == GetDlgItem(hWin, HEXA_HEX)))
        {
            SetBkMode((HDC)wParam, TRANSPARENT);
            SetTextColor((HDC)wParam, settings.clr_front);
            return (BOOL)CreateSolidBrush(settings.clr_back);
        }
        break;
    }
    return 0;
}





BOOL CALLBACK DlgRange(HWND hWin, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    WCHAR	Temp[BUFFER_LEN];
    switch (uMsg)
    {
    case	WM_INITDIALOG:
    {
        swprintf(Temp, L"0x%p", range_address);
        SetDlgItemText(hWin, RANGE_START, Temp);
        swprintf(Temp, L"0x%x", range_size);
        SetDlgItemText(hWin, RANGE_SIZE, Temp);
        SubclassEditBox(GetDlgItem(hWin, RANGE_START));
        SubclassEditBox(GetDlgItem(hWin, RANGE_SIZE));
        break;
    }
    case	WM_COMMAND :
        Disassembler_Cmd(hWin, wParam, lParam, List_Disasm);
        break;
    case	WM_CTLCOLOREDIT:
        if	(((HWND)lParam == GetDlgItem(hWin, RANGE_START))||((HWND)lParam == GetDlgItem(hWin, RANGE_SIZE)))
        {
            SetBkMode((HDC)wParam, TRANSPARENT);
            SetTextColor((HDC)wParam, settings.clr_front);
            return (BOOL)CreateSolidBrush(settings.clr_back);
        }
        break;
    }
    return 0;
};