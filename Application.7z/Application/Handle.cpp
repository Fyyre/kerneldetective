#include	"Kernel Detective.h"
#include	"Handle.h"
#include	"Disassemble.h"

HMENU Menu_Handle;





void EnumHandles(PPROCESS_ENTRY process, CListView *Listv)
{
	PHANDLE_ENTRY hInfo;
	ULONG		count, found = 0;
	WCHAR		Temp[BUFFER_LEN] = L"";
	PWCHAR		ObjectTypeName;
	

	Listv->beginRefresh();
	//__try
	{
        UPDATE_MODULES();
        count = EnumerateHandles(&hInfo, process->ProcessObject);
		Listv->clear();
		if (hInfo)
		{
			for (ULONG c = 0; c < count; ++c)
			{
				_snwprintf_s(Temp, COF(Temp), L"0x%x", hInfo[c].Handle);
				Listv->insertRaw(Temp, TRUE);

				_snwprintf_s(Temp, COF(Temp), L"0x%p", hInfo[c].Object);
				Listv->insertRaw(Temp, FALSE);

				ObjectTypeName = GetTypeName(hInfo[c].ObjectType);
				if (ObjectTypeName && ObjectTypeName[0])
				{
					wcsncpy_s(Temp, COF(Temp), ObjectTypeName, _TRUNCATE);
				}
				else
				{
					wcsncpy_s(Temp, COF(Temp), L"?TYPE?", _TRUNCATE);
				}
				Listv->insertRaw(Temp, FALSE);

				_snwprintf_s(Temp, COF(Temp), L"%u", hInfo[c].HandleCount);
				Listv->insertRaw(Temp, FALSE);

				_snwprintf_s(Temp, COF(Temp), L"0x%x", hInfo[c].GrantedAccess);
				Listv->insertRaw(Temp, FALSE);

				wcsncpy_s(Temp, COF(Temp), L"-", _TRUNCATE);
				if (hInfo[c].Name[0])
				{
					wcsncpy_s(Temp, COF(Temp), hInfo[c].Name, _TRUNCATE);
				};
				if (ObjectTypeName && ObjectTypeName[0])
				{
					if (!_wcsnicmp(L"FILE", ObjectTypeName, wcslen(L"FILE")))
					{
                        decodefilepath(Temp, COF(Temp));
						QueryEnvironmentString(Temp, Temp, 512);
					}
					else if (!_wcsnicmp(L"PROCESS", ObjectTypeName, wcslen(L"PROCESS")))
					{
                        for (ULONG i = 0; i < KiProcessCount; ++i)
						{
                            if (hInfo[c].Object == KiProcessList[i].ProcessObject)
							{
                                wcsncpy_s(Temp, COF(Temp), KiProcessList[i].Name, _TRUNCATE);
								break;
							};
						};
					}
					else if (!_wcsnicmp(L"THREAD", ObjectTypeName, wcslen(L"THREAD")))
					{
						PROCESS_ENTRY Process;
						THREAD_ENTRY Thread;
						RtlZeroMemory(&Process, sizeof(Process));
						RtlZeroMemory(&Thread, sizeof(Thread));
                        GetThreadProcessInformation(hInfo[c].Object, &Process, &Thread);
						if (Process.ProcessObject)
						{
							WCHAR dec_addr[MAX_PATH];
							_snwprintf_s(Temp, COF(Temp), L"%s[%u:%u] :: %s", PathToFileName(Process.Name), Process.Pid, Thread.Cid, decodethreadaddr(dec_addr, (ULONG)Thread.Address));
						};
					};
				};
				Listv->insertRaw(Temp, FALSE);
                if (ObjectTypeName)
                    delete ObjectTypeName;
				++found;
			};
			delete[] hInfo;
		};
	}
	//__except(1)
	{};

	Listv->endRefresh();
	status.Format(L"Total Handles :: %d", found);
}






void CALLBACK Handle_Cmd(HWND hWin, WPARAM wParam, LPARAM lParam, CListView *Listv)
{

	switch	(wParam)
	{
	case HANDLE_REFRESH:
		{
			EnumHandles(&KiCurrentProcess, Listv);
			break;
		};
	case HANDLE_GOTO:
		{
			UpdateCommonBuffer(Listv->getSelUlong(1, 16), 0x400);
			if (KiReadVirtualMemory(KiCurrentProcess.ProcessObject, GetCommonReadAddress(), GetCommonReadBuffer(), GetCommonReadSize()))
				PrintDisasm(GetCommonReadBuffer(), GetCommonReadAddress(), GetCommonReadSize());
			break;
		};
	case HANDLE_CLOSE:
		{
			int c = Listv->getSelCount() + Listv->getSelIndex();
			for (int i = Listv->getSelIndex(); i < c; i++)
			{
                CloseProcessHandle(KiCurrentProcess.ProcessObject, (HANDLE)Listv->getUlong(i, 0, 16));
			};
			EnumHandles(&KiCurrentProcess, Listv);
            break;
		};
	};
    return;
};




BOOL CALLBACK DlgHandle(HWND hWin,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
    POINT		XY;
	static CListView List_Handle(hWin);

    switch (uMsg)
    {
    case	WM_INITDIALOG :
		List_Handle.create(0, 0, 0, 0, settings.clr_back, settings.clr_front, 0);
		List_Handle.insertColumn(L"Handle", 60);
		List_Handle.insertColumn(L"Address", 80);
		List_Handle.insertColumn(L"Type", 120);
		List_Handle.insertColumn(L"Refs", 40);
		List_Handle.insertColumn(L"Attributes", 80);
		List_Handle.insertColumn(L"Name", 350);
        Menu_Handle = GetSubMenu(LoadMenu(hInstance,MAKEINTRESOURCE(MENU_HANDLE)),0);
        break;
	case	WM_SHOWWINDOW:
		if (wParam)
		{
			EnumHandles(&KiCurrentProcess, &List_Handle);
			CurrentList = &List_Handle;
		}
		break;
    case	WM_COMMAND :
		Handle_Cmd(hWin, wParam, lParam, &List_Handle);
        break;
	case WM_SIZE:
		{
			if(wParam != SIZE_MINIMIZED)
				List_Handle.resize(0, 0, LOWORD(lParam),HIWORD(lParam));
			break;
		}
    case	WM_NOTIFY :
		if	(((LPNMHDR)lParam)->hwndFrom == List_Handle.getHwnd()  &&  ((LPNMHDR)lParam)->code == NM_RCLICK)
        {
			if	(0 == List_Handle.isRawSelected())	break;
            GetCursorPos(&XY);
            TrackPopupMenu(Menu_Handle,TPM_LEFTALIGN,XY.x,XY.y,NULL,hWin,NULL);
        }
		if(((LPNMHDR)lParam)->code == LVN_COLUMNCLICK)
		{
			((LPNMLISTVIEW)lParam)->lParam = (LPARAM)&List_Handle;
			ListView_SortItemsEx(((LPNMHDR)lParam)->hwndFrom, CListView::sort, (LPNMLISTVIEW)lParam);
			return TRUE;
		}
		if(((LPNMHDR)lParam)->code == NM_CUSTOMDRAW)
		{
			SetWindowLong(hWin, DWL_MSGRESULT, (LONG)Listview_handler((LPNMLVCUSTOMDRAW)lParam, 0, 0, 0, &List_Handle));
			return TRUE;
		}
        break;
    }
    return 0;
}
