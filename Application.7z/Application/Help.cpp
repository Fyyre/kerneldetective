#include "Kernel Detective.h"

#include <Softpub.h>
#include <wincrypt.h>
#include <wintrust.h>
#include <mscat.h>

#pragma comment(lib, "wintrust")



void Msg( PWCHAR Text )
{
	MessageBox(gWin, Text, AppName, MB_OK | MB_ICONINFORMATION);
};

void Msg( int num )
{
	WCHAR buffer[64];
	wsprintf(buffer, L"0x%p <-> %ld", num, num);
	MessageBox(gWin, buffer, AppName, MB_OK | MB_ICONINFORMATION);
};

void Err( PWCHAR Text )
{
	MessageBox(gWin, Text, AppName, MB_OK | MB_ICONERROR);
};


VOID ShowFilePropertiesDlg(PWCHAR FilePath)
{
	SHELLEXECUTEINFO ShExecInfo ={0};
	ShExecInfo.cbSize = sizeof(SHELLEXECUTEINFO);
	ShExecInfo.fMask = SEE_MASK_INVOKEIDLIST | SEE_MASK_FLAG_NO_UI;
	ShExecInfo.hwnd = NULL;
	ShExecInfo.lpVerb = L"properties";
	ShExecInfo.lpParameters = L"";
	ShExecInfo.lpDirectory = NULL;
	ShExecInfo.nShow = SW_SHOW;
	ShExecInfo.hInstApp = NULL;
	ShExecInfo.lpFile = FilePath;
    if (!ShellExecuteEx(&ShExecInfo) && GetLastError() == ERROR_FILE_NOT_FOUND)
    {
        WCHAR Buffer[MAX_PATH], RootPath[MAX_PATH];

        GetSystemDirectory(RootPath, COF(RootPath));
        _snwprintf(Buffer, COF(Buffer), L"%s\\%s", RootPath, PathToFileName(FilePath));
        ShExecInfo.lpFile = Buffer;
        if (!ShellExecuteEx(&ShExecInfo) && GetLastError() == ERROR_FILE_NOT_FOUND)
        {
            _snwprintf(Buffer, COF(Buffer), L"%s\\drivers\\%s", RootPath, PathToFileName(FilePath));
            ShExecInfo.lpFile = Buffer;
            ShellExecuteEx(&ShExecInfo);
        }
    }
}




// Convert a two-letter string to a byte.  Returns FALSE if any characters in the string are invalid.
BOOL HexToByte(WCHAR *pcText, unsigned char *pbReturn)
{
	*pbReturn = 0;
	for ( INT I = 0; I < 2; I++ ) {
		if (pcText[I] >= '0' && pcText[I] <= '9') 
		{
			(*pbReturn) |= (pcText[I] - '0') << ((1 - I) * 4);
			continue;
		};
		if (pcText[I] >= 'A' && pcText[I] <= 'F')
		{
			(*pbReturn) |= (pcText[I] - 'A' + 10) << ((1 - I) * 4);
			continue;
		};
		if (pcText[I] >= 'a' && pcText[I] <= 'f') 
		{
			(*pbReturn) |= (pcText[I] - 'a' + 10) << ((1 - I) * 4);
			continue;
		};
		return false;
	};
	return true;
};

// Convert a string of hex values to bytes
BOOL ConvertHexToBytes(WCHAR *pcText, unsigned char *pbReturn, unsigned int *pdwLength)
{
	*pdwLength = 0;
	int iLength = wcslen(pcText);

	int iNewLength = 0;
	WCHAR *pcNewText = new WCHAR[iLength+1];
	

	// Remove spaces.
	for (int I = 0; I < iLength; I++) 
	{
		if (pcText[I] == ' ' || pcText[I] == '\t') continue;
		pcNewText[iNewLength++] = pcText[I];
	};
	pcNewText[iNewLength] = 0;

	// If the string is not an even number in length, add a 0 to the front.
	if (iNewLength % 2 != 0) 
	{
		WCHAR *pcBuffer = new WCHAR[iNewLength+2];
		wsprintf( pcBuffer, L"0%s", pcNewText );
		delete[] pcNewText;
		pcNewText = new WCHAR[iNewLength+2];
		wcsncpy_s(pcNewText, iNewLength, pcBuffer, _TRUNCATE);
		delete[] pcBuffer;
		iNewLength++;
	};



	// Convert every two characters into a byte.
	for (int I = 0; I < iNewLength; I += 2) 
	{
		if (!HexToByte( &pcNewText[I], &pbReturn[(*pdwLength)++])) 
		{
			delete[] pcNewText;
			return false;
		};
	};

	delete[] pcNewText;
	return true;
};

void SetClipboard(const WCHAR* WideStr)
{
	OpenClipboard(NULL);
	EmptyClipboard();

	SIZE_T Length = wcslen(WideStr);
	HGLOBAL hMem = GlobalAlloc(GHND, Length + 1);
	PCHAR MultiStr = (PCHAR)GlobalLock(hMem);
	WideCharToMultiByte(CP_ACP, 0, WideStr, -1, MultiStr, Length, NULL, NULL);
	GlobalUnlock(hMem);
	SetClipboardData(CF_TEXT, hMem);
	CloseClipboard();
}


PWCHAR PathToFileName(PWCHAR Str)
{
	for	(unsigned long i = wcslen(Str) - 1; i > 0; --i)
    {
		if (Str[i] == L'\\')
        {
			return Str+i+1;
        }
    }
	return Str;
};

PWCHAR PathToDirectory(PWCHAR Str)
{
	for	(unsigned long i = wcslen(Str); i > 0; --i)
	{
		if	(Str[i] == '\\')
		{
			Str[i+1] = TEXT('\0');
			break;
		}
	}
	return Str;
};


WCHAR *decodefilepath(WCHAR *path, SIZE_T Count)
{
	WCHAR deviceName[BUFFER_LEN];
	WCHAR letter[3] = L"A:";
	

    

	if (!_wcsnicmp(path, L"\\??\\", wcslen(L"\\??\\")))
	{
		wcsncpy_s(path, Count, path + 4, _TRUNCATE);
	}
    else if (!_wcsnicmp(path, L"\\\\?\\", wcslen(L"\\\\?\\")))
    {
		wcsncpy_s(path, Count, path + 4, _TRUNCATE);
	}

	if (!wcsncmp(L"\\Device\\HarddiskVolume", path, wcslen(L"\\Device\\HarddiskVolume")))
	{
		int i;

		for (i = wcslen(L"\\Device\\HarddiskVolume"); path[i] != '\\'; ++i);

		for (letter[0] = 'A'; letter[0] <= 'Z'; ++letter[0])
		{
			QueryDosDevice(letter, deviceName, sizeof(deviceName));
			if (!wcsncmp(deviceName, path, i))
			{
				_snwprintf_s(deviceName, COF(deviceName), L"%s%s", letter, path+wcslen(deviceName));
				wcsncpy(path, deviceName, Count);
				break;
			}
		}
	}

    if (wcslen(path) >= MAX_PATH)
    {
        wcsncpy_s(deviceName, MAX_PATH, PathToFileName(path), _TRUNCATE);
        wcsncpy_s(path, Count, deviceName, _TRUNCATE);
    }

	return path;
};


PWCHAR
QueryEnvironmentString(
	PWCHAR lpSrc,
	PWCHAR lpDst,
	DWORD nCount
	)
{
    if (!_wcsnicmp(lpSrc, L"\\WINDOWS\\", wcslen(L"\\WINDOWS\\")))
	{
		PWCHAR WinDir = new WCHAR [MAX_PATH];
		PWCHAR Source = new WCHAR [nCount];

		wcsncpy_s(Source, nCount, lpSrc, _TRUNCATE);
		GetWindowsDirectory(WinDir, MAX_PATH);
		wcsncpy_s(lpDst, nCount, WinDir, _TRUNCATE);
		wcsncat_s(lpDst, nCount, Source + wcslen(L"\\WINDOWS"), _TRUNCATE);
		delete Source;
        delete WinDir;
		return lpDst;
	}
	else if (lpSrc[0] == '\\')
	{
		SIZE_T Length = wcslen(lpSrc);
		PWCHAR buffer = new WCHAR [nCount + 1];
		PWCHAR Source = new WCHAR [Length + 1];
		wcsncpy_s(buffer, nCount, lpSrc, _TRUNCATE);
		wcsncpy_s(Source, nCount, lpSrc, _TRUNCATE);
		buffer[0] = '%';
		for (unsigned long i = 1; i < Length; i++)
		{
			if (lpSrc[i] == '\\')
			{
				wcsncpy_s(buffer + i + 1, nCount - i, lpSrc + i, _TRUNCATE);
				buffer[i] = '%';
				break;
			}
		}
		if (!ExpandEnvironmentStrings(buffer, lpDst, nCount))
		{
			wcsncpy_s(lpDst, nCount, Source, _TRUNCATE);
		}
		if (lpDst[0] == '%')
		{
			wcsncpy_s(lpDst, nCount, Source, _TRUNCATE);
		}
		delete[] buffer;
		delete[] Source;
		return lpDst;
	}
	return lpSrc;
};


WCHAR *decodethreadaddr(WCHAR *buffer, unsigned long address)
{
	WCHAR Temp[BUFFER_LEN] = L"";
	IMAGEHLP_MODULEW ModuleInfo;

	_snwprintf(buffer, MAX_PATH, L"0x%p", address);
	if (!address) return buffer;
	GetModulePath(address, Temp, BUFFER_LEN);
	if (!_wcsnicmp(Temp, L"\\??\\", 4))
	{
		_snwprintf_s(buffer, MAX_PATH, _TRUNCATE, L"0x%p :: %s", address, PathToFileName(Temp + 4));
	}
	else if (Temp[0] != '-')
	{
		_snwprintf_s(buffer, MAX_PATH, _TRUNCATE, L"0x%p :: %s", address, PathToFileName(QueryEnvironmentString(Temp, Temp, BUFFER_LEN)));
	}
	else
	{
		RtlZeroMemory(&ModuleInfo, sizeof(ModuleInfo));
		ModuleInfo.SizeOfStruct = sizeof(ModuleInfo);
		SymGetModuleInfoW(NtCurrentProcess(), address, &ModuleInfo);
		if (ModuleInfo.BaseOfImage)
		{
			_snwprintf_s(buffer, MAX_PATH, _TRUNCATE, L"0x%p :: %s+%x", address, ModuleInfo.ModuleName, address - ModuleInfo.BaseOfImage);
		};
	};
	return buffer;
};


KFILE::KFILE()
{
	RtlZeroMemory(this->KPath, sizeof(WCHAR) * MAX_PATH);
}


KFILE::~KFILE()
{
	if ((INVALID_HANDLE_VALUE == this->KHandle)||(0 == this->KHandle))
		return;
	CloseHandle(this->KHandle);
}


HANDLE KFILE::KGetHandle()
{
	return this->KHandle;
}


BOOL KFILE::KCreateFile(HWND Owner, PWCHAR path)
{
	if (path)
		wcsncpy_s(this->KPath, COF(this->KPath), path, _TRUNCATE);

	if (this->KPath[0])
	{
		this->KHandle = CreateFile(this->KPath, GENERIC_READ|GENERIC_WRITE, 0, 0,
			CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
		if (INVALID_HANDLE_VALUE != this->KHandle)
			return true;
	}
	else
	{
		OPENFILENAME ofn;
		RtlZeroMemory(&ofn, sizeof(OPENFILENAME));
		ofn.lStructSize = sizeof(OPENFILENAME);
		ofn.hwndOwner = Owner;
		ofn.lpstrFilter = L"All Files(*.*)\0*.*\0\0";
		ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_LONGNAMES;
		ofn.nMaxFile = MAX_PATH;
		ofn.lpstrFile = this->KPath;
		ofn.lpstrTitle = L"Create file ...";
		if (GetSaveFileName(&ofn))
		{
			this->KHandle = CreateFile(this->KPath, GENERIC_READ|GENERIC_WRITE, 0, 0,
				CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
			if (INVALID_HANDLE_VALUE != this->KHandle)
				return true;
		}
	}
	return false;
}


BOOL KFILE::KOpenFile(HWND Owner, PWCHAR path)
{
	if (path)
		wcsncpy_s(this->KPath, COF(this->KPath), path, _TRUNCATE);

	if (this->KPath[0])
	{
		this->KHandle = CreateFile(this->KPath, GENERIC_READ|GENERIC_WRITE, 0, 0,
			OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
		if (INVALID_HANDLE_VALUE != this->KHandle)
			return true;
	}
	else
	{
		OPENFILENAME ofn;
		RtlZeroMemory(&ofn, sizeof(OPENFILENAME));
		ofn.lStructSize = sizeof(OPENFILENAME);
		ofn.hwndOwner = Owner;
		ofn.lpstrFilter = L"All Files(*.*)\0*.*\0\0";
		ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_LONGNAMES;
		ofn.nMaxFile = MAX_PATH;
		ofn.lpstrFile = this->KPath;
		ofn.lpstrTitle = L"Create file ...";
		if (GetOpenFileName(&ofn))
		{
			this->KHandle = CreateFile(this->KPath, GENERIC_READ|GENERIC_WRITE, 0, 0,
				OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
			if (INVALID_HANDLE_VALUE != this->KHandle)
				return true;
		}
	}
	return false;
}


BOOL KFILE::KReadFile(PVOID Offset, PVOID lpBuffer, SIZE_T szBuffer)
{
	DWORD dwRet;
	if ((INVALID_HANDLE_VALUE == this->KHandle)||(0 == this->KHandle))
		return false;
	if (INVALID_SET_FILE_POINTER != SetFilePointer(this->KHandle, (LONG)Offset, 0, FILE_BEGIN))
		return ReadFile(this->KHandle, lpBuffer, szBuffer, &dwRet, 0);
	return false;
}


BOOL KFILE::KWriteFile(PVOID Offset, PVOID lpBuffer, SIZE_T szBuffer)
{
	DWORD dwRet;
	if ((INVALID_HANDLE_VALUE == this->KHandle)||(0 == this->KHandle))
		return false;
	if (INVALID_SET_FILE_POINTER != SetFilePointer(this->KHandle, (LONG)Offset, 0, FILE_BEGIN))
		return WriteFile(this->KHandle, lpBuffer, szBuffer, &dwRet, 0);
	return false;
}


BOOLEAN IsFileDigitallySigned(PWCHAR FilePath)
{
    //Author: AD, 2009
    PVOID Context;
    HANDLE FileHandle;
    DWORD HashSize = 0;
    PBYTE Buffer;
    PVOID CatalogContext;
    CATALOG_INFO InfoStruct;
    WINTRUST_DATA WintrustStructure;
    WINTRUST_CATALOG_INFO WintrustCatalogStructure;
    WINTRUST_FILE_INFO WintrustFileStructure;
    PWCHAR MemberTag;
    BOOLEAN ReturnFlag = FALSE;
    ULONG ReturnVal;
    GUID ActionGuid = WINTRUST_ACTION_GENERIC_VERIFY_V2;

    //Zero our structures.
    memset(&InfoStruct, 0, sizeof(CATALOG_INFO));
    InfoStruct.cbStruct = sizeof(CATALOG_INFO);
    memset(&WintrustCatalogStructure, 0, sizeof(WINTRUST_CATALOG_INFO));
    WintrustCatalogStructure.cbStruct = sizeof(WINTRUST_CATALOG_INFO);
    memset(&WintrustFileStructure, 0, sizeof(WINTRUST_FILE_INFO));
    WintrustFileStructure.cbStruct = sizeof(WINTRUST_FILE_INFO);

    //Get a context for signature verification.
    if( !CryptCATAdminAcquireContext(&Context, NULL, 0) )
    {
        return FALSE;
    }

    //Open file.
    FileHandle = CreateFileW(FilePath, GENERIC_READ, 7, NULL, OPEN_EXISTING, 0, NULL);
    if (INVALID_HANDLE_VALUE == FileHandle && GetLastError() == ERROR_FILE_NOT_FOUND)
    {
        WCHAR Buffer[MAX_PATH], RootPath[MAX_PATH];

        GetSystemDirectory(RootPath, COF(RootPath));
        _snwprintf(Buffer, COF(Buffer), L"%s\\%s", RootPath, PathToFileName(FilePath));
        FileHandle = CreateFileW(Buffer, GENERIC_READ, 7, NULL, OPEN_EXISTING, 0, NULL);
        if (INVALID_HANDLE_VALUE == FileHandle && GetLastError() == ERROR_FILE_NOT_FOUND)
        {
            _snwprintf(Buffer, COF(Buffer), L"%s\\drivers\\%s", RootPath, PathToFileName(FilePath));
            FileHandle = CreateFileW(Buffer, GENERIC_READ, 7, NULL, OPEN_EXISTING, 0, NULL);
        }
        if (INVALID_HANDLE_VALUE != FileHandle)
            FilePath = Buffer;
    }
    if( INVALID_HANDLE_VALUE == FileHandle )
    {
        CryptCATAdminReleaseContext(Context, 0);
        return FALSE;
    }

    //Get the size we need for our hash.
    CryptCATAdminCalcHashFromFileHandle(FileHandle, &HashSize, NULL, 0);
    if( HashSize == 0 )
    {
        //0-sized has means error!
        CryptCATAdminReleaseContext(Context, 0);
        CloseHandle(FileHandle);
        return FALSE;
    }

    //Allocate memory.
    Buffer = (PBYTE)calloc(HashSize, 1);

    //Actually calculate the hash
    if( !CryptCATAdminCalcHashFromFileHandle(FileHandle, &HashSize, Buffer, 0) )
    {
        CryptCATAdminReleaseContext(Context, 0);
        free(Buffer);
        CloseHandle(FileHandle);
        return FALSE;
    }

    //Convert the hash to a string.
    MemberTag = (PWCHAR)calloc((HashSize + 1) * 2, sizeof(WCHAR));
    for( unsigned int i = 0; i < HashSize; i++ )
    {
        _snwprintf_s(&MemberTag[i * 2], (HashSize + 1 - i) * 2, _TRUNCATE, L"%02X", Buffer[i]);
    }

    //Get catalog for our context.
    CatalogContext = CryptCATAdminEnumCatalogFromHash(Context, Buffer, HashSize, 0, NULL);
    if ( CatalogContext )
    {
        //If we couldn't get information
        if ( !CryptCATCatalogInfoFromContext(CatalogContext, &InfoStruct, 0) )
        {
            //Release the context and set the context to null so it gets picked up below.
            CryptCATAdminReleaseCatalogContext(Context, CatalogContext, 0);
            CatalogContext = NULL;
        }
    }
        
    //If we have a valid context, we got our info.  
    //Otherwise, we attempt to verify the internal signature.
    if( !CatalogContext )
    {
        WintrustFileStructure.cbStruct = sizeof(WINTRUST_FILE_INFO);
        WintrustFileStructure.pcwszFilePath = FilePath;
        WintrustFileStructure.hFile = NULL;
        WintrustFileStructure.pgKnownSubject = NULL;

        WintrustStructure.cbStruct = sizeof(WINTRUST_DATA);
        WintrustStructure.dwUnionChoice = WTD_CHOICE_FILE;
        WintrustStructure.pFile = &WintrustFileStructure;
        WintrustStructure.dwUIChoice = WTD_UI_NONE;
        WintrustStructure.fdwRevocationChecks = WTD_REVOKE_NONE;
        WintrustStructure.dwStateAction = WTD_STATEACTION_IGNORE;
        WintrustStructure.dwProvFlags = WTD_SAFER_FLAG;
        WintrustStructure.hWVTStateData = NULL;
        WintrustStructure.pwszURLReference = NULL;
    } else
    {
        //If we get here, we have catalog info!  Verify it.
        WintrustStructure.cbStruct = sizeof(WINTRUST_DATA);
        WintrustStructure.pPolicyCallbackData = 0;
        WintrustStructure.pSIPClientData = 0;
        WintrustStructure.dwUIChoice = WTD_UI_NONE;
        WintrustStructure.fdwRevocationChecks = WTD_REVOKE_NONE;
        WintrustStructure.dwUnionChoice = WTD_CHOICE_CATALOG;
        WintrustStructure.pCatalog = &WintrustCatalogStructure;
        WintrustStructure.dwStateAction = WTD_STATEACTION_VERIFY;
        WintrustStructure.hWVTStateData = NULL;
        WintrustStructure.pwszURLReference = NULL;
        WintrustStructure.dwProvFlags = 0;
        WintrustStructure.dwUIContext = WTD_UICONTEXT_EXECUTE;

        //Fill in catalog info structure.
        WintrustCatalogStructure.cbStruct = sizeof(WINTRUST_CATALOG_INFO);
        WintrustCatalogStructure.dwCatalogVersion = 0;
        WintrustCatalogStructure.pcwszCatalogFilePath = InfoStruct.wszCatalogFile;
        WintrustCatalogStructure.pcwszMemberTag = MemberTag;
        WintrustCatalogStructure.pcwszMemberFilePath = FilePath;
        WintrustCatalogStructure.hMemberFile = NULL;
    }

    //Call our verification function.
    ReturnVal = WinVerifyTrust(0, &ActionGuid, &WintrustStructure);

    //Check return.
    ReturnFlag = SUCCEEDED(ReturnVal);

    //Free context.
    if( CatalogContext )
        CryptCATAdminReleaseCatalogContext(Context, CatalogContext, 0);

    //If we successfully verified, we need to free.
    if( ReturnFlag )
    {
        WintrustStructure.dwStateAction = WTD_STATEACTION_CLOSE;
        WinVerifyTrust(0, &ActionGuid, &WintrustStructure);
    }

    //Free memory.
    free(MemberTag);
    free(Buffer);
    CloseHandle(FileHandle);
    CryptCATAdminReleaseContext(Context, 0);

    return ReturnFlag;
}