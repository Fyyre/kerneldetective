#pragma once
#include <windows.h>
#include "ntdll.h"
#include <math.h>


#ifdef __cplusplus
	extern "C" {
#else
	extern {
#endif

#define DBGHELP_TRANSLATE_WCHAR


extern PWCHAR BasicKernelFiles[];
extern ULONG nBasicKernelFiles;

NTSTATUS
WINAPI
ZwDeviceIoControlFile(
	HANDLE	FileHandle,
	HANDLE	Event,
	PVOID	ApcRoutine,
	PVOID	ApcContext,
	PVOID	IoStatusBlock,
	ULONG	IoControlCode,
	PVOID	InputBuffer,
	ULONG	InputBufferLength,
	PVOID	OutputBuffer,
	ULONG	OutputBufferLength
	);


#define FILE_DEVICE_CORE  0x00008300
#define CORE_IOCTL_INDEX  0x830
#define CODE(CTL)						CTL_CODE(FILE_DEVICE_CORE,CTL,METHOD_NEITHER,FILE_ANY_ACCESS)
typedef enum _IOCTL{
	IOCTL_INITIALIZE				=CODE(CORE_IOCTL_INDEX + 0),
	IOCTL_ENUM_PROCESS				=CODE(CORE_IOCTL_INDEX + 1),
	IOCTL_VM_READ					=CODE(CORE_IOCTL_INDEX + 2),
	IOCTL_VM_WRITE					=CODE(CORE_IOCTL_INDEX + 3),
	IOCTL_PROCESS_KILL_FORCE		=CODE(CORE_IOCTL_INDEX + 4),
	IOCTL_ENUM_DLL					=CODE(CORE_IOCTL_INDEX + 5),
	IOCTL_DBG_MSG					=CODE(CORE_IOCTL_INDEX + 6),
	IOCTL_ENUM_SSDT					=CODE(CORE_IOCTL_INDEX + 7),
	IOCTL_SET_SSDT					=CODE(CORE_IOCTL_INDEX + 8),
	IOCTL_ENUM_IDT					=CODE(CORE_IOCTL_INDEX + 9),
	IOCTL_GET_MODULE				=CODE(CORE_IOCTL_INDEX + 10),
	IOCTL_IDT_OFFSET				=CODE(CORE_IOCTL_INDEX + 11),
	IOCTL_IDT_SELECTOR				=CODE(CORE_IOCTL_INDEX + 12),
	IOCTL_ENUM_SHADOW_SSDT			=CODE(CORE_IOCTL_INDEX + 13),
	IOCTL_SET_SHADOW_SSDT			=CODE(CORE_IOCTL_INDEX + 14),
	IOCTL_ENUM_HOOKS				=CODE(CORE_IOCTL_INDEX + 15),
	IOCTL_UNHOOK_KERNEL				=CODE(CORE_IOCTL_INDEX + 16),
	IOCTL_ENUM_HANDLES				=CODE(CORE_IOCTL_INDEX + 17),
	IOCTL_PROCESS_KILL				=CODE(CORE_IOCTL_INDEX + 18),
	IOCTL_ENUM_DRIVER				=CODE(CORE_IOCTL_INDEX + 19),
	IOCTL_RESTORE_SSDT				=CODE(CORE_IOCTL_INDEX + 20),
	IOCTL_RESTORE_SHADOW_SSDT		=CODE(CORE_IOCTL_INDEX + 21),
	IOCTL_HOOK_KIDEBUGSERVICE		=CODE(CORE_IOCTL_INDEX + 22),
	IOCTL_UNHOOK_KIDEBUGSERVICE		=CODE(CORE_IOCTL_INDEX + 23),
	IOCTL_ALLOCATE_PROCESS_VM		=CODE(CORE_IOCTL_INDEX + 24),
	IOCTL_DEALLOCATE_PROCESS_VM		=CODE(CORE_IOCTL_INDEX + 25),
	IOCTL_PROCESS_OPEN				=CODE(CORE_IOCTL_INDEX + 26),
	IOCTL_CLOSE_HANDLE				=CODE(CORE_IOCTL_INDEX + 27),
	IOCTL_UPDATE_MODULE_LIST		=CODE(CORE_IOCTL_INDEX + 28),
	IOCTL_THREAD_TO_PROCESS			=CODE(CORE_IOCTL_INDEX + 29),
	IOCTL_GET_OBJECT_TYPE			=CODE(CORE_IOCTL_INDEX + 30),
	IOCTL_ENUM_THREADS				=CODE(CORE_IOCTL_INDEX + 31),
	IOCTL_THREAD_KILL_FORCE			=CODE(CORE_IOCTL_INDEX + 32),
	IOCTL_THREAD_SET_SSDT			=CODE(CORE_IOCTL_INDEX + 33),
	IOCTL_THREAD_RESTORE_SSDT		=CODE(CORE_IOCTL_INDEX + 34),
	IOCTL_THREAD_SUSPEND			=CODE(CORE_IOCTL_INDEX + 35),
	IOCTL_PROCESS_SUSPEND			=CODE(CORE_IOCTL_INDEX + 36),
	IOCTL_THREAD_RESUME				=CODE(CORE_IOCTL_INDEX + 37),
	IOCTL_PROCESS_RESUME			=CODE(CORE_IOCTL_INDEX + 38),
	IOCTL_ENUM_UNLOADED_DRIVERS		=CODE(CORE_IOCTL_INDEX + 39),
	IOCTL_ENUM_TIMERS				=CODE(CORE_IOCTL_INDEX + 40),
	IOCTL_ENUM_OBJECT_TYPES			=CODE(CORE_IOCTL_INDEX + 41),
	IOCTL_CANCEL_TIMER				=CODE(CORE_IOCTL_INDEX + 42),
	IOCTL_CHANGE_OBJECT_PROC		=CODE(CORE_IOCTL_INDEX + 43),
	IOCTL_ENUM_IMAGE_NOTIFY			=CODE(CORE_IOCTL_INDEX + 44),
	IOCTL_ENUM_PROCESS_NOTIFY		=CODE(CORE_IOCTL_INDEX + 45),
	IOCTL_ENUM_THREAD_NOTIFY		=CODE(CORE_IOCTL_INDEX + 46),
	IOCTL_ENUM_LEGO_NOTIFY			=CODE(CORE_IOCTL_INDEX + 47),
	IOCTL_ENUM_CM_NOTIFY			=CODE(CORE_IOCTL_INDEX + 48),
	IOCTL_DELETE_NOTIFY				=CODE(CORE_IOCTL_INDEX + 49),
	IOCTL_DELETE_FILE				=CODE(CORE_IOCTL_INDEX + 50),
	IOCTL_COPY_FILE					=CODE(CORE_IOCTL_INDEX + 51),
	IOCTL_ENUM_BUGCHECK				=CODE(CORE_IOCTL_INDEX + 52),
	IOCTL_ENUM_BUGCHECK_REASON		=CODE(CORE_IOCTL_INDEX + 53),
	IOCTL_DUMP_PHYSICAL_MEMORY		=CODE(CORE_IOCTL_INDEX + 54),
	IOCTL_ENUM_THREAD_TRACE			=CODE(CORE_IOCTL_INDEX + 55),
	IOCTL_THREAD_OPEN				=CODE(CORE_IOCTL_INDEX + 56),
	IOCTL_UNMAP_SECTION				=CODE(CORE_IOCTL_INDEX + 57),
	IOCTL_GET_PROCESS_INFO			=CODE(CORE_IOCTL_INDEX + 58),
	IOCTL_PROCESS_BY_PID			=CODE(CORE_IOCTL_INDEX + 59),
	IOCTL_PROCESS_BY_HANDLE			=CODE(CORE_IOCTL_INDEX + 60),
	IOCTL_GET_THREAD_INFO			=CODE(CORE_IOCTL_INDEX + 61),
	IOCTL_THREAD_BY_PID				=CODE(CORE_IOCTL_INDEX + 62),
	IOCTL_THREAD_BY_HANDLE			=CODE(CORE_IOCTL_INDEX + 63),
	IOCTL_GET_THREAD_CONTEXT		=CODE(CORE_IOCTL_INDEX + 64),
	IOCTL_SET_THREAD_CONTEXT		=CODE(CORE_IOCTL_INDEX + 65),
	IOCTL_GET_MEMORY_INFO			=CODE(CORE_IOCTL_INDEX + 66),
	IOCTL_ALLOC_NONPAGED_POOL		=CODE(CORE_IOCTL_INDEX + 67),
	IOCTL_FREE_NONPAGED_POOL		=CODE(CORE_IOCTL_INDEX + 68),
	IOCTL_PROTECT_PROCESS_VM		=CODE(CORE_IOCTL_INDEX + 69),
	IOCTL_QUERY_PROCESS_VM			=CODE(CORE_IOCTL_INDEX + 70),
	IOCTL_PHYSICAL_PAGE_READ		=CODE(CORE_IOCTL_INDEX + 71),
	IOCTL_PHYSICAL_PAGE_WRITE		=CODE(CORE_IOCTL_INDEX + 72),
	IOCTL_GET_FILENAME_BY_OBJECT	=CODE(CORE_IOCTL_INDEX + 73),
	IOCTL_GET_FILENAME_BY_HANDLE	=CODE(CORE_IOCTL_INDEX + 74),
	IOCTL_READ_FILE_BY_HANDLE		=CODE(CORE_IOCTL_INDEX + 75),
	IOCTL_WRITE_FILE_BY_HANDLE		=CODE(CORE_IOCTL_INDEX + 76),
	IOCTL_READ_FILE_BY_NAME			=CODE(CORE_IOCTL_INDEX + 77),
	IOCTL_WRITE_FILE_BY_NAME		=CODE(CORE_IOCTL_INDEX + 78),
	IOCTL_OPEN_FILE					=CODE(CORE_IOCTL_INDEX + 79),
	IOCTL_ENUM_DEVICES				=CODE(CORE_IOCTL_INDEX + 80),
	IOCTL_GET_DRIVER_INFO			=CODE(CORE_IOCTL_INDEX + 81),
	IOCTL_GET_OBJECT_NAME			=CODE(CORE_IOCTL_INDEX + 82),
	IOCTL_GET_CONTROL_REG			=CODE(CORE_IOCTL_INDEX + 83),
	IOCTL_SET_CONTROL_REG			=CODE(CORE_IOCTL_INDEX + 84),
	IOCTL_GET_KERNEL_INFO			=CODE(CORE_IOCTL_INDEX + 85)
}IOCTL;


#define SCAN_NORMAL		(0x00000001L)
#define SCAN_BRUTE		(0x00000002L)


typedef struct _IO_INPUT_BUFFER {
	union {
		ULONG Key;
		struct {
			ULONG Index : CHAR_BIT;
		};
	};
	ULONG ControlCode[UCHAR_MAX + 1];
	PVOID InputBuffer[UCHAR_MAX + 1];
} IO_INPUT_BUFFER, *PIO_INPUT_BUFFER;


typedef struct _SDT {
	ULONG			Index;
	ULONG			Current;
	ULONG			Original;
	ULONG			Status;
	WCHAR			Module[MAX_PATH];
}SDT, *LPSDT;

typedef	struct _PROCESS {
	ULONG	eProcess;
	ULONG	ImageBase;
	ULONG	PEB;
	ULONG	Status;
	ULONG	pid;
	ULONG	parent;
	ULONG	cb;
	WCHAR	Name[MAX_PATH];
}PROCESS,*LPPROCESS;

typedef struct _THREAD_INFO {
	PVOID	Process;
	PVOID	ParentId;
	PVOID	Thread;
	HANDLE	Cid;
	struct _TEB	*Teb;
	PVOID	ServiceTable;
	PVOID	Address;
	ULONG	Type;
	ULONG	ThreadState;
	ULONG	WaitReason;
	ULONG	Status;
} THREAD_INFO, *LPTHREAD_INFO;

typedef struct _DRIVER {
	PVOID	ImageBase;
	PVOID	DriverObject;
	PVOID	Unload;
	PVOID	EntryPoint;
	ULONG	ImageSize;
	WCHAR	ImagePath[MAX_PATH];
} DRIVER, *LPDRIVER;

typedef struct _KIDTENTRY {
	USHORT Offset;
	USHORT Selector;
	struct {
		USHORT __unnamed1	: 8;
		USHORT type			: 2;
		USHORT __unnamed2	: 1;
		USHORT size			: 2;
		USHORT DPL			: 2;
		USHORT P			: 1;
	} Access;
	USHORT ExtendedOffset;
} KIDTENTRY, *PKIDTENTRY;

typedef struct _HANDLE_INFORMATION {
    PVOID		QuotaProcess;
	PVOID		UniqueProcessId;
    HANDLE		Handle;
    PVOID		Object;
    ULONG		GrantedAccess;
	ULONG		HandleCount;
	WCHAR		Name[260];
} HANDLE_INFORMATION, *PHANDLE_INFORMATION;

typedef struct _OBJECT_TYPE_INFO {
	PVOID Address;
	DWORD Count;
	DWORD Index;
	struct {
		PVOID DumpProcedure;
		PVOID OpenProcedure;
		PVOID CloseProcedure;
		PVOID DeleteProcedure;
		PVOID ParseProcedure;
		PVOID SecurityProcedure;
		PVOID QueryNameProcedure;
		PVOID OkayToCloseProcedure;
	} ProcedureTable;
	WCHAR Name[MAX_PATH];
} OBJECT_TYPE_INFO, *POBJECT_TYPE_INFO;

typedef	struct	_HOOKED_BLOCK {
	DWORD			ImageBase;
	DWORD			RVA;
	DWORD			cb;
	DWORD			State;
	DWORD			Destination;
	DWORD			lparam;
	UCHAR			Origin[64];
	UCHAR			Current[64];
} HOOKED_BLOCK, *LPHOOKED_BLOCK;


typedef struct _DISPATCHER_HEADER {
    UCHAR Type;
    UCHAR Absolute;
    UCHAR Size;
    UCHAR Inserted;
    LONG SignalState;
    LIST_ENTRY WaitListHead;
} DISPATCHER_HEADER;

typedef struct _KDPC {
    SHORT Type;
    UCHAR Number;
    UCHAR Importance;
    LIST_ENTRY DpcListEntry;
    PVOID DeferredRoutine;
    PVOID DeferredContext;
    PVOID SystemArgument1;
    PVOID SystemArgument2;
    PULONG_PTR Lock;
} KDPC, *PKDPC, *RESTRICTED_POINTER PRKDPC;

typedef struct _KTIMER {
    DISPATCHER_HEADER Header;
    ULARGE_INTEGER DueTime;
    LIST_ENTRY TimerListEntry;
    struct _KDPC *Dpc;
    LONG Period;
} KTIMER, *PKTIMER, *RESTRICTED_POINTER PRKTIMER;

typedef struct _TIMER_INFO {
	PVOID Object;
	PVOID Thread;
	KTIMER Timer;
	KDPC Dpc;
} TIMER_INFO, *PTIMER_INFO;


class device
{
public:
	device(WCHAR *device_name, WCHAR *driver_path, short NtBuild);
	~device(void);
	BOOL load(BOOL hookDbgService);
	void unload(void);
	long __fastcall syscall(IOCTL ioctl, void *buffer, BOOL naked = 0);
	LPSDT enumSdt(long &count);
	LPSDT enumSdtShadow(long &count);
	LPPROCESS enumProcesses(long &count, unsigned long uflags);
	LPTHREAD_INFO enumThreads(unsigned long process, ULONG &count, unsigned long uflags);
	LPDRIVER enumDrivers(long &count);
	void **enumDevices(long &count);
	LPDRIVER getDriverInfo(unsigned long driver);
	wchar_t *getObjectName(unsigned long object);
	LPHOOKED_BLOCK enumKernelHooks(WCHAR * path, ULONG &count, unsigned long uflags);
	PKIDTENTRY enumIdt(long cpu);
	PHANDLE_INFORMATION enumHandles(unsigned long process, long &count);
	BOOL readVM(unsigned long process, void *address, void *buffer, unsigned long size);
	BOOL writeVM(unsigned long process, void *address, void *buffer, unsigned long size);
	BOOL readPhysicalPages(PLARGE_INTEGER pfn, void *buffer, unsigned long nPages);
	BOOL writePhysicalPages(PLARGE_INTEGER pfn, void *buffer, unsigned long nPages);
	void *updateVM(unsigned long address, unsigned long size);
	void *getVMaddress();
	void *getVMbuffer();
	unsigned long getVMsize();
	void *allocVM(unsigned long process, unsigned long size);
	void freeVM(unsigned long process, void *address, unsigned long size);
	BOOL protectVM(unsigned long process, void *address, unsigned long size, unsigned long newCode, unsigned long *oldCode);
	BOOL queryVM(unsigned long process, void *address, PMEMORY_BASIC_INFORMATION buffer, unsigned long size);
	BOOL unmapSection(unsigned long process, void *base);
	HANDLE getProcessHandle(unsigned long process, unsigned long pid);
	HANDLE getThreadHandle(unsigned long thread, unsigned long tid);
	WCHAR *getObjectType(void *object, WCHAR *objectname);
	LPTHREAD_INFO threadToProcess(unsigned long thread, LPPROCESS process, LPTHREAD_INFO thread_info);
	BOOL closeHandle(HANDLE handle, unsigned long process, unsigned long pid = 0);
	unsigned long getEntrypoint(unsigned long process, unsigned long imagebase);
	BOOL forceKillProcess(unsigned long process);
	BOOL forceKillThread(unsigned long thread);
	BOOL suspendProcess(unsigned long process);
	BOOL suspendThread(unsigned long thread);
	BOOL resumeProcess(unsigned long process, BOOL force);
	BOOL resumeThread(unsigned long thread, BOOL force);
	BOOL captureStackContext(unsigned long thread, PCONTEXT Context);
	BOOL getThreadContext(unsigned long thread, PCONTEXT context);
	BOOL setThreadContext(unsigned long thread, PCONTEXT context);
	BOOL deleteFile(WCHAR *filename, BOOL forcedelete);
	BOOL copyFile(WCHAR *source, WCHAR *dest);
	void *hookIntOffset(long index, void *address, unsigned char cpu);
	void *hookIntSelector(long index, void *selector, unsigned char cpu);
	WCHAR *getModulePath(unsigned long address, WCHAR *module, unsigned long size);
	void free_symbols(void);
	void initiate_symbols(void);
	BOOL decodesymbol(unsigned long address, unsigned long &disp, WCHAR *symbol, BOOL decodemodule = 0);
	unsigned long getNTcount();
	unsigned long getGDIcount();
	BOOL isdbghooked();
	WCHAR **ServiceTable;
	WCHAR **ShadowServiceTable;
	unsigned long *RealIdt;
	LPPROCESS processes;
	long processes_count;
	unsigned short NtBuildNumber;
	WCHAR *getError();
	WCHAR *getKernelFileName(){return this->KernelFileName;};

private:
	BOOL initiateDevice(BOOL hookDbgService);
	WCHAR **getServiceNames(void);
	unsigned long NTmax;
	unsigned long GDImax;
	unsigned long *NT;
	unsigned long *GDI;
	WCHAR errormsg[512];
	WCHAR symbolic[128];
	WCHAR path[MAX_PATH];
	HANDLE handle;
	BOOL hookdbg;
	unsigned long readbuffer;
	unsigned long readaddress;
	unsigned long readsize;
	WCHAR KernelFileName[260];
};


#define UPDATE_MODULES()\
	{\
		kd->syscall(IOCTL_UPDATE_MODULE_LIST, NULL, TRUE);\
	}

#ifdef __cplusplus
	}
#endif