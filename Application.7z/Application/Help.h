#include <math.h>


void 
Msg( 
	PWCHAR Text 
	);


void
Msg(
	int num 
	);


void 
Err( 
	PWCHAR Text 
	);

VOID ShowFilePropertiesDlg(PWCHAR FilePath);


BOOL
ConvertHexToBytes(
	WCHAR *pcText,
	unsigned char *pbReturn,
	unsigned int *pdwLength
	);


void
SetClipboard(
	const WCHAR* str
	);


PWCHAR PathToFileName(PWCHAR Str);
PWCHAR PathToDirectory(PWCHAR Str);
PWCHAR decodefilepath(PWCHAR path, SIZE_T Count);


PWCHAR
QueryEnvironmentString(
	PWCHAR lpSrc,
	PWCHAR lpDst,
	DWORD nSize
	);


PWCHAR decodethreadaddr(PWCHAR buffer, unsigned long address);


BOOLEAN IsFileDigitallySigned(PWCHAR FilePath);

class KFILE
{
public:
	KFILE();
	~KFILE();
	HANDLE KGetHandle();
	BOOL KCreateFile(HWND Owner, PWCHAR path);
	BOOL KOpenFile(HWND Owner, PWCHAR path);
	BOOL KReadFile(PVOID Offset, PVOID lpBuffer, SIZE_T szBuffer);
	BOOL KWriteFile(PVOID Offset, PVOID lpBuffer, SIZE_T szBuffer);
private:
	HANDLE KHandle;
	WCHAR KPath[MAX_PATH];
};


ULONG __inline alignNumber(ULONG number, ULONG alignment)
{
	return (ULONG)(ceil(number / (alignment + 0.0)) * alignment);
}