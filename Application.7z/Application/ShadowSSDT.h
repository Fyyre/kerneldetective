

void EnumShadowSSDT(CListView*);

