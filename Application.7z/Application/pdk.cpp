#include	"Kernel Detective.h"
#include	"pdk.h"




ULONG PluginsCount;
CPlugin **PluginsList;
PWCHAR PluginsLogBuffer;
ULONG PluginsLogSize;





//
// Plugins system core
//

VOID InitializePlugins()
{
	WCHAR PluginSearchPath[260];
	WCHAR PluginDirPath[260];
	WCHAR PluginFilePath[260];
	PPLUGIN_ENTRY PluginEntry;
	HANDLE hFind;
	WIN32_FIND_DATA FindFileData;
	HMODULE hModule;
	KD_INIT_PLUGIN KdInitPlugin = NULL;


    PluginsLogSize = 1 * sizeof(WCHAR);
    PluginsLogBuffer = (PWCHAR)malloc(PluginsLogSize);
    PluginsLogBuffer[0] = L'\0';
	if (GetModuleFileName(NULL, PluginDirPath, 260) > 0)
	{
		PathToDirectory(PluginDirPath);
		wcsncat_s(PluginDirPath, L"Plugins\\", wcslen(L"Plugins\\"));
		_snwprintf_s(PluginSearchPath, COF(PluginSearchPath), L"%s*.kdp", PluginDirPath);
		hFind = FindFirstFile(PluginSearchPath, &FindFileData);
		if (hFind != INVALID_HANDLE_VALUE)
		{
			do
			{
				_snwprintf_s(PluginFilePath, COF(PluginFilePath), L"%s%s", PluginDirPath, FindFileData.cFileName);
				hModule = LoadLibrary(PluginFilePath);
				if (hModule != NULL)
				{
					KdInitPlugin = (KD_INIT_PLUGIN)GetProcAddress(hModule, "KdInitPlugin");
					if (KdInitPlugin)
					{
						PluginEntry = KdInitPlugin(&RoutineTable, PLUGIN_VERSION);
						if (PluginEntry)
						{
                            KdWriteLog(L"$SYSTEM: Plugin \"%s\" loaded", PluginEntry->PluginTitle, FindFileData.cFileName);
                            PluginsList = (CPlugin **)realloc(PluginsList, sizeof(PVOID) * (PluginsCount + 1));
                            PluginsList[PluginsCount] = new CPlugin(hModule, PluginEntry);
                            PluginsCount++;
						}
                        else
                        {
                            FreeLibrary(hModule);
                        }
					}
					else
					{
						FreeLibrary(hModule);
					}
				}
			} while(FindNextFile(hFind, &FindFileData));
			FindClose(hFind);
		}
	}
    KdWriteLog(L"$SYSTEM: Plugins count = %lu \r\n", PluginsCount);
}

VOID DestroyPlugins()
{
	KD_DESTROY_PLUGIN KdDestroyPlugin;
	for (ULONG Index = 0; Index < PluginsCount; Index++)
	{
		KdDestroyPlugin = (KD_DESTROY_PLUGIN)PluginsList[Index]->GetPluginRoutine("KdDestroyPlugin");
		if (IsBadCodePtr((FARPROC)KdDestroyPlugin))
		{
			delete PluginsList[Index];
			continue;
		}
		KdDestroyPlugin();
        delete PluginsList[Index];
	}
    free(PluginsLogBuffer);
    free(PluginsList);
}

BOOL KdIsValidPointer(PVOID Pointer, SIZE_T Size = sizeof(PVOID))
{
    if (Pointer == NULL)
        return FALSE;
    return (IsBadReadPtr(Pointer, Size) == FALSE);
}

VOID KdCallOnProcessChange(PROCESS_ENTRY *NewProcess)
{
	KD_ON_PROCESS_CHANGE KdOnProcessChange;
	PROCESS_INFO NewProcessEx;

	NewProcessEx.ImageBase = NewProcess->ImageBase;
	NewProcessEx.ParentId = NewProcess->ParentId;
	wcsncpy_s(NewProcessEx.Path, NewProcess->Name, STRING_LENGTH);
	NewProcessEx.Peb = (ULONG)NewProcess->Peb;
	NewProcessEx.ProcessId = NewProcess->Pid;
	NewProcessEx.ProcessObject = (ULONG)NewProcess->ProcessObject;
	NewProcessEx.VirtualSize = NewProcess->Cb;
	for (ULONG Index = 0; Index < PluginsCount; Index++)
	{
		KdOnProcessChange = (KD_ON_PROCESS_CHANGE)PluginsList[Index]->GetPluginRoutine("KdOnProcessChange");
		if (IsBadCodePtr((FARPROC)KdOnProcessChange))
			continue;
		KdOnProcessChange(&NewProcessEx);
	}
}


INT_PTR CALLBACK DlgConsole(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    static HWND hwndLog;

    switch (uMsg)
    {
    case WM_INITDIALOG:
        hwndLog = GetDlgItem(hwndDlg, PLUGIN_LOG_WINDOW);
        SendMessage(hwndLog, 
                    WM_SETFONT,
                    (WPARAM)CreateFont(-11, 0,0,0,0,0,0,0,0,0,0,0,0, L"Courier New"),
                    MAKELPARAM(TRUE, 0));
        SetDlgItemText(hwndDlg, PLUGIN_LOG_WINDOW, PluginsLogBuffer);
        PostMessage(hwndLog, EM_SETSEL, -1, -1);
        PostMessage(hwndLog, EM_SCROLLCARET, 0, 0);
        break;

    case WM_COMMAND:
        if (wParam == PLUGIN_CONSOLE_CLEAR)
        {
            PluginsLogSize = 1 * sizeof(WCHAR);
            free(PluginsLogBuffer);
            PluginsLogBuffer = (PWCHAR)malloc(PluginsLogSize);
            PluginsLogBuffer[0] = L'\0';

            SetDlgItemText(hwndDlg, PLUGIN_LOG_WINDOW, PluginsLogBuffer);
            PostMessage(GetDlgItem(hwndDlg, PLUGIN_LOG_WINDOW), EM_SETSEL, 0, 0);
        }
        break;

    case WM_CTLCOLORSTATIC:
        if ((HWND)lParam == GetDlgItem(hwndDlg, PLUGIN_LOG_WINDOW))
        {
            SetBkColor((HDC)wParam, 0);
            SetTextColor((HDC)wParam, RGB(0xff, 0xff, 0xff));
            return (BOOL)CreateSolidBrush(0);
        }
        break;

    case WM_CLOSE:
        EndDialog(hwndDlg, EXIT_SUCCESS);
        break;

    default:
        return FALSE;
    }

    return TRUE;
}



//
// Plugins Helper
//
VOID WINAPI KdFreeBuffer(PVOID Buffer)
{
    if (Buffer)
	    delete Buffer;
}

VOID WINAPIV KdWriteLog(PWCHAR Format, ...)
{
    va_list Args;
	va_start(Args, Format);
    ULONG Length;
	WCHAR Buffer[512 + 2];

    _vsnwprintf(Buffer, COF(Buffer), Format, Args);
    wcscat(Buffer, L"\r\n");
    
    Length = wcslen(Buffer);
    PluginsLogSize += Length * sizeof(WCHAR);
    PluginsLogBuffer = (PWCHAR)realloc(PluginsLogBuffer, PluginsLogSize);
    wcscat(PluginsLogBuffer, Buffer);
}

VOID WINAPI KdWriteLogDirect(PWCHAR Buffer)
{
    ULONG Length;
    
    Length = wcslen(Buffer) + 2;
    PluginsLogSize += Length * sizeof(WCHAR);
    PluginsLogBuffer = (PWCHAR)realloc(PluginsLogBuffer, PluginsLogSize);
    wcscat(PluginsLogBuffer, Buffer);
    wcscat(PluginsLogBuffer, L"\r\n");
}

ULONG WINAPI KdShowMessage(PWCHAR Message, PWCHAR Title, ULONG uType)
{
	return MessageBoxW(gWin, Message, Title, uType);
}

VOID WINAPI KdShowConsole(VOID)
{
    SendMessage(gWin, WM_COMMAND, CONSOLE_PLUGIN, NULL);
}

PVOID WINAPI KdGetCurrentProcess(VOID)
{
    return KiKdProcess.ProcessObject;
}

PVOID WINAPI KdGetCsrProcess(VOID)
{
    return KiCsrProcess.ProcessObject;
}

PVOID WINAPI KdGetSystemProcess(VOID)
{
    return KiSystemProcess.ProcessObject;
}

PVOID WINAPI KdGetSystemIdleProcess(VOID)
{
    return KiIdleProcess.ProcessObject;
}

PVOID WINAPI KdGetSelectedProcess(VOID)
{
    return KiCurrentProcess.ProcessObject;
}

HWND WINAPI KdGetMainWindow(VOID)
{
	return gWin;
}



//
// Process Object
//
ULONG WINAPI KdEnumActiveProcesses(PVOID **ProcessObjectList)
{
    KI_PACKET KiPacket;
    PPROCESS_ENTRY Processes;
    ULONG Count = 0;

    if (KdIsValidPointer(ProcessObjectList))
    {
        Syscall(IOCTL_ENUM_PROCESS, &KiPacket);
        Processes = KiPacket.Parameters.ProcessEnumerate.Processes;
        Count = KiPacket.Parameters.ProcessEnumerate.Count;

        PVOID *Output = new PVOID [Count];
	    for (ULONG i = 0; i < Count; i++)
	    {
            Output[i] = Processes[i].ProcessObject;
	    }
        VirtualFree(Processes, 0, MEM_RELEASE);
	    *ProcessObjectList = Output;
    }
	return Count;
}

VOID WINAPI KdGetProcessInformation(PVOID ProcessObject, PROCESS_INFO *Buffer)
{
	PROCESS_ENTRY BufferEx;
	
    if (ProcessObject && KdIsValidPointer(Buffer, sizeof(PROCESS_INFO)))
    {
        GetProcessInformation(ProcessObject, &BufferEx);

	    Buffer->ImageBase = BufferEx.ImageBase;
	    Buffer->ParentId = BufferEx.ParentId;
	    wcsncpy_s(Buffer->Path, BufferEx.Name, STRING_LENGTH);
	    Buffer->Peb = (ULONG)BufferEx.Peb;
	    Buffer->ProcessId = BufferEx.Pid;
	    Buffer->ProcessObject = (ULONG)BufferEx.ProcessObject;
	    Buffer->VirtualSize = BufferEx.Cb;
    }
}

ULONG WINAPI KdEnumProcessModules(PVOID ProcessObject, DLL_ENTRY **Buffer)
{
	PDLL_ENTRY Dlls;
	ULONG Count = 0;
	
    if (ProcessObject && KdIsValidPointer(Buffer))
    {
        Count = EnumerateDlls(ProcessObject, &Dlls);
	    if (Count == 0)
	    {
		    *Buffer = NULL;
		    return 0;
	    }

	    *Buffer = Dlls;
    }
	return Count;
}

HANDLE WINAPI KdOpenProcessByPid(ULONG ProcessId)
{
    if (ProcessId)
        return GetProcessHandleById(ProcessId);
    else
        return NULL;
}

HANDLE WINAPI KdOpenProcessByPointer(PVOID ProcessObject)
{
    if (ProcessObject)
	    return GetProcessHandle(ProcessObject);
    else
        return NULL;
}

PVOID WINAPI KdGetProcessPointerByPid(ULONG ProcessId)
{
    KI_PACKET KiPacket;

    if (ProcessId)
    {
        KiPacket.Parameters.Common.Parameter1 = ProcessId;
	    Syscall(IOCTL_PROCESS_BY_PID, &KiPacket);
        return (PVOID)KiPacket.Parameters.Common.Parameter2;
    }
    else
    {
        return KiIdleProcess.ProcessObject;
    }
}

PVOID WINAPI KdGetProcessPointerByHandle(HANDLE hProcess)
{
	KI_PACKET KiPacket;

    if (hProcess)
    {
        KiPacket.Parameters.Common.Parameter1 = (ULONG_PTR)hProcess;
	    Syscall(IOCTL_PROCESS_BY_HANDLE, &KiPacket);
        return (PVOID)KiPacket.Parameters.Common.Parameter2;
    }
    else
    {
        return NULL;
    }
}

BOOL WINAPI KdKillProcess(PVOID ProcessObject)
{
    if (ProcessObject && ProcessKill(ProcessObject, FALSE))
    {
        Sleep(500);
        return TRUE;
    }
	return FALSE;
}

BOOL WINAPI KdForceKillProcess(PVOID ProcessObject)
{
    if (ProcessObject && ProcessKill(ProcessObject, TRUE))
    {
        Sleep(500);
        return TRUE;
    }
	return FALSE;
}

BOOL WINAPI KdSuspendProcess(PVOID ProcessObject)
{
    if (ProcessObject)
	    return ProcessSuspend(ProcessObject);
    else
        return FALSE;
}

BOOL WINAPI KdResumeProcess(PVOID ProcessObject)
{
    if (ProcessObject)
        return ProcessResume(ProcessObject, FALSE);
    else
        return FALSE;
}

BOOL WINAPI KdForceResumeProcess(PVOID ProcessObject)
{
    if (ProcessObject)
	    return ProcessResume(ProcessObject, TRUE);
    else
        return FALSE;
}



//
// Thread Object
//
ULONG WINAPI KdEnumActiveThreads(PVOID **ThreadObjectList)
{
	PTHREAD_ENTRY Threads;
	ULONG Count = 0;
	PVOID *Output;

    if (KdIsValidPointer(ThreadObjectList))
    {
        Count = EnumerateThreads(&Threads, NULL);
	    Output = new PVOID [Count];
	    for (ULONG Index = 0; Index < Count; Index++)
	    {
		    Output[Index] = Threads[Index].Thread;
	    }
	    delete Threads;
	    *ThreadObjectList = Output;
    }
	return Count;
}

ULONG WINAPI KdEnumProcessThreads(PVOID ProcessObject, PVOID **ThreadObjectList)
{
	PTHREAD_ENTRY Threads;
	ULONG Count = 0;
	PVOID *Output;

    if (ProcessObject && KdIsValidPointer(ThreadObjectList))
    {
        Count = EnumerateThreads(&Threads, ProcessObject);
	    Output = new PVOID [Count];
	    for (ULONG Index = 0; Index < Count; Index++)
	    {
		    Output[Index] = Threads[Index].Thread;
	    }
	    delete Threads;
	    *ThreadObjectList = Output;
    }
	return Count;
}

VOID WINAPI KdGetThreadInformation(PVOID ThreadObject, THREAD_INFO_EX *Buffer)
{
    PROCESS_ENTRY Process;
	THREAD_ENTRY Thread;
	
    if (ThreadObject && KdIsValidPointer(Buffer, sizeof(THREAD_INFO_EX)))
    {
        GetThreadProcessInformation(ThreadObject, &Process, &Thread);
	    Buffer->ProcessId = (ULONG)Thread.ParentId;
	    Buffer->ProcessObject = (ULONG)Thread.Process;
	    Buffer->ServiceTable = (ULONG)Thread.ServiceTable;
	    Buffer->StartAddress = (ULONG)Thread.Address;
	    Buffer->Teb = (ULONG)Thread.Teb;
	    Buffer->ThreadId = (ULONG)Thread.Cid;
	    Buffer->ThreadObject = (ULONG)Thread.Thread;
    }
}

VOID WINAPI KdGetThreadParentProcess(PVOID ThreadObject, PROCESS_INFO *ProcessInformation)
{
	PROCESS_ENTRY Process;
	THREAD_ENTRY Thread;
	
    if (ThreadObject && KdIsValidPointer(ProcessInformation, sizeof(PROCESS_INFO)))
    {
        GetThreadProcessInformation(ThreadObject, &Process, &Thread);
	    ProcessInformation->ImageBase = Process.ImageBase;
	    ProcessInformation->ParentId = Process.ParentId;
	    wcsncpy_s(ProcessInformation->Path, Process.Name, STRING_LENGTH);
	    ProcessInformation->Peb = (ULONG)Process.Peb;
	    ProcessInformation->ProcessId = Process.Pid;
	    ProcessInformation->ProcessObject = (ULONG)Process.ProcessObject;
	    ProcessInformation->VirtualSize = Process.Cb;
    }
}

HANDLE WINAPI KdOpenThreadByTid(ULONG ThreadId)
{
    if (ThreadId)
        return GetThreadHandleById(ThreadId);
    else
        return NULL;
}

HANDLE WINAPI KdOpenThreadByPointer(PVOID ThreadObject)
{
    if (ThreadObject)
	    return GetThreadHandle(ThreadObject);
    else
        return NULL;
}

PVOID WINAPI KdGetThreadPointerByTid(ULONG ThreadId)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.Common.Parameter1 = ThreadId;
	Syscall(IOCTL_THREAD_BY_PID, &KiPacket);
    return (PVOID)KiPacket.Parameters.Common.Parameter2;
}

PVOID WINAPI KdGetThreadPointerByHandle(HANDLE hThread)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.Common.Parameter1 = (ULONG_PTR)hThread;
	Syscall(IOCTL_THREAD_BY_HANDLE, &KiPacket);
    return (PVOID)KiPacket.Parameters.Common.Parameter2;
}

BOOL WINAPI KdForceKillThread(PVOID ThreadObject)
{
	if (ThreadObject && ThreadKill(ThreadObject))
	{
		Sleep(500);
		return TRUE;
	}
	return FALSE;
}

BOOL WINAPI KdSuspendThread(PVOID ThreadObject)
{
    if (ThreadObject)
	    return ThreadSuspend(ThreadObject);
    else
        return FALSE;
}

BOOL WINAPI KdResumeThread(PVOID ThreadObject)
{
    if (ThreadObject)
	    return ThreadResume(ThreadObject, FALSE);
    else
        return FALSE;
}

BOOL WINAPI KdForceResumeThread(PVOID ThreadObject)
{
    if (ThreadObject)
	    return ThreadResume(ThreadObject, TRUE);
    else
        return FALSE;
}

BOOL WINAPI KdGetContextThread(PVOID ThreadObject, CONTEXT *Context)
{
    KI_PACKET KiPacket;

    if (ThreadObject && KdIsValidPointer(Context, sizeof(CONTEXT)))
    {
        KiPacket.Parameters.ThreadContext.ThreadObject = ThreadObject;
        KiPacket.Parameters.ThreadContext.Context = Context;
        KiPacket.Parameters.ThreadContext.Set = FALSE;
        return Syscall(IOCTL_THREAD_CONTEXT, &KiPacket);
    }
    return FALSE;
}

BOOL WINAPI KdSetContextThread(PVOID ThreadObject, CONTEXT *Context)
{
	KI_PACKET KiPacket;

    if (ThreadObject && KdIsValidPointer(Context, sizeof(CONTEXT)))
    {
        KiPacket.Parameters.ThreadContext.ThreadObject = ThreadObject;
        KiPacket.Parameters.ThreadContext.Context = Context;
        KiPacket.Parameters.ThreadContext.Set = TRUE;
        return Syscall(IOCTL_THREAD_CONTEXT, &KiPacket);
    }
    return FALSE;
}


//
// Memory Management
//
BOOL WINAPI KdReadVirtualMemory(PVOID ProcessObject, PVOID VirtualAddress, PVOID Buffer, ULONG Size, PULONG BytesRead)
{
    KI_PACKET KiPacket;

    if (ProcessObject && !IsBadWritePtr(Buffer, Size))
    {
        KiPacket.Parameters.VirtualRead.ProcessObject = ProcessObject;
        KiPacket.Parameters.VirtualRead.VirtualAddress = VirtualAddress;
        KiPacket.Parameters.VirtualRead.Buffer = Buffer;
        KiPacket.Parameters.VirtualRead.Size = Size;
        KiPacket.Parameters.VirtualRead.NumberOfBytesRead = BytesRead;
	    RtlZeroMemory(Buffer, Size);
	    return Syscall(IOCTL_VM_READ, &KiPacket);
    }
    return FALSE;
}

BOOL WINAPI KdWriteVirtualMemory(PVOID ProcessObject, PVOID VirtualAddress, PVOID Buffer, ULONG Size, PULONG BytesWritten)
{
	KI_PACKET KiPacket;

    if (ProcessObject && !IsBadReadPtr(Buffer, Size))
    {
        KiPacket.Parameters.VirtualWrite.ProcessObject = ProcessObject;
        KiPacket.Parameters.VirtualWrite.VirtualAddress = VirtualAddress;
        KiPacket.Parameters.VirtualWrite.Buffer = Buffer;
        KiPacket.Parameters.VirtualWrite.Size = Size;
        KiPacket.Parameters.VirtualWrite.NumberOfBytesWritten = BytesWritten;
	    return Syscall(IOCTL_VM_WRITE, &KiPacket);
    }
    return FALSE;
}

BOOL WINAPI KdQueryVirtualMemory(PVOID ProcessObject, PVOID VirtualAddress, PMEMORY_BASIC_INFORMATION Buffer, ULONG dwLength)
{
    if (ProcessObject && KdIsValidPointer(Buffer, dwLength))
	    return QueryVirtualMemory(ProcessObject, VirtualAddress, dwLength, Buffer);
    else
        return FALSE;
}

BOOL WINAPI KdProtectVirtualMemory(PVOID ProcessObject, PVOID VirtualAddress, ULONG dwSize, ULONG NewProtection, PULONG OldProtection)
{
    if (ProcessObject)
        return ProtectVirtualMemory(ProcessObject, VirtualAddress, dwSize, NewProtection, OldProtection);
    else
        return FALSE;
}

PVOID WINAPI KdAllocateVirtualMemory(PVOID ProcessObject, ULONG Size)
{
    if (ProcessObject)
        return AllocateVirtualMemory(ProcessObject, Size);
    else
        return NULL;
}

VOID WINAPI KdFreeVirtualMemory(PVOID ProcessObject, PVOID VirtualAddress)
{
    if (ProcessObject)
        FreeVirtualMemory(ProcessObject, VirtualAddress, 0);
}

BOOL WINAPI KdReadPhysicalMemory(PLARGE_INTEGER PhysicalAddress, PVOID Buffer, SIZE_T Size)
{
    if (KdIsValidPointer(Buffer, Size))
        return ReadPhysicalPages(PhysicalAddress, Buffer, Size);
    else
        return FALSE;
}

BOOL WINAPI KdWritePhysicalMemory(PLARGE_INTEGER PhysicalAddress, PVOID Buffer, SIZE_T Size)
{
    if (KdIsValidPointer(Buffer, Size))
	    return WritePhysicalPages(PhysicalAddress, Buffer, Size);
    else
        return FALSE;
}

PVOID WINAPI KdAllocateNonpagedPool(ULONG Size)
{
	KI_PACKET KiPacket;

    if (Size)
    {
        KiPacket.Parameters.Common.Parameter1 = Size;
	    Syscall(IOCTL_ALLOC_NONPAGED_POOL, &KiPacket);
        return (PVOID)KiPacket.Parameters.Common.Parameter2;
    }
    else
    {
        return NULL;
    }
}

VOID WINAPI KdFreeNonpagedPool(PVOID NonpagedPoolAddress)
{
    KI_PACKET KiPacket;

    if (NonpagedPoolAddress)
    {
        KiPacket.Parameters.Common.Parameter1 = (ULONG_PTR)NonpagedPoolAddress;
	    Syscall(IOCTL_FREE_NONPAGED_POOL, &KiPacket);
    }
}

BOOL WINAPI KdUnmapViewOfSection(PVOID ProcessObject, PVOID SectionBase)
{
    if (ProcessObject)
	    return UnmapSection(ProcessObject, SectionBase);
    else
        return FALSE;
}

ULONG WINAPI KdGetLowestPhysicalPage(VOID)
{
	KI_PACKET KiPacket;

	Syscall(IOCTL_GET_MEMORY_INFO, &KiPacket);
    return KiPacket.Parameters.SystemInformation.LowestPhysicalPage;
}

ULONG WINAPI KdGetHighestPhysicalPage(VOID)
{
	KI_PACKET KiPacket;

	Syscall(IOCTL_GET_MEMORY_INFO, &KiPacket);
	return KiPacket.Parameters.SystemInformation.HighestPhysicalPage;
}

ULONG WINAPI KdGetNumberOfPhysicalPages(VOID)
{
	KI_PACKET KiPacket;

	Syscall(IOCTL_GET_MEMORY_INFO, &KiPacket);
	return KiPacket.Parameters.SystemInformation.NumberOfPhysicalPages;
}

PVOID WINAPI KdGetHighestUserAddress(VOID)
{
	KI_PACKET KiPacket;

	Syscall(IOCTL_GET_MEMORY_INFO, &KiPacket);
	return (PVOID)KiPacket.Parameters.SystemInformation.HighestUserAddress;
}

PVOID WINAPI KdGetSystemRangeStart(VOID)
{
	KI_PACKET KiPacket;

	Syscall(IOCTL_GET_MEMORY_INFO, &KiPacket);
	return (PVOID)KiPacket.Parameters.SystemInformation.SystemRangeStart;
}

PVOID WINAPI KdGetUserProbeAddress(VOID)
{
	KI_PACKET KiPacket;

	Syscall(IOCTL_GET_MEMORY_INFO, &KiPacket);
	return (PVOID)KiPacket.Parameters.SystemInformation.UserProbeAddress;
}


//
// File System
//
HANDLE WINAPI KdOpenFile(PWCHAR FilePath)
{
    KI_PACKET KiPacket;
	HANDLE Handle = INVALID_HANDLE_VALUE;

    if (FilePath)
    {
        KiPacket.Parameters.Common.Parameter1 = (ULONG_PTR)FilePath;
	    if (Syscall(IOCTL_OPEN_FILE, &KiPacket))
            Handle = (HANDLE)KiPacket.Parameters.Common.Parameter2;
    }
	return Handle;
}

BOOL WINAPI KdReadFileByHandle(HANDLE hFile, PVOID Buffer, ULONG Size, PLARGE_INTEGER Offset)
{
    KI_PACKET KiPacket;

    if (hFile && KdIsValidPointer(Buffer, Size))
    {
        KiPacket.Parameters.Common.Parameter1 = (ULONG_PTR)hFile;
        KiPacket.Parameters.Common.Parameter2 = (ULONG_PTR)Buffer;
        KiPacket.Parameters.Common.Parameter3 = (ULONG_PTR)Size;
        KiPacket.Parameters.Common.Parameter4 = (ULONG_PTR)Offset;
	    return Syscall(IOCTL_READ_FILE_BY_HANDLE, &KiPacket);
    }
    return FALSE;
}

BOOL WINAPI KdReadFileByName(PWCHAR FilePath, PVOID Buffer, ULONG Size, PLARGE_INTEGER Offset)
{
	KI_PACKET KiPacket;

    if (FilePath && KdIsValidPointer(Buffer, Size))
    {
        KiPacket.Parameters.Common.Parameter1 = (ULONG_PTR)FilePath;
        KiPacket.Parameters.Common.Parameter2 = (ULONG_PTR)Buffer;
        KiPacket.Parameters.Common.Parameter3 = (ULONG_PTR)Size;
        KiPacket.Parameters.Common.Parameter4 = (ULONG_PTR)Offset;
	    return Syscall(IOCTL_READ_FILE_BY_NAME, &KiPacket);
    }
    return FALSE;
}

BOOL WINAPI KdWriteFileByHandle(HANDLE hFile, PVOID Buffer, ULONG Size, PLARGE_INTEGER Offset)
{
	KI_PACKET KiPacket;

    if (hFile && KdIsValidPointer(Buffer, Size))
    {
        KiPacket.Parameters.Common.Parameter1 = (ULONG_PTR)hFile;
        KiPacket.Parameters.Common.Parameter2 = (ULONG_PTR)Buffer;
        KiPacket.Parameters.Common.Parameter3 = (ULONG_PTR)Size;
        KiPacket.Parameters.Common.Parameter4 = (ULONG_PTR)Offset;
	    return Syscall(IOCTL_WRITE_FILE_BY_HANDLE, &KiPacket);
    }
    return FALSE;
}

BOOL WINAPI KdWriteFileByName(PWCHAR FilePath, PVOID Buffer, ULONG Size, PLARGE_INTEGER Offset)
{
	KI_PACKET KiPacket;

    if (FilePath && KdIsValidPointer(Buffer, Size))
    {
        KiPacket.Parameters.Common.Parameter1 = (ULONG_PTR)FilePath;
        KiPacket.Parameters.Common.Parameter2 = (ULONG_PTR)Buffer;
        KiPacket.Parameters.Common.Parameter3 = (ULONG_PTR)Size;
        KiPacket.Parameters.Common.Parameter4 = (ULONG_PTR)Offset;
	    return Syscall(IOCTL_WRITE_FILE_BY_NAME, &KiPacket);
    }
    return FALSE;
}

BOOL WINAPI KdReadSectors(ULONG DiskNumber, ULONG SectorNumber, USHORT SectorCount , PVOID Buffer)
{
	KI_PACKET KiPacket;

    if (KdIsValidPointer(Buffer, SectorCount * 512))
    {
        KiPacket.Parameters.DiskReadWrite.Disk = DiskNumber;
        KiPacket.Parameters.DiskReadWrite.SectorNumber = SectorNumber;
        KiPacket.Parameters.DiskReadWrite.SectorCount = SectorCount;
        KiPacket.Parameters.DiskReadWrite.Buffer = Buffer;
        KiPacket.Parameters.DiskReadWrite.IsWrite = FALSE;
        return Syscall(IOCTL_DISK_READWRITE, &KiPacket);
    }
    return FALSE;
}

BOOL WINAPI KdWriteSectors(ULONG DiskNumber, ULONG SectorNumber, USHORT SectorCount , PVOID Buffer)
{
	KI_PACKET KiPacket;

    if (KdIsValidPointer(Buffer, SectorCount * 512))
    {
        KiPacket.Parameters.DiskReadWrite.Disk = DiskNumber;
        KiPacket.Parameters.DiskReadWrite.SectorNumber = SectorNumber;
        KiPacket.Parameters.DiskReadWrite.SectorCount = SectorCount;
        KiPacket.Parameters.DiskReadWrite.Buffer = Buffer;
        KiPacket.Parameters.DiskReadWrite.IsWrite = TRUE;
        return Syscall(IOCTL_DISK_READWRITE, &KiPacket);
    }
    return FALSE;
}

BOOL WINAPI KdGetFileNameByHandle(HANDLE hFile, PWCHAR FileName, ULONG Size)
{
	KI_PACKET KiPacket;

    if (hFile && KdIsValidPointer(FileName, Size * sizeof(WCHAR)))
    {
        KiPacket.Parameters.Common.Parameter1 = (ULONG_PTR)hFile;
        KiPacket.Parameters.Common.Parameter2 = (ULONG_PTR)FileName;
        KiPacket.Parameters.Common.Parameter3 = (ULONG_PTR)Size;
	    return Syscall(IOCTL_GET_FILENAME_BY_HANDLE, &KiPacket);
    }
    return FALSE;
}

BOOL WINAPI KdGetFileNameByPointer(PVOID FileObject, PWCHAR FileName, ULONG Size)
{
	KI_PACKET KiPacket;

    if (FileObject && KdIsValidPointer(FileName, Size * sizeof(WCHAR)))
    {
        KiPacket.Parameters.Common.Parameter1 = (ULONG_PTR)FileObject;
        KiPacket.Parameters.Common.Parameter2 = (ULONG_PTR)FileName;
        KiPacket.Parameters.Common.Parameter3 = (ULONG_PTR)Size;
	    return Syscall(IOCTL_GET_FILENAME_BY_OBJECT, &KiPacket);
    }
    return FALSE;
}

BOOL WINAPI KdCopyFile(PWCHAR SourceFilePath, PWCHAR DestinationFilePath)
{
    if (SourceFilePath && DestinationFilePath)
        return FileCopy(SourceFilePath, DestinationFilePath);
    else
        return FALSE;
}

BOOL WINAPI KdDeleteFile(PWCHAR FilePath)
{
    if (FilePath)
	    return FileDelete(FilePath, FALSE);
    else
        return FALSE;
}

BOOL WINAPI KdForceDeleteFile(PWCHAR FilePath)
{
    if (FilePath)
	    return FileDelete(FilePath, TRUE);
    else
        return FALSE;
}

BOOL WINAPI KdCheckFileSignature(PWCHAR FilePath)
{
    if (FilePath)
	    return IsFileDigitallySigned(FilePath);
    else
        return FALSE;
}


//
// Driver/Device Object
//
ULONG WINAPI KdEnumKernelModules(DRIVER_INFO **KernelModuleList)
{
	PDRIVER_ENTRY Drivers;
	DRIVER_INFO *Buffer;
	ULONG Count = 0;

    if (KdIsValidPointer(KernelModuleList))
    {
        Count = EnumerateDrivers(&Drivers);
	    Buffer = new DRIVER_INFO[Count];
	    for (ULONG Index = 0; Index < Count; Index++)
	    {
		    Buffer[Index].EntryPoint = Drivers[Index].EntryPoint;
		    Buffer[Index].ImageBase = Drivers[Index].ImageBase;
		    Buffer[Index].ImageSize = Drivers[Index].ImageSize;
		    wcsncpy_s(Buffer[Index].ImagePath, Drivers[Index].ImagePath, STRING_LENGTH);;
	    }
	    delete Drivers;
	    *KernelModuleList = Buffer;
    }

	return Count;
}

ULONG WINAPI KdEnumDrivers(PVOID **DriverObjectList)
{
	PDRIVER_ENTRY Drivers;
	PVOID *Buffer;
	ULONG Count = 0, nObjects = 0;

    if (KdIsValidPointer(DriverObjectList))
    {
	    Count = EnumerateDrivers(&Drivers);

	    for (ULONG Index = 0; Index < Count; Index++)
	    {
		    if (Drivers[Index].DriverObject)
			    nObjects ++;
	    }
	    Buffer = new PVOID[nObjects];

	    nObjects = 0;
	    for (ULONG Index = 0; Index < Count; Index++)
	    {
		    if (Drivers[Index].DriverObject)
		    {
			    Buffer[nObjects] = Drivers[Index].DriverObject;
			    nObjects ++;
		    }
	    }
	    delete Drivers;
	    *DriverObjectList = Buffer;
    }

	return nObjects;
}

ULONG WINAPI KdEnumDevices(PVOID **DeviceObjectList)
{
	LONG Count = 0;

    if (KdIsValidPointer(DeviceObjectList))
	    Count = EnumerateDevices(DeviceObjectList);
	return Count;
}

BOOL WINAPI KdGetDriverName(PVOID DriverObject, PWCHAR DriverName, ULONG nCount)
{
	DRIVER_ENTRY *Driver = GettDriverInformation(DriverObject);
	if (Driver && KdIsValidPointer(DriverName, nCount * sizeof(WCHAR)))
	{
		wcsncpy_s(DriverName, nCount, Driver->ImagePath, _TRUNCATE);
		delete Driver;
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

BOOL WINAPI KdGetDeviceName(PVOID DeviceObject, PWCHAR DeviceName, ULONG nCount)
{
    if (DeviceObject && KdIsValidPointer(DeviceName, nCount * sizeof(WCHAR)))
    {
        PWCHAR Buffer = GetObjectName(DeviceObject);
	    if (Buffer)
	    {
		    wcsncpy_s(DeviceName, nCount, Buffer, _TRUNCATE);
		    delete Buffer;
		    return TRUE;
	    }
	    else
	    {
		    return FALSE;
	    }
    }
    else
    {
        return FALSE;
    }
}

ULONG WINAPI KdEnumUnloadedDrivers(DRIVER_INFO **DriversList)
{
    KI_PACKET KiPacket;
	DRIVER_INFO *Buffer;
    ULONG Count = 0;
    PDRIVER_ENTRY UnloadedDrivers;

    if (KdIsValidPointer(DriversList))
    {
	    Syscall(IOCTL_ENUM_UNLOADED_DRIVERS, &KiPacket);
        Count = KiPacket.Parameters.Common.Parameter1;
        UnloadedDrivers = (PDRIVER_ENTRY)KiPacket.Parameters.Common.Parameter2;

        Buffer = new DRIVER_INFO[Count];
	    for (ULONG Index = 0; Index < Count; Index++)
	    {
		    Buffer[Index].ImageBase = UnloadedDrivers[Index].ImageBase;
		    Buffer[Index].ImageSize = UnloadedDrivers[Index].ImageSize;
		    Buffer[Index].EntryPoint = NULL;
		    wcsncpy_s(Buffer[Index].ImagePath, UnloadedDrivers[Index].ImagePath, MAX_PATH);
	    }
	    VirtualFree(UnloadedDrivers, 0, MEM_RELEASE);
	    *DriversList = Buffer;
    }

	return Count;
}


//
// Handle Object
//
ULONG WINAPI KdEnumHandles(PVOID ProcessObject, HANDLE_ENTRY **HandlesList)
{
    if (ProcessObject && KdIsValidPointer(HandlesList))
	    return EnumerateHandles(HandlesList, ProcessObject);
    else
        return 0;
}

ULONG WINAPI KdEnumObjectTypes(OBJECT_TYPE_ENTRY **ObjectTypesList)
{
    if (KdIsValidPointer(ObjectTypesList))
        return EnumerateObjectTypes(ObjectTypesList);
    else
        return 0;
}

BOOL WINAPI KdGetObjectName(PVOID Object, PWCHAR ObjectName, ULONG nCount)
{
    if (Object && KdIsValidPointer(ObjectName, nCount * sizeof(WCHAR)))
    {
	    PWCHAR Buffer = GetObjectName(Object);
	    if (Buffer)
	    {
		    wcsncpy_s(ObjectName, nCount, Buffer, _TRUNCATE);
		    delete Buffer;
		    return TRUE;
	    }
	    else
	    {
		    return FALSE;
	    }
    }
    else
    {
        return FALSE;
    }
}

BOOL WINAPI KdGetObjectTypeName(PVOID Object, PWCHAR ObjectTypeName, ULONG nCount)
{
    if (Object && KdIsValidPointer(ObjectTypeName, nCount * sizeof(WCHAR)))
    {
	    PWCHAR Buffer = GetObjectTypeName(Object);
        if (Buffer)
	    {
		    wcsncpy_s(ObjectTypeName, nCount, Buffer, _TRUNCATE);
		    delete Buffer;
		    return TRUE;
	    }
	    else
	    {
		    return FALSE;
	    }
    }
    else
    {
        return FALSE;
    }
}

PVOID WINAPI KdGetObjectPointerByHandle(HANDLE Handle)
{
    KI_PACKET KiPacket;

    if (Handle)
    {
        KiPacket.Parameters.Common.Parameter1 = (ULONG_PTR)Handle;
        Syscall(IOCTL_GET_OBJECT_BY_HANDLE, &KiPacket);
        return (PVOID)KiPacket.Parameters.Common.Parameter2;
    }
    return FALSE;
}

BOOL WINAPI KdCloseRemoteHandle(PVOID ProcessObject, HANDLE Handle)
{
    if (ProcessObject && Handle)
        return CloseProcessHandle(ProcessObject, Handle);
    else
        return FALSE;
}


//
// System Control
//
PKIDT_ENTRY WINAPI KdEnumInterrupts(UCHAR ProcessorNumber)
{
    PKIDT_ENTRY Interrupts;
    EnumerateInterrupts(ProcessorNumber, &Interrupts);
	return Interrupts;
}

ULONG_PTR WINAPI KdHookInterruptOffset(ULONG Index, ULONG_PTR Offset, UCHAR Processor)
{
	return HookInterruptOffset(Processor, Index, Offset);
}

USHORT WINAPI KdHookInterruptSelector(ULONG Index, USHORT Selector, UCHAR Processor)
{
	return HookInterruptSelector(Processor, Index, Selector);
}

ULONG WINAPI KdEnumServiceTable(SERVICE_ENTRY_INFO **Servicetable)
{
	ULONG Count = 0;
    SDT_ENTRY *PtrSdt;
	SERVICE_ENTRY_INFO *Buffer;

    if (KdIsValidPointer(Servicetable))
    {
        Count = EnumerateSsdt(&PtrSdt);
	    Buffer = new SERVICE_ENTRY_INFO[Count];
	    for (ULONG Index = 0; Index < Count; Index++)
	    {
		    Buffer[Index].Current = PtrSdt[Index].Current;
		    Buffer[Index].Original = PtrSdt[Index].Original;
		    Buffer[Index].Index = PtrSdt[Index].Index;
	    }
	    delete[] PtrSdt;
	    *Servicetable = Buffer;
    }

	return Count;
}

VOID WINAPI KdRestoreServiceTable(VOID)
{
	Syscall(IOCTL_RESTORE_SSDT, NULL);
}

VOID WINAPI KdHookServiceTable(ULONG Index, PVOID ServiceRoutine)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.Common.Parameter1 = Index;
    KiPacket.Parameters.Common.Parameter2 = (ULONG_PTR)ServiceRoutine;
	Syscall(IOCTL_SET_SSDT, &KiPacket);
}

ULONG WINAPI KdEnumShadowServiceTable(SERVICE_ENTRY_INFO **ShadowServicetable)
{
	ULONG Count = 0;
	SDT_ENTRY *PtrSdt;
	SERVICE_ENTRY_INFO *Buffer;

    if (KdIsValidPointer(ShadowServicetable))
    {
        Count = EnumerateShadowSsdt(&PtrSdt);
	    Buffer = new SERVICE_ENTRY_INFO[Count];
	    for (ULONG Index = 0; Index < Count; Index++)
	    {
		    Buffer[Index].Current = PtrSdt[Index].Current;
		    Buffer[Index].Original = PtrSdt[Index].Original;
		    Buffer[Index].Index = PtrSdt[Index].Index;
	    }
	    delete[] PtrSdt;
	    *ShadowServicetable = Buffer;
    }

	return Count;
}

VOID WINAPI KdRestoreShadowServiceTable(VOID)
{
	Syscall(IOCTL_RESTORE_SHADOW_SSDT, NULL);
}

VOID WINAPI KdHookShadowServiceTable(ULONG Index, PVOID ServiceRoutine)
{
	KI_PACKET KiPacket;

    KiPacket.Parameters.Common.Parameter1 = Index;
    KiPacket.Parameters.Common.Parameter2 = (ULONG_PTR)ServiceRoutine;
	Syscall(IOCTL_SET_SHADOW_SSDT, &KiPacket);
}

ULONG WINAPI KdEnumActiveTimers(TIMER_ENTRY **TimersList)
{
    KI_PACKET KiPacket;
	TIMER_ENTRY *Buffer, *PtrTimers;
    ULONG Count = 0;

    if (KdIsValidPointer(TimersList))
    {
	    if (Syscall(IOCTL_ENUM_TIMERS, &KiPacket))
	    {
            PtrTimers = (PTIMER_ENTRY)KiPacket.Parameters.Common.Parameter1;
            Count = KiPacket.Parameters.Common.Parameter2;
		    Buffer = new TIMER_ENTRY[Count];
		    RtlCopyMemory(Buffer, PtrTimers, sizeof(TIMER_ENTRY) * Count);
		    *TimersList = Buffer;
		    VirtualFree(PtrTimers, 0, MEM_RELEASE);
	    }
	    else
	    {
		    *TimersList = NULL;
            Count = 0;
	    }
    }

    return Count;
}

BOOL WINAPI KdCancelTimer(PVOID TimerObject)
{
    KI_PACKET KiPacket;

    if (TimerObject)
    {
        KiPacket.Parameters.Common.Parameter1 = (ULONG_PTR)TimerObject;
	    return Syscall(IOCTL_CANCEL_TIMER, &KiPacket);
    }
    return FALSE;
}

ULONG WINAPI KdGetCr0(VOID)
{
    KI_PACKET KiPacket;
	
    KiPacket.Parameters.Common.Parameter1 = 0;
	Syscall(IOCTL_GET_CONTROL_REG, &KiPacket);
    return KiPacket.Parameters.Common.Parameter2;
}

ULONG WINAPI KdGetCr4(VOID)
{
    KI_PACKET KiPacket;
	
    KiPacket.Parameters.Common.Parameter1 = 4;
	Syscall(IOCTL_GET_CONTROL_REG, &KiPacket);
    return KiPacket.Parameters.Common.Parameter2;
}

VOID WINAPI KdReadMsr(ULONG Register, PULONGLONG Value)
{
    KI_PACKET KiPacket;
	
    KiPacket.Parameters.Msr.Register = Register;
    KiPacket.Parameters.Msr.Write = FALSE;
	Syscall(IOCTL_MSR, &KiPacket);
    *Value = KiPacket.Parameters.Msr.Value;
}

VOID WINAPI KdWriteMsr(ULONG Register, PULONGLONG Value)
{
    KI_PACKET KiPacket;
	
    KiPacket.Parameters.Msr.Register = Register;
    KiPacket.Parameters.Msr.Value = *Value;
    KiPacket.Parameters.Msr.Write = TRUE;
	Syscall(IOCTL_MSR, &KiPacket);
}

PVOID WINAPI KdGetKernelBase(VOID)
{
    KI_PACKET KiPacket;

	Syscall(IOCTL_GET_KERNEL_INFO, &KiPacket);
    return KiPacket.Parameters.KernelInformation.KernelBase;
}

ULONG WINAPI KdGetKernelSize(VOID)
{
	KI_PACKET KiPacket;

	Syscall(IOCTL_GET_KERNEL_INFO, &KiPacket);
	return KiPacket.Parameters.KernelInformation.KernelSize;
}

PVOID WINAPI KdGetPsLoadedModuleList(VOID)
{
	KI_PACKET KiPacket;

	Syscall(IOCTL_GET_KERNEL_INFO, &KiPacket);
	return KiPacket.Parameters.KernelInformation.PsLoadedModuleList;
}

PVOID WINAPI KdGetMmLoadedUserImageList(VOID)
{
	KI_PACKET KiPacket;

	Syscall(IOCTL_GET_KERNEL_INFO, &KiPacket);
	return KiPacket.Parameters.KernelInformation.MmLoadedUserImageList;
}

PVOID WINAPI KdGetPspCidTable(VOID)
{
	KI_PACKET KiPacket;

	Syscall(IOCTL_GET_KERNEL_INFO, &KiPacket);
	return KiPacket.Parameters.KernelInformation.PspCidTable;
}

BOOL WINAPI KdCallBiosInterrupt(UCHAR Interrupt, PBIOS_REGISTERS Context)
{
    KI_PACKET KiPacket;

    if (KdIsValidPointer(Context, sizeof(BIOS_REGISTERS)))
    {
        KiPacket.Parameters.BiosCall.BiosCommand = Interrupt;
        KiPacket.Parameters.BiosCall.BiosArguments = Context;
        return Syscall(IOCTL_CALL_BIOS, &KiPacket);
    }
    return FALSE;
}

UCHAR WINAPI KdReadPortChar(USHORT Port)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.Common.Parameter1 = 0;
    KiPacket.Parameters.Common.Parameter2 = Port;
    Syscall(IOCTL_PORT_READ, &KiPacket);
    return (KiPacket.Parameters.Common.Parameter3 & 0xFF);
}

USHORT WINAPI KdReadPortShort(USHORT Port)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.Common.Parameter1 = 1;
    KiPacket.Parameters.Common.Parameter2 = Port;
    Syscall(IOCTL_PORT_READ, &KiPacket);
    return (KiPacket.Parameters.Common.Parameter3 & 0xFFFF);
}

ULONG WINAPI KdReadPortLong(USHORT Port)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.Common.Parameter1 = 2;
    KiPacket.Parameters.Common.Parameter2 = Port;
    Syscall(IOCTL_PORT_READ, &KiPacket);
    return (KiPacket.Parameters.Common.Parameter3);
}

VOID WINAPI KdReadPortBufferChar(USHORT Port, PUCHAR Buffer, ULONG Count)
{
    KI_PACKET KiPacket;

    if (KdIsValidPointer(Buffer, Count))
    {
        KiPacket.Parameters.Common.Parameter1 = 3;
        KiPacket.Parameters.Common.Parameter2 = Port;
        KiPacket.Parameters.Common.Parameter3 = (ULONG_PTR)Buffer;
        KiPacket.Parameters.Common.Parameter4 = Count;
        Syscall(IOCTL_PORT_READ, &KiPacket);
    }
}

VOID WINAPI KdReadPortBufferShort(USHORT Port, PUSHORT Buffer, ULONG Count)
{
    KI_PACKET KiPacket;

    if (KdIsValidPointer(Buffer, Count * sizeof(USHORT)))
    {
        KiPacket.Parameters.Common.Parameter1 = 4;
        KiPacket.Parameters.Common.Parameter2 = Port;
        KiPacket.Parameters.Common.Parameter3 = (ULONG_PTR)Buffer;
        KiPacket.Parameters.Common.Parameter4 = Count;
        Syscall(IOCTL_PORT_READ, &KiPacket);
    }
}

VOID WINAPI KdReadPortBufferLong(USHORT Port, PULONG Buffer, ULONG Count)
{
    KI_PACKET KiPacket;

    if (KdIsValidPointer(Buffer, Count * sizeof(ULONG)))
    {
        KiPacket.Parameters.Common.Parameter1 = 5;
        KiPacket.Parameters.Common.Parameter2 = Port;
        KiPacket.Parameters.Common.Parameter3 = (ULONG_PTR)Buffer;
        KiPacket.Parameters.Common.Parameter4 = Count;
        Syscall(IOCTL_PORT_READ, &KiPacket);
    }
}

VOID WINAPI KdWritePortChar(USHORT Port, UCHAR Value)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.Common.Parameter1 = 0;
    KiPacket.Parameters.Common.Parameter2 = Port;
    KiPacket.Parameters.Common.Parameter3 = Value;
    Syscall(IOCTL_PORT_WRITE, &KiPacket);
}

VOID WINAPI KdWritePortShort(USHORT Port, USHORT Value)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.Common.Parameter1 = 1;
    KiPacket.Parameters.Common.Parameter2 = Port;
    KiPacket.Parameters.Common.Parameter3 = Value;
    Syscall(IOCTL_PORT_WRITE, &KiPacket);
}

VOID WINAPI KdWritePortLong(USHORT Port, ULONG Value)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.Common.Parameter1 = 2;
    KiPacket.Parameters.Common.Parameter2 = Port;
    KiPacket.Parameters.Common.Parameter3 = Value;
    Syscall(IOCTL_PORT_WRITE, &KiPacket);
}

VOID WINAPI KdWritePortBufferChar(USHORT Port, PUCHAR Buffer, ULONG Count)
{
    KI_PACKET KiPacket;

    if (KdIsValidPointer(Buffer, Count))
    {
        KiPacket.Parameters.Common.Parameter1 = 3;
        KiPacket.Parameters.Common.Parameter2 = Port;
        KiPacket.Parameters.Common.Parameter3 = (ULONG_PTR)Buffer;
        KiPacket.Parameters.Common.Parameter4 = Count;
        Syscall(IOCTL_PORT_WRITE, &KiPacket);
    }
}

VOID WINAPI KdWritePortBufferShort(USHORT Port, PUSHORT Buffer, ULONG Count)
{
    KI_PACKET KiPacket;

    if (KdIsValidPointer(Buffer, Count * sizeof(USHORT)))
    {
        KiPacket.Parameters.Common.Parameter1 = 4;
        KiPacket.Parameters.Common.Parameter2 = Port;
        KiPacket.Parameters.Common.Parameter3 = (ULONG_PTR)Buffer;
        KiPacket.Parameters.Common.Parameter4 = Count;
        Syscall(IOCTL_PORT_WRITE, &KiPacket);
    }
}

VOID WINAPI KdWritePortBufferLong(USHORT Port, PULONG Buffer, ULONG Count)
{
    KI_PACKET KiPacket;

    if (KdIsValidPointer(Buffer, Count * sizeof(ULONG)))
    {
        KiPacket.Parameters.Common.Parameter1 = 5;
        KiPacket.Parameters.Common.Parameter2 = Port;
        KiPacket.Parameters.Common.Parameter3 = (ULONG_PTR)Buffer;
        KiPacket.Parameters.Common.Parameter4 = Count;
        Syscall(IOCTL_PORT_WRITE, &KiPacket);
    }
}

BOOL WINAPI KdDeviceRead(PVOID DeviceObject, PVOID FileObject, PVOID Buffer, ULONG Length, PLARGE_INTEGER StartingOffset)
{
    KD_IO_PACKET IoPacket;

    if (DeviceObject && KdIsValidPointer(Buffer, Length))
    {
        IoPacket.MajorFunction = IRP_MJ_READ;
        IoPacket.DeviceObject = (_DEVICE_OBJECT *)DeviceObject;
        IoPacket.FileObject = (_FILE_OBJECT *)FileObject;
        IoPacket.Parameters.Read.Buffer = Buffer;
        IoPacket.Parameters.Read.Length = Length;
        IoPacket.Parameters.Read.StartingOffset = StartingOffset;
        return SendIoPacket(&IoPacket);
    }
    return FALSE;
}

BOOL WINAPI KdDeviceWrite(PVOID DeviceObject, PVOID FileObject, PVOID Buffer, ULONG Length, PLARGE_INTEGER StartingOffset)
{
    KD_IO_PACKET IoPacket;

    if (DeviceObject && KdIsValidPointer(Buffer, Length))
    {
        IoPacket.MajorFunction = IRP_MJ_WRITE;
        IoPacket.DeviceObject = (_DEVICE_OBJECT *)DeviceObject;
        IoPacket.FileObject = (_FILE_OBJECT *)FileObject;
        IoPacket.Parameters.Read.Buffer = Buffer;
        IoPacket.Parameters.Read.Length = Length;
        IoPacket.Parameters.Read.StartingOffset = StartingOffset;
        return SendIoPacket(&IoPacket);
    }
    return FALSE;
}

BOOL WINAPI KdDeviceIoControl(PVOID DeviceObject, PVOID FileObject, ULONG IoControlCode, PVOID InputBuffer, ULONG InputBufferLength, PVOID OutputBuffer, ULONG OutputBufferLength, BOOL InternalDeviceIoControl)
{
    KD_IO_PACKET IoPacket;

    if (DeviceObject)
    {
        IoPacket.MajorFunction = IRP_MJ_DEVICE_CONTROL;
        IoPacket.DeviceObject = (_DEVICE_OBJECT *)DeviceObject;
        IoPacket.FileObject = (_FILE_OBJECT *)FileObject;
        IoPacket.Parameters.DeviceIoControl.IoControlCode = IoControlCode;
        IoPacket.Parameters.DeviceIoControl.InputBuffer = InputBuffer;
        IoPacket.Parameters.DeviceIoControl.InputBufferLength = InputBufferLength;
        IoPacket.Parameters.DeviceIoControl.OutputBuffer = OutputBuffer;
        IoPacket.Parameters.DeviceIoControl.OutputBufferLength = OutputBufferLength;
        IoPacket.Parameters.DeviceIoControl.InternalDeviceIoControl = InternalDeviceIoControl;
        return SendIoPacket(&IoPacket);
    }
    return FALSE;
}

VOID WINAPI KdExecuteCode(PVOID ProcessObject, PKSTART_ROUTINE StartAddress, PVOID Context)
{
    KI_PACKET KiPacket;

    KiPacket.Parameters.CreateThread.Process = ProcessObject;
    KiPacket.Parameters.CreateThread.StartAddress = StartAddress;
    KiPacket.Parameters.CreateThread.Context = Context;
    Syscall(IOCTL_CREATE_THREAD, &KiPacket);
}