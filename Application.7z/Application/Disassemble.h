
BOOL CALLBACK EditHex(HWND hWin,UINT uMsg,WPARAM wParam,LPARAM lParam);
BOOL CALLBACK DlgAssemble(HWND hWin,UINT uMsg,WPARAM wParam,LPARAM lParam);
void PrintDisasm(void *data, void *address, SIZE_T cb);
BOOL CALLBACK DlgHexa(HWND hWin,UINT uMsg,WPARAM wParam,LPARAM lParam);
BOOL CALLBACK DlgRange(HWND hWin,UINT uMsg,WPARAM wParam,LPARAM lParam);
extern CListView *List_Disasm;
unique unsigned long range_address;
unique unsigned long range_size;


#pragma pack()
typedef struct _SYMBOL {
  ULONG SizeOfStruct;
  ULONG TypeIndex;
  ULONG64 Reserved[2];
  ULONG Index;
  ULONG Size;
  ULONG64 ModBase;
  ULONG Flags;
  ULONG64 Value;
  ULONG64 Address;
  ULONG Register;
  ULONG Scope;
  ULONG Tag;
  ULONG NameLen;
  ULONG MaxNameLen;
  WCHAR Name[256];
} SYMBOL, *PSYMBOL;

