#include	"Kernel Detective.h"
#include	"Disassemble.h"
#include	"ShadowSSDT.h"


HMENU		Menu_ShadowSSDT;



void CALLBACK ShadowSSDT_Cmd(HWND hWin, WPARAM wParam, LPARAM lParam, CListView *Listv)
{
    ULONG		offset = 0;
    int			szCmd = 0;
    int			Pos = 0;
    KI_PACKET KiPacket;

    switch	(wParam)
    {
    case	SHADOW_SSDT_RESTORE:
    {
        int c = Listv->getSelCount() + Listv->getSelIndex();
        for (int i = Listv->getSelIndex(); i < c; i++)
        {
            KiPacket.Parameters.Common.Parameter1 = Listv->getUlong(i, 0, 10);
            if (KiPacket.Parameters.Common.Parameter1 < KiShadowSsdtLimit)
            {
                KiPacket.Parameters.Common.Parameter2 = Listv->getUlong(i, 3, 16);
                Syscall(IOCTL_SET_SHADOW_SSDT, &KiPacket);
            }
        }
        EnumShadowSSDT(Listv);
        break;
    }
    case	SHADOW_SSDT_ALL:
        Syscall(IOCTL_RESTORE_SHADOW_SSDT, NULL);
        EnumShadowSSDT(Listv);
        break;
    case	SHADOW_SSDT_SET:
        if	(GetAddress(Listv->getSelUlong(2, 16), &KiPacket.Parameters.Common.Parameter2))
        {
            KiPacket.Parameters.Common.Parameter1 = Listv->getSelUlong(0, 10);
            Syscall(IOCTL_SET_SHADOW_SSDT, &KiPacket);
            EnumShadowSSDT(Listv);
        }
        break;
    case	SHADOW_SSDT_REFRESH:
        EnumShadowSSDT(Listv);
        break;
    case	SHADOW_SSDT_CURRENT:
        UpdateCommonBuffer(Listv->getSelUlong(2, 16), 0x400);
        if (KiReadVirtualMemory(KiCurrentProcess.ProcessObject, GetCommonReadAddress(), GetCommonReadBuffer(), GetCommonReadSize()))
			PrintDisasm(GetCommonReadBuffer(), GetCommonReadAddress(), GetCommonReadSize());
        break;
    case	SHADOW_SSDT_REAL:
        UpdateCommonBuffer(Listv->getSelUlong(3, 16), 0x400);
        if (KiReadVirtualMemory(KiCurrentProcess.ProcessObject, GetCommonReadAddress(), GetCommonReadBuffer(), GetCommonReadSize()))
			PrintDisasm(GetCommonReadBuffer(), GetCommonReadAddress(), GetCommonReadSize());
        break;
    case SHADOW_SSDT_PROPERTIES:
    {
        WCHAR FileName[MAX_PATH];
        Listv->getSelText(5, FileName, sizeof(FileName));
        ShowFilePropertiesDlg(FileName);
        break;
    }
    case SHADOW_SSDT_DELETE:
    {
        WCHAR FileName[MAX_PATH];
        Listv->getSelText(5, FileName, MAX_PATH);
        if (FileDelete(FileName, FALSE))
        {
            MessageBox(hWin, L"File deleted successfully", AppName, MB_OK | MB_ICONINFORMATION);
        }
        else
        {
            UINT msgID = MessageBox(hWin, L"Cannot delete file normally !\r\nDo you want to force delete the file ?", AppName, MB_YESNO | MB_ICONERROR);
            if (msgID == IDYES)
            {
                SendMessage(hWin, WM_COMMAND, DRIVER_FORCEDELETE, 0);
            }
        }
        break;
    }
    case SHADOW_SSDT_FORCEDELETE:
    {
        WCHAR FileName[MAX_PATH];
        Listv->getSelText(5, FileName, MAX_PATH);
        if (FileDelete(FileName, TRUE))
        {
            MessageBox(hWin, L"File deleted successfully", AppName, MB_OK | MB_ICONINFORMATION);
        }
        else
        {
            MessageBox(hWin, L"File cannot be deleted !", AppName, MB_OK | MB_ICONERROR);
        }
        break;
    }
    case SHADOW_SSDT_VERIFY:
    {
        WCHAR FileName[MAX_PATH];
        Listv->getSelText(5, FileName, MAX_PATH);
        if (IsFileDigitallySigned(FileName))
        {
            MessageBox(hWin, L"File was verified successfully", AppName, MB_OK | MB_ICONINFORMATION);
        }
        else
        {
            MessageBox(hWin, L"File cannot be verified", AppName, MB_OK | MB_ICONEXCLAMATION);
        }
        break;
    }
    }
    return;
}




BOOL CALLBACK DlgShadowSSDT(HWND hWin,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
    POINT		XY;
    static CListView List_ShadowSSDT(hWin);

    switch (uMsg)
    {
    case	WM_INITDIALOG :
        List_ShadowSSDT.create(0,0,0,0, settings.clr_back, settings.clr_front, 0);
        List_ShadowSSDT.insertColumn(L"Index", 40);
        List_ShadowSSDT.insertColumn(L"Service Name", 200);
        List_ShadowSSDT.insertColumn(L"Current Address", 80);
        List_ShadowSSDT.insertColumn(L"Original Address", 80);
        List_ShadowSSDT.insertColumn(L"State", 70);
        List_ShadowSSDT.insertColumn(L"Module", 250);
        Menu_ShadowSSDT = GetSubMenu(LoadMenu(hInstance,MAKEINTRESOURCE(MENU_SHADOWSSDT)),0);
        break;
    case	WM_SHOWWINDOW:
        if ( (BOOL)wParam )
        {
            EnumShadowSSDT(&List_ShadowSSDT);
            CurrentList = &List_ShadowSSDT;
        }
        break;
    case	WM_COMMAND :
        ShadowSSDT_Cmd(hWin, wParam, lParam, &List_ShadowSSDT);
        break;
    case WM_SIZE:
    {
        if(wParam != SIZE_MINIMIZED)
            List_ShadowSSDT.resize(0, 0, LOWORD(lParam),HIWORD(lParam));
        break;
    };
    case	WM_NOTIFY :
        if	(((LPNMHDR)lParam)->hwndFrom == List_ShadowSSDT.getHwnd()  &&  ((LPNMHDR)lParam)->code == NM_RCLICK)
        {
            if	(0 == List_ShadowSSDT.isRawSelected())	break;
            GetCursorPos(&XY);
            TrackPopupMenu(Menu_ShadowSSDT,TPM_LEFTALIGN,XY.x,XY.y,NULL,hWin,NULL);
        };
        if(((LPNMHDR)lParam)->code == LVN_COLUMNCLICK)
        {
            ((LPNMLISTVIEW)lParam)->lParam = (LPARAM)&List_ShadowSSDT;
            ListView_SortItemsEx(((LPNMHDR)lParam)->hwndFrom, CListView::sort, (LPNMLISTVIEW)lParam);
            return TRUE;
        };
        if(((LPNMHDR)lParam)->code == NM_CUSTOMDRAW)
        {
            PWCHAR warn[2] = {ServiceWarn[1], ServiceWarn[2]};
            SetWindowLong(hWin, DWL_MSGRESULT, (LONG)Listview_handler((LPNMLVCUSTOMDRAW)lParam, warn, 2, 4, &List_ShadowSSDT));
            return TRUE;
        };
        break;
    };
    return 0;
};





void EnumShadowSSDT(CListView *Listv)
{
    WCHAR Temp[BUFFER_LEN] = L"";
    PSDT_ENTRY Ssdt = 0;
    ULONG Count, changed = 0, extra = 0;

    Listv->beginRefresh();
    Count = EnumerateShadowSsdt(&Ssdt);
    Listv->clear();
    __try
    {
        for (ULONG i = 0; i < Count; i++)
        {
            _snwprintf_s(Temp, COF(Temp), L"%ld", Ssdt[i].Index);
            Listv->insertRaw(Temp, TRUE);

            _snwprintf_s(Temp, COF(Temp), L"%s", (i < KiShadowSsdtLimit) ? KiShadowSsdtStrings[i] : L"-");
            Listv->insertRaw(Temp, FALSE);

            _snwprintf_s(Temp, COF(Temp), L"0x%p", Ssdt[i].Current);
            Listv->insertRaw(Temp, FALSE);

            _snwprintf_s(Temp, COF(Temp), L"0x%p", Ssdt[i].Original);
            Listv->insertRaw(Temp, FALSE);

            _snwprintf_s(Temp, COF(Temp), L"%s", ServiceWarn[Ssdt[i].Status]);
            if (Ssdt[i].Status == 1) 
                changed++;
            else if 
                (Ssdt[i].Status == 2) extra++;
            Listv->insertRaw(Temp, FALSE);

            if ( !_wcsnicmp( Ssdt[i].Module, L"\\??\\", 4 ) )
                Listv->insertRaw(Ssdt[i].Module + 4, FALSE);
            else
                Listv->insertRaw(QueryEnvironmentString(Ssdt[i].Module, Temp, BUFFER_LEN), FALSE);
        }
    }
    __except(1)
    {	};
    delete[] Ssdt;

    Listv->endRefresh();
    status.Format(L"Total Services :: %ld  -  Modified :: %ld  -  Extra :: %ld", Count, changed, extra);
};