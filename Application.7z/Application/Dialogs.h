

void SwitchTab();
LRESULT Listview_handler(LPNMLVCUSTOMDRAW lplvcd, PWCHAR *warnlist, int count, int status_pos, CListView *Listv);
BOOL CALLBACK DlgProc(HWND	hWin,UINT uMsg,WPARAM wParam,LPARAM lParam);
BOOL GetAddress(DWORD init, PDWORD plc);
WNDPROC SubclassEditBox(HWND);

// dialogs prototypes
BOOL CALLBACK DlgUnhook(HWND hWin,UINT uMsg,WPARAM wParam,LPARAM lParam);
BOOL CALLBACK DlgSSDT(HWND hWin, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK DlgShadowSSDT(HWND hWin, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK DlgProcess(HWND hWin, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK DlgIDT(HWND hWin, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK DlgDriver(HWND hWin, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK DlgModule(HWND hWin, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK DlgDisasm(HWND hWin, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK DlgDbgMsg(HWND hWin, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK DlgHandle(HWND hWin, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK DlgThread(HWND hWin, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK DlgExtras(HWND hWin, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK DlgGetFile(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK DlgSetFile(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK DlgGetModuleName(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);


#define SETFILEDLG(TITLE) (WCHAR *)DialogBoxParam(hInstance, MAKEINTRESOURCE(DLG_GETFILE), gWin, DlgSetFile, (LPARAM)TITLE);
#define GETFILEDLG(TITLE) (WCHAR *)DialogBoxParam(hInstance, MAKEINTRESOURCE(DLG_GETFILE), gWin, DlgGetFile, (LPARAM)TITLE);
#define GETMODULENAMEDLG(TITLE) (WCHAR *)DialogBoxParam(hInstance, MAKEINTRESOURCE(DLG_GETMODULENAME), gWin, DlgGetModuleName, (LPARAM)TITLE);


extern CListView *CurrentList;

class STATUS_BAR
{
public:
	void Initialize(HWND Parent, PWCHAR string);
	void Resize(int x, int y, int xc, int yc);
	int Format(PWCHAR format, ...);
	int Append(PWCHAR string);
private:
	HWND hStatus;
};

