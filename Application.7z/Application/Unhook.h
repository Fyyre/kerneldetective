

#define KRNL_SCAN_SECTIONS		1L
#define KRNL_SCAN_IAT			2L
#define KRNL_SCAN_EAT			4L

void EnumHooks(CListView*);

