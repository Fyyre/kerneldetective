#include	"Kernel Detective.h"
#include	"DebugView.h"


HMENU Menu_DbgMsg;



void CALLBACK Dbg_Cmd(HWND hWin,WPARAM wParam,LPARAM lParam, CListView *Listv)
{
	WCHAR Temp[BUFFER_LEN];
	ULONG offset = 0;
	int	szCmd = 0;
	int Pos = 0;
	DWORD eProcess = 0;

	switch	(wParam)
	{
	case	DBGMSG_ALL:
		{
			int c = Listv->getSelCount() + Listv->getSelIndex();
			WCHAR* text = (WCHAR*)malloc(c*BUFFER_LEN);
			memset(text,0,c*BUFFER_LEN);
			for (int i = Listv->getSelIndex(); i < c; i++)
			{
				wcscat_s(text, c * BUFFER_LEN, Listv->getText(i, 0, Temp, sizeof(Temp)));
				wcscat_s(text, c * BUFFER_LEN, L"          ");
				wcscat_s(text, c * BUFFER_LEN, Listv->getText(i, 1, Temp, sizeof(Temp)));
				wcscat_s(text, c * BUFFER_LEN, L"          ");
				wcscat_s(text, c * BUFFER_LEN, Listv->getText(i, 2, Temp, sizeof(Temp)));
				wcscat_s(text, c * BUFFER_LEN, L"\r\n");
			}
			SetClipboard(text);
			free(text);
            break;
		}
	case	DBGMSG_MSG:
		{
			SetClipboard(Listv->getSelText(2, Temp, sizeof(Temp)));
            break;
		}
	case	DBGMSG_PID:
		{
			SetClipboard(Listv->getSelText(1, Temp, sizeof(Temp)));
            break;
		}
	case	DBGMSG_TIME:
		{
			SetClipboard(Listv->getSelText(0, Temp, sizeof(Temp)));
            break;
		}
	case	DBGMSG_CLEAR:
		{
			Listv->clear();
			break;
		}
	}
    return;
}


void PrintDbgMsg(CListView *Listv)
{
    KI_PACKET KiPacket;
	LPDBGMSG Msg;
	SYSTEMTIME lpSystemTime;
	WCHAR Temp[BUFFER_LEN];
	__try
	{
		Syscall(IOCTL_DBG_MSG, &KiPacket);
        Msg = (LPDBGMSG)KiPacket.Parameters.Common.Parameter1;
		if (Msg)
		{
            for (ULONG i = 0; i < KiPacket.Parameters.Common.Parameter2; i++)
			{
				FileTimeToSystemTime((FILETIME*)&Msg[i].time, &lpSystemTime);
				_snwprintf_s(Temp, COF(Temp), _TRUNCATE, L"%02d:%02d:%02d", lpSystemTime.wHour, lpSystemTime.wMinute, lpSystemTime.wSecond );
				Listv->insertRaw(Temp, TRUE);
				_snwprintf_s(Temp, COF(Temp), _TRUNCATE, L"%u:%u -> [%s]", Msg[i].Cid.UniqueProcess, Msg[i].Cid.UniqueThread, Msg[i].process);
				Listv->insertRaw(Temp, FALSE);
				Listv->insertRaw(Msg[i].Msg, FALSE);
			}
			VirtualFree(Msg, 0, MEM_RELEASE);
		}
	}
    __except(EXCEPTION_EXECUTE_HANDLER)
	{
    }
}



BOOL CALLBACK DlgDbgMsg(HWND hWin,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	POINT		XY;
	static CListView List_DbgMsg(hWin);

    switch (uMsg)
    {
    case	WM_INITDIALOG:
		List_DbgMsg.create(0, 0, 0, 0, settings.clr_back, settings.clr_front, 0);
		List_DbgMsg.insertColumn(L"Time", 100);
		List_DbgMsg.insertColumn(L"Pid:Tid", 150);
        List_DbgMsg.insertColumn(L"Debug Print", 500);
        Menu_DbgMsg = GetSubMenu(LoadMenu(hInstance,MAKEINTRESOURCE(MENU_DBGMSG)),0);
		if (CaptureDbgMode) 
            SetTimer( hWin, TIMER_DBGMSG, 200, NULL);
        break;
	case	WM_TIMER:
		{
			if (CaptureDbgMode) 
                PrintDbgMsg(&List_DbgMsg);
			break;
		}
	case	WM_SHOWWINDOW:
		{
			if (wParam)	
			{
				status.Format(L"");
				CurrentList = &List_DbgMsg;
			}
			break;
		}
	case	WM_COMMAND :
		{
			Dbg_Cmd(hWin, wParam, lParam, &List_DbgMsg);
			break;
		}
	case WM_SIZE:
		{
			if(wParam != SIZE_MINIMIZED)
				List_DbgMsg.resize(0, 0, LOWORD(lParam),HIWORD(lParam));
			break;
		}
	case	WM_NOTIFY :
		{
			if(((LPNMHDR)lParam)->code == NM_CUSTOMDRAW)
			{
				SetWindowLong(hWin, DWL_MSGRESULT, (LONG)Listview_handler((LPNMLVCUSTOMDRAW)lParam, 0, 0, 0, &List_DbgMsg));
				return TRUE;
			}
			if(((LPNMHDR)lParam)->code == LVN_COLUMNCLICK)
			{
				((LPNMLISTVIEW)lParam)->lParam = (LPARAM)&List_DbgMsg;
				ListView_SortItemsEx(((LPNMHDR)lParam)->hwndFrom, CListView::sort, (LPNMLISTVIEW)lParam);
				return TRUE;
			}
			if	(((LPNMHDR)lParam)->hwndFrom == List_DbgMsg.getHwnd())
			{
				if	(((LPNMHDR)lParam)->code == NM_RCLICK)
				{
					if	(0 == List_DbgMsg.isRawSelected()) break;
					GetCursorPos(&XY);
					TrackPopupMenu(Menu_DbgMsg,TPM_LEFTALIGN,XY.x,XY.y,NULL,hWin,NULL);
				}
			}
			break;
		}
    }
    return 0;
}