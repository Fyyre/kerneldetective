#include "Kernel Detective.h"
#include "Disassemble.h"
#include "dumper.h"
#include "Driver.h"
#include <atlstr.h>
#include <psapi.h>
#include <vector>

#pragma comment(lib, "psapi.lib")

HMENU Menu_Driver;



#define IRP_MJ_MAXIMUM_FUNCTION         0x1b

typedef struct _DRIVER_EXTENSION {
    PVOID DriverObject;
    PVOID AddDevice;
    ULONG Count;
    UNICODE_STRING ServiceKeyName;
} DRIVER_EXTENSION, *PDRIVER_EXTENSION;

typedef struct _FAST_IO_DISPATCH {
    ULONG SizeOfFastIoDispatch;
    PVOID FastIoCheckIfPossible;
    PVOID FastIoRead;
    PVOID FastIoWrite;
    PVOID FastIoQueryBasicInfo;
    PVOID FastIoQueryStandardInfo;
    PVOID FastIoLock;
    PVOID FastIoUnlockSingle;
    PVOID FastIoUnlockAll;
    PVOID FastIoUnlockAllByKey;
    PVOID FastIoDeviceControl;
    PVOID AcquireFileForNtCreateSection;
    PVOID ReleaseFileForNtCreateSection;
    PVOID FastIoDetachDevice;
    PVOID FastIoQueryNetworkOpenInfo;
    PVOID AcquireForModWrite;
    PVOID MdlRead;
    PVOID MdlReadComplete;
    PVOID PrepareMdlWrite;
    PVOID MdlWriteComplete;
    PVOID FastIoReadCompressed;
    PVOID FastIoWriteCompressed;
    PVOID MdlReadCompleteCompressed;
    PVOID MdlWriteCompleteCompressed;
    PVOID FastIoQueryOpen;
    PVOID ReleaseForModWrite;
    PVOID AcquireForCcFlush;
    PVOID ReleaseForCcFlush;
} FAST_IO_DISPATCH, *PFAST_IO_DISPATCH;

typedef struct _DRIVER_OBJECT {
    USHORT Type;
    USHORT Size;
    PVOID DeviceObject;
    ULONG Flags;
    PVOID DriverStart;
    ULONG DriverSize;
    PVOID DriverSection;
    PDRIVER_EXTENSION DriverExtension;
    UNICODE_STRING DriverName;
    PUNICODE_STRING HardwareDatabase;
    PFAST_IO_DISPATCH FastIoDispatch;
    PVOID DriverInit;
    PVOID DriverStartIo;
    PVOID DriverUnload;
    PVOID MajorFunction[IRP_MJ_MAXIMUM_FUNCTION + 1];
} DRIVER_OBJECT, *PDRIVER_OBJECT;



VOID AddDriverReference(PVOID Reference, std::vector<PVOID> &VectReference, PDRIVER_ENTRY Drivers, ULONG DriverCount)
{

    if (Reference == NULL)
        return;


    //
    // Get the reference base address
    //
    for (ULONG i = 0; i < DriverCount; i++)
    {
        if (Drivers[i].ImageBase && Drivers[i].ImageSize)
        {
            if (Reference >= Drivers[i].ImageBase &&
                (ULONG_PTR)Reference < (ULONG_PTR)Drivers[i].ImageBase + Drivers[i].ImageSize)
            {
                Reference = Drivers[i].ImageBase;
                if (Reference == NULL)
                    return;
            }
        }
    }

    //
    // Check if reference exists
    //
    for (ULONG i = 0; i < VectReference.size(); i++)
    {
        if (Reference == VectReference[i])
            return;
    }

    //
    // Add reference
    //
    VectReference.push_back(Reference);
}

PWCHAR GetDriverReferences(PVOID lpDriverObject, PDRIVER_ENTRY Drivers, ULONG DriversCount)
{
    DRIVER_OBJECT DriverObject;
    std::vector<PVOID> VectReference;


    if (lpDriverObject == NULL || Drivers == NULL)
        return NULL;


    if (KiReadVirtualMemory(KiCurrentProcess.ProcessObject, lpDriverObject, &DriverObject, sizeof(DRIVER_OBJECT)))
    {
        
        AddDriverReference(DriverObject.DriverStart, VectReference, Drivers, DriversCount);

        if (DriverObject.DriverExtension != NULL)
        {
            DRIVER_EXTENSION DriverExtension;
            if (KiReadVirtualMemory(KiCurrentProcess.ProcessObject, DriverObject.DriverExtension, &DriverExtension, sizeof(DRIVER_EXTENSION)))
            {
                
                AddDriverReference(DriverExtension.AddDevice, VectReference, Drivers, DriversCount);

                if (DriverExtension.DriverObject != NULL && DriverExtension.DriverObject != lpDriverObject)
                {
                    DRIVER_OBJECT ExtensionDriverObject;
                    if (KiReadVirtualMemory(KiCurrentProcess.ProcessObject, DriverExtension.DriverObject, &ExtensionDriverObject, sizeof(DRIVER_OBJECT)))
                    {
                        AddDriverReference(ExtensionDriverObject.DriverStart, VectReference, Drivers, DriversCount);
                        AddDriverReference(ExtensionDriverObject.DriverInit, VectReference, Drivers, DriversCount);
                        AddDriverReference(ExtensionDriverObject.DriverStartIo, VectReference, Drivers, DriversCount);
                        AddDriverReference(ExtensionDriverObject.DriverUnload, VectReference, Drivers, DriversCount);
                        for (ULONG Index = 0; Index < IRP_MJ_MAXIMUM_FUNCTION; Index++)
                        {
                            AddDriverReference(ExtensionDriverObject.MajorFunction[Index], VectReference, Drivers, DriversCount);
                        }
                        if (ExtensionDriverObject.FastIoDispatch != NULL)
                        {
                            FAST_IO_DISPATCH FastIoDispatch;
                            if (KiReadVirtualMemory(KiCurrentProcess.ProcessObject, ExtensionDriverObject.FastIoDispatch, &FastIoDispatch, sizeof(FAST_IO_DISPATCH)))
                            {
                                ULONG MaxFastIoElements = min(26, (FastIoDispatch.SizeOfFastIoDispatch - 8) / 4);
                                for (ULONG Index = 0; Index < MaxFastIoElements; Index++)
                                {
                                    PVOID FastIoRoutine = ((PVOID *)&FastIoDispatch.FastIoCheckIfPossible)[Index];
                                    AddDriverReference(FastIoRoutine, VectReference, Drivers, DriversCount);
                                }
                            }
                        }
                    }
                }
            }
        }

        if (DriverObject.FastIoDispatch != NULL)
        {
            FAST_IO_DISPATCH FastIoDispatch;
            if (KiReadVirtualMemory(KiCurrentProcess.ProcessObject, DriverObject.FastIoDispatch, &FastIoDispatch, sizeof(FAST_IO_DISPATCH)))
            {
                ULONG MaxFastIoElements = min(26, (FastIoDispatch.SizeOfFastIoDispatch - 8) / 4);
                for (ULONG Index = 0; Index < MaxFastIoElements; Index++)
                {
                    PVOID FastIoRoutine = ((PVOID *)&FastIoDispatch.FastIoCheckIfPossible)[Index];
                    AddDriverReference(FastIoRoutine, VectReference, Drivers, DriversCount);
                }
            }
        }

        AddDriverReference(DriverObject.DriverInit, VectReference, Drivers, DriversCount);

        AddDriverReference(DriverObject.DriverStartIo, VectReference, Drivers, DriversCount);

        AddDriverReference(DriverObject.DriverUnload, VectReference, Drivers, DriversCount);

        for (ULONG Index = 0; Index < IRP_MJ_MAXIMUM_FUNCTION; Index++)
        {
            AddDriverReference(DriverObject.MajorFunction[Index], VectReference, Drivers, DriversCount);
        }
    }


    if (!VectReference.empty())
    {
        PWCHAR Result;
        BOOL Infected = FALSE;
        CString strReference = L"";
        PWCHAR Buffer = new WCHAR [MAX_PATH];

        for (ULONG i = 0; i < VectReference.size(); i++)
        {
            GetModulePath((ULONG_PTR)VectReference[i], Buffer, MAX_PATH, FALSE);
            if ((Buffer[0] == L'\0' || Buffer[0] == L'-'))
            {
                if (!Infected)
                {
                    strReference.AppendFormat(L"[??? :: 0x%p] ", VectReference[i]);
                    Infected = TRUE;
                }
            }
            else
            {
                strReference = strReference + L"[" + PathToFileName(Buffer) + L"] ";
            }
        }
        Result = new WCHAR [wcslen(strReference) + 1];
        RtlZeroMemory(Result, (wcslen(strReference) + 1) * sizeof(WCHAR));
        wcsncpy(Result, strReference.GetString(), wcslen(strReference));
        delete Buffer;
        return Result;
    }
    else
    {
        return NULL;
    }
}


VOID EnumDrivers(CListView *Listv)
{
    WCHAR Temp[BUFFER_LEN];
    PDRIVER_ENTRY Drivers, VisibleDrivers;
    ULONG k, hidden = 0, susp = 0;
    ULONG Count, VisibleCount;

    Listv->beginRefresh();
    UPDATE_MODULES();
    Count = EnumerateDrivers(&Drivers);
    Listv->clear();
    if (Drivers)
    {
        VisibleCount = EnumerateUserModeDrivers(&VisibleDrivers);
        for (ULONG i = 0; i < Count; i++)
        {
            BOOL Infected = FALSE;

            Listv->insertRaw(PathToFileName(Drivers[i].ImagePath), TRUE);

            _snwprintf_s(Temp, COF(Temp), L"0x%p",Drivers[i].DriverObject);
            Listv->insertRaw(Temp, FALSE);

            _snwprintf_s(Temp, COF(Temp), L"0x%p",Drivers[i].ImageBase);
            Listv->insertRaw(Temp, FALSE);

            _snwprintf_s(Temp, COF(Temp), L"0x%p",Drivers[i].EntryPoint);
            Listv->insertRaw(Temp, FALSE);

            _snwprintf_s(Temp, COF(Temp), L"0x%p",Drivers[i].Unload);
            Listv->insertRaw(Temp, FALSE);

            _snwprintf_s(Temp, COF(Temp), L"0x%p",Drivers[i].ImageSize);
            Listv->insertRaw(Temp, FALSE);

            decodefilepath(Drivers[i].ImagePath, COF(Drivers[i].ImagePath));
            QueryEnvironmentString(Drivers[i].ImagePath, Drivers[i].ImagePath, COF(Drivers[i].ImagePath));
            Listv->insertRaw(Drivers[i].ImagePath, FALSE);

            PWCHAR strReference = GetDriverReferences(Drivers[i].DriverObject, Drivers, Count);
            if (strReference == NULL || strReference[0] == L'\0')
            {
                Listv->insertRaw(L"-", FALSE);
            }
            else
            {
                Listv->insertRaw(strReference, FALSE);
                if (wcsstr(strReference, L"[??? :: 0x"))
                    Infected = TRUE;
                delete strReference;
            }

            for (k = 0; k < VisibleCount; k++)
                if (Drivers[i].ImageBase == NULL || VisibleDrivers[k].ImageBase == Drivers[i].ImageBase)
                    break;

            if ((Drivers[i].ImageBase != NULL && VisibleCount && VisibleDrivers && VisibleDrivers[k].ImageBase != Drivers[i].ImageBase) ||
                    Drivers[i].ImagePath[0] == L'\0' ||
                    Drivers[i].ImagePath[0] == L' ' ||
                    Drivers[i].ImagePath[0] == L'-')
            {
                wcsncpy_s(Temp, COF(Temp), L"Invisible", _TRUNCATE);
                hidden++;
            }
            else if (Infected)
            {
                wcsncpy_s(Temp, COF(Temp), L"Suspicious", _TRUNCATE);
                susp++;
            }
            else
            {
                wcsncpy_s(Temp, COF(Temp), L"-", _TRUNCATE);
            }
            Listv->insertRaw(Temp, FALSE);
        }
        delete[] Drivers;
        if (VisibleDrivers)
            delete[] VisibleDrivers;
    }

    Listv->endRefresh();
    status.Format(L"Total Drivers :: %ld  -  Hidden :: %ld  -  Suspicious :: %ld", Count, hidden, susp);
}


void CALLBACK Dirver_Cmd(HWND hWin, WPARAM wParam, LPARAM lParam, CListView *Listv)
{

    switch	(wParam)
    {
    case DRIVER_REFRESH:
    {
        EnumDrivers(Listv);
        break;
    }
    case DRIVER_GOTO_EP:
    {
        UpdateCommonBuffer(Listv->getSelUlong(3, 16), 0x400);
        if (KiReadVirtualMemory(KiCurrentProcess.ProcessObject, GetCommonReadAddress(), GetCommonReadBuffer(), GetCommonReadSize()))
            PrintDisasm(GetCommonReadBuffer(), GetCommonReadAddress(), GetCommonReadSize());
        break;
    }
    case DRIVER_GOTO_BASE:
    {
        UpdateCommonBuffer(Listv->getSelUlong(2, 16), 0x400);
        if (KiReadVirtualMemory(KiCurrentProcess.ProcessObject, GetCommonReadAddress(), GetCommonReadBuffer(), GetCommonReadSize()))
            PrintDisasm(GetCommonReadBuffer(), GetCommonReadAddress(), GetCommonReadSize());
        break;
    }
    case DRIVER_GOTO_DRIVER:
    {
        UpdateCommonBuffer(Listv->getSelUlong(1, 16), 0x400);
        if (KiReadVirtualMemory(KiCurrentProcess.ProcessObject, GetCommonReadAddress(), GetCommonReadBuffer(), GetCommonReadSize()))
            PrintDisasm(GetCommonReadBuffer(), GetCommonReadAddress(), GetCommonReadSize());
        break;
    }
    case DRIVER_GOTO_UNLOAD:
    {
        UpdateCommonBuffer(Listv->getSelUlong(4, 16), 0x400);
        if (KiReadVirtualMemory(KiCurrentProcess.ProcessObject, GetCommonReadAddress(), GetCommonReadBuffer(), GetCommonReadSize()))
            PrintDisasm(GetCommonReadBuffer(), GetCommonReadAddress(), GetCommonReadSize());
        break;
    }
    case DRIVER_DUMP:
    {
        ULONG_PTR ImageBase = Listv->getSelUlong(2, 16);
        SIZE_T ImageSize = Listv->getSelUlong(5, 16);
        if (ImageBase == NULL)
        {
            ImageBase = Listv->getSelUlong(3, 16);
            if (ImageBase)
                ImageSize = 0x1000;
            else
                break;
        }
        dumper dumpfile(KiCsrProcess.ProcessObject, ImageBase);
        dumpfile.dump_memory(0, ImageSize);
        break;
    }
    case DRIVER_PROPERTIES:
    {
        WCHAR FileName[MAX_PATH];
        Listv->getSelText(6, FileName, sizeof(FileName));
        ShowFilePropertiesDlg(FileName);
        break;
    }
    case DRIVER_DELETE:
    {
        WCHAR FileName[MAX_PATH];
        Listv->getSelText(6, FileName, MAX_PATH);
        if (FileDelete(FileName, FALSE))
        {
            MessageBox(hWin, L"File deleted successfully", AppName, MB_OK | MB_ICONINFORMATION);
        }
        else
        {
            UINT msgID = MessageBox(hWin, L"Cannot delete file normally !\r\nDo you want to force delete the file ?", AppName, MB_YESNO | MB_ICONERROR);
            if (msgID == IDYES)
            {
                SendMessage(hWin, WM_COMMAND, DRIVER_FORCEDELETE, 0);
            }
        }
        break;
    }
    case DRIVER_FORCEDELETE:
    {
        WCHAR FileName[MAX_PATH];
        Listv->getSelText(6, FileName, MAX_PATH);
        if (FileDelete(FileName, TRUE))
        {
            MessageBox(hWin, L"File deleted successfully", AppName, MB_OK | MB_ICONINFORMATION);
        }
        else
        {
            MessageBox(hWin, L"File cannot be deleted !", AppName, MB_OK | MB_ICONERROR);
        }
        break;
    }
    case DRIVER_VERIFY:
    {
        WCHAR FileName[MAX_PATH];
        Listv->getSelText(6, FileName, MAX_PATH);
        if (IsFileDigitallySigned(FileName))
        {
            MessageBox(hWin, L"File was verified successfully", AppName, MB_OK | MB_ICONINFORMATION);
        }
        else
        {
            MessageBox(hWin, L"File cannot be verified", AppName, MB_OK | MB_ICONEXCLAMATION);
        }
        break;
    }
    }
}


BOOL CALLBACK DlgDriver(HWND hWin,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
    POINT		XY;
    static CListView List_Driver(hWin);

    switch (uMsg)
    {
    case	WM_INITDIALOG :
        List_Driver.create(0, 0, 0, 0, settings.clr_back, settings.clr_front, 0);
        List_Driver.insertColumn(L"FileName", 150);
        List_Driver.insertColumn(L"DriverObject", 80);
        List_Driver.insertColumn(L"ImageBase", 80);
        List_Driver.insertColumn(L"EntryPoint", 80);
        List_Driver.insertColumn(L"UnloadRoutine", 80);
        List_Driver.insertColumn(L"Size", 80);
        List_Driver.insertColumn(L"Path", 250);
        List_Driver.insertColumn(L"References", 150);
        List_Driver.insertColumn(L"Status", 80);
        Menu_Driver = GetSubMenu(LoadMenu(hInstance,MAKEINTRESOURCE(MENU_DRIVER)),0);
        break;
    case	WM_SHOWWINDOW:
    {
        if (wParam)
        {
            EnumDrivers(&List_Driver);
            CurrentList = &List_Driver;
        }
        break;
    }
    case	WM_COMMAND :
    {
        Dirver_Cmd(hWin, wParam, lParam, &List_Driver);
        break;
    }
    case WM_SIZE:
    {
        if(wParam != SIZE_MINIMIZED)
            List_Driver.resize(0, 0, LOWORD(lParam),HIWORD(lParam));
        break;
    }
    case	WM_NOTIFY :
    {
        if	(((LPNMHDR)lParam)->hwndFrom == List_Driver.getHwnd()  &&  ((LPNMHDR)lParam)->code == NM_RCLICK)
        {
            if	(0 == List_Driver.isRawSelected())	break;
            GetCursorPos(&XY);
            TrackPopupMenu(Menu_Driver,TPM_LEFTALIGN,XY.x,XY.y,NULL,hWin,NULL);
        }
        if(((LPNMHDR)lParam)->code == LVN_COLUMNCLICK)
        {
            ((LPNMLISTVIEW)lParam)->lParam = (LPARAM)&List_Driver;
            ListView_SortItemsEx(((LPNMHDR)lParam)->hwndFrom, CListView::sort, (LPNMLISTVIEW)lParam);
            return TRUE;
        }
        if(((LPNMHDR)lParam)->code == NM_CUSTOMDRAW)
        {
            PWCHAR warn[] = {L"Invisible"/*, L"Suspicious"*/};
            SetWindowLong(hWin, DWL_MSGRESULT, (ULONG)Listview_handler((LPNMLVCUSTOMDRAW)lParam, warn, 1, 8, &List_Driver));
            return TRUE;
        }
        break;
    }
    }
    return FALSE;
}
