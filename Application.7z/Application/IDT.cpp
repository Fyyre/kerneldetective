#include	"Kernel Detective.h"
#include	"Disassemble.h"
#include	"IDT.h"


HMENU Menu_IDT;

const WCHAR* Int_Type[]	=
{
	L"Task", 
	L"Interrupt", 
	L"Trap"
};



void EnumIDT(CListView *Listv)
{
	WCHAR		Temp[BUFFER_LEN];
	int			i = 0;
	PKIDT_ENTRY	idt;
	SYSTEM_INFO	sinfo;
	int			changed = 0;


	Listv->beginRefresh();
	__try
	{
		Listv->clear();
		GetSystemInfo(&sinfo);
		UPDATE_MODULES();
		for (unsigned long k = 0; k < sinfo.dwNumberOfProcessors; k++)
		{
            EnumerateInterrupts((UCHAR)k, &idt);
			wcsncpy_s(Temp, COF(Temp), L"-", _TRUNCATE);
			Listv->insertRaw(Temp, true);
			_snwprintf_s(Temp, COF(Temp), L"CPU #%d", k);
			Listv->insertRaw(Temp, false);
			Listv->insertRaw(Temp, false);
			Listv->insertRaw(Temp, false);
			Listv->insertRaw(Temp, false);
			Listv->insertRaw(Temp, false);
			Listv->insertRaw(Temp, false);
			Listv->insertRaw(Temp, false);

			for ( i = 0; i < 256; i++)
			{
				_snwprintf_s(Temp, COF(Temp), L"0x%02x", i);
				Listv->insertRaw(Temp, true);

				_snwprintf_s(Temp, COF(Temp), L"0x%04X", idt[i].Selector);
				Listv->insertRaw(Temp, false);

				_snwprintf_s(Temp, COF(Temp), L"0x%p", (idt[i].Offset)|(idt[i].ExtendedOffset << 16));
				Listv->insertRaw(Temp, false);

				_snwprintf_s(Temp, COF(Temp), L"0x%p", InterruptServiceRoutines[i]);
				Listv->insertRaw(Temp, false);

				wcsncpy_s(Temp, COF(Temp), L"-", _TRUNCATE);
				if (idt[i].Access.type)
					_snwprintf_s(Temp, COF(Temp), L"%ldbit %s", (idt[i].Access.size + 1)*16, Int_Type[idt[i].Access.type - 1]);

				Listv->insertRaw(Temp, false);

				wcsncpy_s(Temp, COF(Temp), L"-", _TRUNCATE);
				if (idt[i].Access.type)
					_snwprintf_s(Temp, COF(Temp), L"Accessible from ring %ld", idt[i].Access.DPL);
				Listv->insertRaw(Temp, false);

				GetModulePath((idt[i].Offset)|(idt[i].ExtendedOffset << 16), (WCHAR *)&Temp, BUFFER_LEN);
				if (!_wcsnicmp(Temp, L"\\??\\", 4))
					Listv->insertRaw(Temp + 4, false);
				else
					Listv->insertRaw(QueryEnvironmentString(Temp, Temp, BUFFER_LEN), false);

				if (((idt[i].Offset)|(idt[i].ExtendedOffset << 16)) != InterruptServiceRoutines[i])
				{
					wcsncpy_s(Temp, COF(Temp), L"Interrupt/Trap/Task Handler modified", _TRUNCATE);
					++changed;
				}
				else
				{
					wcsncpy_s(Temp, COF(Temp), L"-", _TRUNCATE);
				};
				Listv->insertRaw(Temp, false);
			}
			delete[] idt;
		}
	}
	__except(EXCEPTION_EXECUTE_HANDLER)
	{};

	Listv->endRefresh();
	status.Format(L"Interrupt/Trap/Task :: 256 - Modified :: %ld -  Processors :: %ld", changed, sinfo.dwNumberOfProcessors);
}





void CALLBACK IDT_Cmd(HWND hWin, WPARAM wParam, LPARAM lParam, CListView *Listv)
{
	ULONG_PTR offset = 0;
	int szCmd = 0;
	int Pos = 0;

	switch	(wParam)
	{
	case IDT_REFRESH:
		{
			EnumIDT(Listv);
			break;
		};
	case IDT_OFFSET:
		{
			if	(GetAddress(Listv->getSelUlong(2, 16), &offset))
			{
				UCHAR Cpu = Listv->getSelIndex()/257;
				Pos = Listv->getSelUlong(0, 16);
                HookInterruptOffset(Cpu, Pos, offset);
				EnumIDT(Listv);
			};
			break;
		};
	case IDT_SELECTOR:
		{
			if	(GetAddress(Listv->getSelUlong(1, 16), &offset))
			{
				UCHAR Cpu = Listv->getSelIndex()/257;
				Pos = Listv->getSelUlong(0, 16);
				HookInterruptSelector(Cpu, Pos, (USHORT)offset);
				EnumIDT(Listv);
			};
			break;
		};
	case IDT_RESTORE:
		{
			offset = Listv->getSelUlong(3, 16);
			UCHAR Cpu = Listv->getSelIndex()/257;
			Pos = Listv->getSelUlong(0, 16);
            HookInterruptOffset(Cpu, Pos, offset);
			EnumIDT(Listv);
			break;
		};
	case IDT_GOTO:
		{
			UpdateCommonBuffer(Listv->getSelUlong(2, 16), 0x400);
			if (KiReadVirtualMemory(KiCurrentProcess.ProcessObject, GetCommonReadAddress(), GetCommonReadBuffer(), GetCommonReadSize()))
				PrintDisasm(GetCommonReadBuffer(), GetCommonReadAddress(), GetCommonReadSize());
			break;
		};
	};
    return;
};


BOOL CALLBACK DlgIDT(HWND hWin, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    POINT		XY;
	WCHAR		Temp[BUFFER_LEN];
	static CListView List_IDT(hWin);

    switch (uMsg)
    {
    case	WM_INITDIALOG :
		List_IDT.create(0, 0, 0, 0, settings.clr_back, settings.clr_front, 0);
		List_IDT.insertColumn(L"Index", 45);
		List_IDT.insertColumn(L"Sel", 50);
		List_IDT.insertColumn(L"Current ISR", 80);
		List_IDT.insertColumn(L"Real ISR", 80);
		List_IDT.insertColumn(L"Type", 100);
        List_IDT.insertColumn(L"Access Level (DPL)", 120);
		List_IDT.insertColumn(L"Module", 300);
		List_IDT.insertColumn(L"State", 200);
        Menu_IDT = GetSubMenu(LoadMenu(hInstance, MAKEINTRESOURCE(MENU_IDT)), 0);
        break;
	case	WM_SHOWWINDOW:
		if (wParam)
		{
			EnumIDT(&List_IDT);
			CurrentList = &List_IDT;
		}
		break;
    case	WM_COMMAND :
		IDT_Cmd(hWin, wParam, lParam, &List_IDT);
        break;
	case WM_SIZE:
		{
			if(wParam != SIZE_MINIMIZED)
				List_IDT.resize(0, 0, LOWORD(lParam), HIWORD(lParam));
			break;
		}
    case	WM_NOTIFY :
		if	(((LPNMHDR)lParam)->hwndFrom == List_IDT.getHwnd()  &&  ((LPNMHDR)lParam)->code == NM_RCLICK)
        {
			if (0 == List_IDT.getSelText(0, Temp, 4)) break;
			if (Temp[0] == '-')	break;
            GetCursorPos(&XY);
            TrackPopupMenu(Menu_IDT, TPM_LEFTALIGN, XY.x, XY.y, NULL, hWin, NULL);
        }
		if(((LPNMHDR)lParam)->code == NM_CUSTOMDRAW)
		{
			PWCHAR warn = L"-";
			SetWindowLong(hWin, DWL_MSGRESULT, (LONG)Listview_handler((LPNMLVCUSTOMDRAW)lParam, &warn, 1, 0, &List_IDT));
			return true;
		}
        break;
    }
    return 0;
}
