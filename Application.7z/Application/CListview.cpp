#include "CListview.h"

CListView::CListView(HWND parent)
{
	this->parent = parent;
	this->iCol = 0;
	this->preItem = 0;
	this->preColumn = 0;
	memset(&this->lvi, 0, sizeof(this->lvi));
	this->lvi.mask = LVIF_TEXT | LVIF_IMAGE;
	--this->lvi.iItem;
};


CListView::~CListView()
{
	ImageList_Destroy(ListView_GetImageList(this->hwnd, LVSIL_SMALL));
	DestroyWindow(this->hwnd);
};


LRESULT CALLBACK GenericListviewProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_PRINT:
		InvalidateRect(hwnd, NULL, TRUE);
		break;
	}
	return CallWindowProc((WNDPROC)GetWindowLongPtr(hwnd, GWLP_USERDATA), hwnd, uMsg, wParam, lParam);
}


WNDPROC SubclassListview(HWND hwnd)
{
	WNDPROC PreviousWndProc = (WNDPROC)SetWindowLongPtr(hwnd, GWLP_WNDPROC, (LONG)GenericListviewProc);
	SetWindowLongPtr(hwnd, GWLP_USERDATA, (LONG)PreviousWndProc);
	return PreviousWndProc;
}


void CListView::create(int x, int y, int width, int height, COLORREF BkColor, COLORREF TextColor, int defcol)
{
	this->hwnd = CreateWindowEx(WS_EX_STATICEDGE, WC_LISTVIEW, L"", 
		LVS_REPORT | LVS_ALIGNLEFT | WS_TABSTOP | WS_CHILD | WS_VISIBLE,
		x, y, width, height, this->parent, 0, 0, 0);
	this->preColumn = defcol;
	if (this->hwnd != 0)
	{
		ListView_SetBkColor(this->hwnd, BkColor);
		ListView_SetTextBkColor(this->hwnd, BkColor);
		ListView_SetTextColor(this->hwnd, TextColor);
		ListView_SetExtendedListViewStyle(this->hwnd, ListView_GetExtendedListViewStyle(this->hwnd) | 
			LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES | LVS_EX_DOUBLEBUFFER
			);
		SubclassListview(this->hwnd);
	};
};


void CListView::pickFromDlg(int Id, COLORREF BkColor, COLORREF TextColor)
{
	this->hwnd = GetDlgItem(this->parent, Id);
	if (this->hwnd != 0)
	{
		ListView_SetBkColor(this->hwnd, BkColor);
		ListView_SetTextBkColor(this->hwnd, BkColor);
		ListView_SetTextColor(this->hwnd, TextColor);
		SendMessage(this->hwnd,LVM_SETEXTENDEDLISTVIEWSTYLE,NULL,LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES | LVS_EX_DOUBLEBUFFER);
	};
};


HWND CListView::getHwnd()
{
	return this->hwnd;
};


void CListView::resize(int x, int y, int width, int height)
{
	MoveWindow(this->hwnd, x, y, width, height, TRUE);
};


void CListView::insertColumn(WCHAR *title,int width)
{
	LV_COLUMN lvc;
    lvc.mask = LVCF_TEXT|LVCF_WIDTH;
    lvc.cx = width;
    lvc.pszText = title;
	ListView_InsertColumn(this->hwnd, this->iCol, &lvc);
	++this->iCol;
};


void CListView::insertRaw(WCHAR *text, int newraw)
{
	this->lvi.pszText = text;
	if (0 == newraw)
	{
		ListView_SetItem(this->hwnd, &this->lvi);
	}
	else
	{
		this->lvi.iImage = ++this->lvi.iItem;
		this->lvi.iSubItem = 0;
		ListView_InsertItem(this->hwnd, &this->lvi);
	};
	++this->lvi.iSubItem;
};


void CListView::clear()
{
	ImageList_Destroy(ListView_GetImageList(this->hwnd, LVSIL_SMALL));
	ListView_DeleteAllItems(this->hwnd);
	this->lvi.iItem = -1;
};


bool CListView::isRawSelected()
{
	if (-1 == this->getSelIndex()) return false;
	return true;
};


WCHAR *CListView::getText(int index, int iSub, WCHAR *buffer, int size)
{
	LV_ITEM lvi;
	if (-1 == index) return 0;
	lvi.iItem = index;
	lvi.iSubItem = iSub;
	lvi.mask = LVIF_TEXT;
	lvi.pszText = buffer;
	lvi.cchTextMax = size;
	ListView_GetItem(this->hwnd, &lvi);
	return buffer;
};


WCHAR *CListView::getSelText(int iSub, WCHAR *buffer, int size)
{
	return this->getText(this->getSelIndex(), iSub, buffer, size);
};


unsigned int CListView::getUlong(int index, int iSub, int radix)
{
	WCHAR buffer[16] = L"";
	this->getText(index, iSub, buffer, 16);
	return wcstoul(buffer, 0, radix);
};


unsigned int CListView::getSelUlong(int iSub, int radix)
{
	return this->getUlong(this->getSelIndex(), iSub, radix);
};


int CListView::getSelCount()
{
	return ListView_GetSelectedCount(this->hwnd);
};


int CListView::getSelIndex()
{
	return ListView_GetNextItem(this->hwnd, -1, LVNI_SELECTED);
};


int CListView::getCount()
{
	return ListView_GetItemCount(this->hwnd);
};


void CListView::beginRefresh(void)
{
	this->preItem = this->getSelIndex();
	if (this->preItem == -1)
		this->preItem = 0;
};


void CListView::endRefresh(void)
{
	RECT rect;

	this->arrange(this->preColumn);
	ListView_GetItemRect(this->hwnd, this->preItem, &rect, LVIR_BOUNDS);
	ListView_Scroll(this->hwnd, 0, rect.top-50);
	ListView_SetItemState(this->hwnd, this->preItem, LVIS_FOCUSED | LVIS_SELECTED, LVIS_FOCUSED | LVIS_SELECTED);
};

NMLISTVIEW arrnmv;
void CListView::arrange(int Column)
{
	arrnmv.hdr.code = LVN_COLUMNCLICK;
	arrnmv.hdr.hwndFrom = this->hwnd;
	arrnmv.iItem = -1;
	arrnmv.iSubItem = Column;
	arrnmv.hdr.idFrom = 0;
	SendMessage(this->parent, WM_NOTIFY, 0, (LPARAM)&arrnmv);
};


int __stdcall CListView::sort(int index1, int index2, LPNMLISTVIEW pnmv)
{
	WCHAR	text1[260] = L"";
	WCHAR	text2[260] = L"";
	LV_ITEM lvi;
	CListView *Listv = (CListView *)pnmv->lParam;

	Listv->preColumn = pnmv->iSubItem;
	lvi.iSubItem = pnmv->iSubItem;
	lvi.mask = LVIF_TEXT;
	lvi.cchTextMax = 260;

	lvi.pszText = text1;
	lvi.iItem = index1;
	ListView_GetItem(pnmv->hdr.hwndFrom, &lvi);
	lvi.pszText = text2;
	lvi.iItem = index2;
	ListView_GetItem(pnmv->hdr.hwndFrom, &lvi);

	if ((text1[0] == '0' && text1[1] == 'x')&&(text2[0] == '0' && text2[1] == 'x'))
	{
		return (wcstoul(text1, 0, 16) > wcstoul(text2, 0, 16) ? 1 : -1);
	}
	else if (iswdigit(text1[0]) && iswdigit(text2[0]))
	{
		return (wcstoul(text1, 0, 10) > wcstoul(text2, 0, 10) ? 1 : -1);
	}
	else if (text1[0] == text2[0] && text1[0]== '-') 
	{
		return 0;
	}
	else if (text1[0] == '-')
	{
		return 1;
	}
	else if (text2[0] == '-') 
	{
		return -1;
	}
	else
	{
		return _wcsicmp(text1, text2);
	};
};