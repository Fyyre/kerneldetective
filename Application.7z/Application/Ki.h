#pragma once
#include "ntdll.h"


EXTERN_C NTSTATUS (NTAPI *pNtQuerySystemInformation)(SYSTEM_INFORMATION_CLASS, PVOID, ULONG, PULONG);
EXTERN_C NTSTATUS (NTAPI *pNtLoadDriver)(PUNICODE_STRING );
EXTERN_C NTSTATUS (NTAPI *pNtUnloadDriver)(PUNICODE_STRING);
EXTERN_C NTSTATUS (NTAPI *pNtDeviceIoControlFile)( HANDLE, HANDLE, PVOID, PVOID, PVOID, ULONG, PVOID, ULONG, PVOID, ULONG);


#define IRP_MJ_CREATE                   0x00
#define IRP_MJ_CREATE_NAMED_PIPE        0x01
#define IRP_MJ_CLOSE                    0x02
#define IRP_MJ_READ                     0x03
#define IRP_MJ_WRITE                    0x04
#define IRP_MJ_QUERY_INFORMATION        0x05
#define IRP_MJ_SET_INFORMATION          0x06
#define IRP_MJ_QUERY_EA                 0x07
#define IRP_MJ_SET_EA                   0x08
#define IRP_MJ_FLUSH_BUFFERS            0x09
#define IRP_MJ_QUERY_VOLUME_INFORMATION 0x0a
#define IRP_MJ_SET_VOLUME_INFORMATION   0x0b
#define IRP_MJ_DIRECTORY_CONTROL        0x0c
#define IRP_MJ_FILE_SYSTEM_CONTROL      0x0d
#define IRP_MJ_DEVICE_CONTROL           0x0e
#define IRP_MJ_INTERNAL_DEVICE_CONTROL  0x0f
#define IRP_MJ_SHUTDOWN                 0x10
#define IRP_MJ_LOCK_CONTROL             0x11
#define IRP_MJ_CLEANUP                  0x12
#define IRP_MJ_CREATE_MAILSLOT          0x13
#define IRP_MJ_QUERY_SECURITY           0x14
#define IRP_MJ_SET_SECURITY             0x15
#define IRP_MJ_POWER                    0x16
#define IRP_MJ_SYSTEM_CONTROL           0x17
#define IRP_MJ_DEVICE_CHANGE            0x18
#define IRP_MJ_QUERY_QUOTA              0x19
#define IRP_MJ_SET_QUOTA                0x1a
#define IRP_MJ_PNP                      0x1b
#define IRP_MJ_PNP_POWER                IRP_MJ_PNP      // Obsolete....
#define IRP_MJ_MAXIMUM_FUNCTION         0x1b
#define IRP_MJ_SCSI                     IRP_MJ_INTERNAL_DEVICE_CONTROL


/*********************************************************
**********************************************************
*********************************************************/


typedef
VOID
(*PKSTART_ROUTINE) (
    IN PVOID StartContext
    );

typedef struct DECLSPEC_ALIGN(1) _KD_IO_PACKET {
    UCHAR MajorFunction;
    union {

        struct {
            PVOID Buffer;
            ULONG Length;
            PLARGE_INTEGER StartingOffset;
        } Read;

        struct {
            PVOID Buffer;
            ULONG Length;
            PLARGE_INTEGER StartingOffset;
        } Write;

        struct {
            ULONG IoControlCode;
            PVOID InputBuffer;
            ULONG InputBufferLength;
            PVOID OutputBuffer;
            ULONG OutputBufferLength;
            BOOL  InternalDeviceIoControl;
        } DeviceIoControl;

    } Parameters;
    struct _DEVICE_OBJECT *DeviceObject;
    struct _FILE_OBJECT *FileObject;
} KD_IO_PACKET, *PKD_IO_PACKET;

typedef	struct DECLSPEC_ALIGN(1) _PROCESS_ENTRY {
	PVOID ProcessObject;
	ULONG ImageBase;
	PVOID Peb;
	ULONG Status;
	ULONG Pid;
	ULONG ParentId;
	ULONG Cb;
	WCHAR Name[MAX_PATH];
} PROCESS_ENTRY, *PPROCESS_ENTRY;

typedef struct DECLSPEC_ALIGN(1) _THREAD_ENTRY {
	PVOID Process;
	ULONG ParentId;
	PVOID Thread;
	ULONG Cid;
	PVOID Teb;
	PVOID ServiceTable;
	PVOID Address;
	ULONG Type;
	ULONG ThreadState;
	ULONG WaitReason;
	ULONG Status;
} THREAD_ENTRY, *PTHREAD_ENTRY;

typedef struct DECLSPEC_ALIGN(1) _DLL_ENTRY {
	PVOID BaseAddress;
	PVOID EntryPoint;
	ULONG SizeOfImage;
    WCHAR FullDllName[MAX_PATH];
} DLL_ENTRY, *PDLL_ENTRY;

typedef struct DECLSPEC_ALIGN(1) _SDT_ENTRY {
	ULONG Index;
	ULONG Current;
	ULONG Original;
	ULONG Status;
	WCHAR Module[MAX_PATH];
} SDT_ENTRY, *PSDT_ENTRY;

typedef struct DECLSPEC_ALIGN(1) _DRIVER_ENTRY {
	PVOID ImageBase;
	PVOID DriverObject;
	PVOID Unload;
	PVOID EntryPoint;
	ULONG ImageSize;
	WCHAR ImagePath[MAX_PATH];
} DRIVER_ENTRY, *PDRIVER_ENTRY;

typedef struct DECLSPEC_ALIGN(1) _HANDLE_ENTRY {
    PVOID QuotaProcess;
	PVOID UniqueProcessId;
    HANDLE Handle;
    PVOID Object;
    PVOID ObjectType;
    ULONG GrantedAccess;
	ULONG HandleCount;
	WCHAR Name[MAX_PATH];
} HANDLE_ENTRY, *PHANDLE_ENTRY;

typedef struct DECLSPEC_ALIGN(1) _OBJECT_TYPE_ENTRY {
	PVOID Address;
	DWORD Count;
	DWORD Index;
	struct {
		PVOID DumpProcedure;
		PVOID OpenProcedure;
		PVOID CloseProcedure;
		PVOID DeleteProcedure;
		PVOID ParseProcedure;
		PVOID SecurityProcedure;
		PVOID QueryNameProcedure;
		PVOID OkayToCloseProcedure;
	} ProcedureTable;
	WCHAR Name[MAX_PATH];
} OBJECT_TYPE_ENTRY, *POBJECT_TYPE_ENTRY;

typedef	struct DECLSPEC_ALIGN(1) _HOOK_ENTRY {
	ULONG ImageBase;
	ULONG Rva;
	ULONG Size;
	ULONG State;
	ULONG Parameter1;
	ULONG Parameter2;
    ULONG Parameter3;
    ULONG Parameter4;
	UCHAR Origin[64];
	UCHAR Current[64];
} HOOK_ENTRY, *PHOOK_ENTRY;

typedef struct DECLSPEC_ALIGN(1) _KIDT_ENTRY {
	USHORT Offset;
	USHORT Selector;
	struct {
		USHORT __unnamed1	: 8;
		USHORT type			: 2;
		USHORT __unnamed2	: 1;
		USHORT size			: 2;
		USHORT DPL			: 2;
		USHORT P			: 1;
	} Access;
	USHORT ExtendedOffset;
} KIDT_ENTRY, *PKIDT_ENTRY;

typedef struct _DISPATCHER_HEADER {
    UCHAR Type;
    UCHAR Absolute;
    UCHAR Size;
    UCHAR Inserted;
    LONG SignalState;
    LIST_ENTRY WaitListHead;
} DISPATCHER_HEADER;

typedef struct _KDPC {
    SHORT Type;
    UCHAR Number;
    UCHAR Importance;
    LIST_ENTRY DpcListEntry;
    PVOID DeferredRoutine;
    PVOID DeferredContext;
    PVOID SystemArgument1;
    PVOID SystemArgument2;
    PULONG_PTR Lock;
} KDPC, *PKDPC, *RESTRICTED_POINTER PRKDPC;

typedef struct _KTIMER {
    DISPATCHER_HEADER Header;
    ULARGE_INTEGER DueTime;
    LIST_ENTRY TimerListEntry;
    struct _KDPC *Dpc;
    LONG Period;
} KTIMER, *PKTIMER, *RESTRICTED_POINTER PRKTIMER;

typedef struct DECLSPEC_ALIGN(1) _TIMER_ENTRY {
	PVOID Object;
	PVOID Thread;
	KTIMER Timer;
	KDPC Dpc;
} TIMER_ENTRY, *PTIMER_ENTRY;

typedef struct DECLSPEC_ALIGN(1) _DBGMSG{
	CLIENT_ID Cid;
	LARGE_INTEGER time;
	WCHAR process[16];
	WCHAR Msg[512];
}DBGMSG, *LPDBGMSG;

typedef struct DECLSPEC_ALIGN(1) _BIOS_REGISTERS {
    ULONG Eax;
    ULONG Ecx;
    ULONG Edx;
    ULONG Ebx;
    ULONG Ebp;
    ULONG Esi;
    ULONG Edi;
    USHORT SegDs;
    USHORT SegEs;
    ULONG EFlags;
} BIOS_REGISTERS, *PBIOS_REGISTERS;


/*********************************************************
**********************************************************
*********************************************************/


typedef struct DECLSPEC_ALIGN(8) _IO_INPUT_BUFFER {
	union {
		ULONG Key;
		struct {
			ULONG Index : CHAR_BIT;
		};
	};
	ULONG ControlCode[UCHAR_MAX + 1];
	PVOID InputBuffer[UCHAR_MAX + 1];
} IO_INPUT_BUFFER, *PIO_INPUT_BUFFER;

typedef struct DECLSPEC_ALIGN(8) _KI_PACKET {

	union {

		struct {
			ULONG_PTR Parameter1;
			ULONG_PTR Parameter2;
			ULONG_PTR Parameter3;
			ULONG_PTR Parameter4;
			ULONG_PTR Parameter5;
			ULONG_PTR Parameter6;
			ULONG_PTR Parameter7;
			ULONG_PTR Parameter8;
		} Common;


        struct {
	        ULONG_PTR *InterruptServiceRoutines;
	        ULONG_PTR *Ssdt;
	        ULONG_PTR *ShadowSsdt;
	        BOOL      CaptureDbgMode;
	        USHORT    NtBuildNumber;
	        PWCHAR    KernelFileName;
	        PWCHAR    SystemrootPath;
            PVOID     KiKdProcess;
            PVOID     KiCsrProcess;
            PVOID     KiSystemProcess;
            PVOID     KiIdleProcess;
            PVOID     CsrProcessId;
        } Initialize;


        struct {
            KD_IO_PACKET Packet;
        } IoPacket;


        struct {
            PVOID Process;
            PKSTART_ROUTINE StartAddress;
            PVOID Context;
        } CreateThread;


        struct {
            ULONG Register;
            ULONGLONG Value;
            BOOL Write;
        } Msr;


        struct {
	        ULONG LowestPhysicalPage;
	        ULONG HighestPhysicalPage;
	        ULONG NumberOfPhysicalPages;
	        ULONG_PTR HighestUserAddress;
	        ULONG_PTR SystemRangeStart;
	        ULONG_PTR UserProbeAddress;
        } SystemInformation;


        struct {
	        PVOID KernelBase;
		    DWORD KernelSize;
		    PVOID PsLoadedModuleList;
		    PVOID MmLoadedUserImageList;
		    PVOID PspCidTable;
        } KernelInformation;


		struct {
			ULONG_PTR Address;
			BOOL GetExports;
            BOOL GetSymbols;
			PWCHAR Buffer;
            SIZE_T Size;
		} GetModuleInfo;


		struct {
			PVOID ProcessObject;
			PVOID VirtualAddress;
			PVOID Buffer;
			SIZE_T Size;
			PULONG NumberOfBytesRead;
		} VirtualRead;


		struct {
			PVOID ProcessObject;
			PVOID VirtualAddress;
			PVOID Buffer;
			SIZE_T Size;
			PULONG NumberOfBytesWritten;
		} VirtualWrite;


		struct {
			PLARGE_INTEGER PhysicalAddress;
			PVOID Buffer;
			SIZE_T Size;
		} PhysicalRead;


		struct {
			PLARGE_INTEGER PhysicalAddress;
			PVOID Buffer;
			SIZE_T Size;
		} PhysicalWrite;


		struct {
			PVOID ProcessObject;
			SIZE_T Size;
			PVOID Address;
		} VirtualAlloc;


		struct {
			PVOID ProcessObject;
			PVOID Address;
			SIZE_T Size;
		} VirtualFree;


		struct {
			PVOID ProcessObject;
			PVOID Address;
			SIZE_T Size;
			ULONG NewProtection;
			PULONG OldProtection;
		} VirtualProtect;


		struct {
			PVOID ProcessObject;
			PVOID Address;
			PMEMORY_BASIC_INFORMATION MemoryBasicInformation;
			SIZE_T Size;
		} VirtualQuery;


		struct {
			PVOID ProcessObject;
			PVOID SectionBase;
		} SectionUnmap;


		struct {
			PPROCESS_ENTRY Processes;
			ULONG Count;
		} ProcessEnumerate;


        struct {
			PVOID ProcessObject;
			PPROCESS_ENTRY Process;
		} ProcessQueryInformation;


		struct {
			PVOID ProcessObject;
            ULONG ProcessId;
			HANDLE Handle;
		} ProcessOpen;


		struct {
			PVOID ProcessObject;
		} ProcessSuspend;


		struct {
			PVOID ProcessObject;
			BOOL ForceResume;
		} ProcessResume;


		struct {
			PVOID ProcessObject;
            BOOL ForceKill;
		} ProcessKill;


        struct {
			PVOID ProcessObject;
            PDLL_ENTRY Dlls;
			ULONG Count;
		} DllEnumerate;


		struct {
			PVOID ProcessObject;
			PTHREAD_ENTRY Threads;
			ULONG Count;
		} ThreadEnumerate;


        struct {
			PVOID ThreadObject;
			PPROCESS_ENTRY Process;
            PTHREAD_ENTRY Thread;
		} ThreadQueryInformation;


		struct {
			PVOID ThreadObject;
            ULONG ThreadId;
			HANDLE Handle;
		} ThreadOpen;


		struct {
			PVOID ThreadObject;
		} ThreadSuspend;


		struct {
			PVOID ThreadObject;
			BOOL ForceResume;
		} ThreadResume;


		struct {
			PVOID ThreadObject;
		} ThreadKill;


		struct {
			PVOID ThreadObject;
			PCONTEXT Context;
		} ThreadCaptureStack;


		struct {
			PVOID ThreadObject;
			PCONTEXT Context;
			BOOL Set;
		} ThreadContext;


		struct {
			PVOID ProcessObject;
			HANDLE Handle;
		} CloseHandle;


		struct {
			PWCHAR FilePath;
			BOOL ForceDelete;
		} FileDelete;


		struct {
			PWCHAR SourceFilePath;
			PWCHAR DestinationFilePath;
		} FileCopy;


		struct {
			PKIDT_ENTRY InterruptEntries;
		} InterruptEnumerate;


		struct {
			ULONG Index;
			union {
				ULONG_PTR Offset;
				USHORT Selector;
			};
		} InterrupHook;


		struct {
			PSDT_ENTRY Ssdt;
			ULONG Count;
		} SsdtEnumerate;


		struct {
			PDRIVER_ENTRY Drivers;
			ULONG Count;
		} DriversEnumerate;


		struct {
			PVOID DriverObject;
			PDRIVER_ENTRY DriverInformation;
		} DriversQueryInformation;


		struct {
			PVOID *DeviceObjects;
			ULONG Count;
		} DevicesEnumerate;


		struct {
			PVOID Object;
			PWCHAR ObjectName;
		} ObjectQueryName;

        struct {
			PVOID Object;
			PWCHAR ObjectTypeName;
		} ObjectQueryTypeName;


		struct {
			PWCHAR ImagePath;
			ULONG Flags;
			ULONG Count;
			PHOOK_ENTRY HookEntries;
		} ImageHooksEnumerate;


		struct {
			PVOID ProcessObject;
			PHANDLE_ENTRY HandleEntries;
			ULONG Count;
		} HandlesEnumerate;


        struct {
            ULONG BiosCommand;
            PBIOS_REGISTERS BiosArguments;
        } BiosCall;


        struct {
            ULONG Disk;
            ULONG SectorNumber;
            USHORT SectorCount;
            PVOID Buffer;
            BOOL IsWrite;
        } DiskReadWrite;


	} Parameters;

    _KI_PACKET() {
        RtlZeroMemory(this, sizeof(KI_PACKET));
    }
} KI_PACKET, *PKI_PACKET;


/*********************************************************
**********************************************************
*********************************************************/

#define COF(_Array) (sizeof(_Array) / sizeof(_Array[0]))
#define UPDATE_MODULES() SyscallNaked(IOCTL_UPDATE_MODULE_LIST, NULL);
#define PAGE_SIZE 0x1000

#define INIT_SUCCESS				0
#define INIT_UNSUPPORTED_OS			1
#define INIT_CANNOT_LOCATE_ITEMS	2
#define INIT_CANNOT_LOCATE_KERNEL	3
#define INIT_CANNOT_LOAD_KERNEL		4
#define INIT_CANNOT_LOAD_DRIVER		5
#define INIT_UNKNOWN_ERROR  		6


/*********************************************************
**********************************************************
*********************************************************/


#define FILE_DEVICE_CORE  0x00008300
#define CORE_IOCTL_INDEX  0x830
#define CODE(CTL)						CTL_CODE(FILE_DEVICE_CORE,CTL,METHOD_NEITHER,FILE_ANY_ACCESS)
typedef enum {
	IOCTL_INITIALIZE = 1,
	IOCTL_ENUM_PROCESS,
	IOCTL_VM_READ,
	IOCTL_VM_WRITE,
	IOCTL_ENUM_DLL,
	IOCTL_DBG_MSG,
	IOCTL_ENUM_SSDT,
	IOCTL_SET_SSDT,
	IOCTL_ENUM_IDT,
	IOCTL_GET_MODULE,
	IOCTL_IDT_OFFSET,
	IOCTL_IDT_SELECTOR,
	IOCTL_ENUM_SHADOW_SSDT,
	IOCTL_SET_SHADOW_SSDT,
	IOCTL_ENUM_HOOKS,
	IOCTL_UNHOOK_KERNEL,
	IOCTL_ENUM_HANDLES,
	IOCTL_PROCESS_KILL,
	IOCTL_ENUM_DRIVER,
	IOCTL_RESTORE_SSDT,
	IOCTL_RESTORE_SHADOW_SSDT,
	IOCTL_HOOK_KIDEBUGSERVICE,
	IOCTL_UNHOOK_KIDEBUGSERVICE	,
	IOCTL_ALLOCATE_PROCESS_VM,
	IOCTL_DEALLOCATE_PROCESS_VM,
	IOCTL_PROCESS_OPEN,
	IOCTL_CLOSE_HANDLE,
	IOCTL_UPDATE_MODULE_LIST,
	IOCTL_THREAD_TO_PROCESS,
	IOCTL_GET_OBJECT_TYPE,
	IOCTL_ENUM_THREADS,
    IOCTL_THREAD_KILL,
	IOCTL_THREAD_SET_SSDT,
	IOCTL_THREAD_RESTORE_SSDT,
	IOCTL_THREAD_SUSPEND,
	IOCTL_PROCESS_SUSPEND,
	IOCTL_THREAD_RESUME,
	IOCTL_PROCESS_RESUME,
	IOCTL_ENUM_UNLOADED_DRIVERS,
	IOCTL_ENUM_TIMERS,
	IOCTL_ENUM_OBJECT_TYPES	,
	IOCTL_CANCEL_TIMER,
	IOCTL_CHANGE_OBJECT_PROC,
	IOCTL_ENUM_IMAGE_NOTIFY	,
	IOCTL_ENUM_PROCESS_NOTIFY,
	IOCTL_ENUM_THREAD_NOTIFY,
	IOCTL_ENUM_LEGO_NOTIFY,
	IOCTL_ENUM_CM_NOTIFY,
	IOCTL_DELETE_NOTIFY,
	IOCTL_DELETE_FILE,
	IOCTL_COPY_FILE	,
	IOCTL_ENUM_BUGCHECK,
	IOCTL_ENUM_BUGCHECK_REASON,
	IOCTL_ENUM_THREAD_TRACE,
	IOCTL_THREAD_OPEN,
	IOCTL_UNMAP_SECTION	,
	IOCTL_GET_PROCESS_INFO,
	IOCTL_PROCESS_BY_PID,
	IOCTL_PROCESS_BY_HANDLE	,
	IOCTL_THREAD_BY_PID	,
	IOCTL_THREAD_BY_HANDLE,
	IOCTL_THREAD_CONTEXT,
	IOCTL_GET_MEMORY_INFO,
	IOCTL_ALLOC_NONPAGED_POOL,
	IOCTL_FREE_NONPAGED_POOL,
	IOCTL_PROTECT_PROCESS_VM,
	IOCTL_QUERY_PROCESS_VM,
	IOCTL_PHYSICAL_PAGE_READ,
	IOCTL_PHYSICAL_PAGE_WRITE,
	IOCTL_GET_FILENAME_BY_OBJECT,
	IOCTL_GET_FILENAME_BY_HANDLE,
	IOCTL_READ_FILE_BY_HANDLE,
	IOCTL_WRITE_FILE_BY_HANDLE,
	IOCTL_READ_FILE_BY_NAME,
	IOCTL_WRITE_FILE_BY_NAME,
	IOCTL_OPEN_FILE	,
	IOCTL_ENUM_DEVICES,
	IOCTL_GET_DRIVER_INFO,
	IOCTL_GET_OBJECT_NAME,
	IOCTL_GET_CONTROL_REG,
	IOCTL_SET_CONTROL_REG,
	IOCTL_GET_KERNEL_INFO,
    IOCTL_CALL_BIOS,
    IOCTL_DISK_READWRITE,
    IOCTL_PORT_READ,
    IOCTL_PORT_WRITE,
    IOCTL_MSR,
    IOCTL_IO_PACKET,
    IOCTL_GET_OBJECT_BY_HANDLE,
    IOCTL_CREATE_THREAD,
    IOCTL_GET_TYPE_NAME
}IOCTL;


/*********************************************************
**********************************************************
*********************************************************/

 
EXTERN_C SHORT NtBuildNumber;
EXTERN_C BOOL CaptureDbgMode;
EXTERN_C WCHAR *ErrorMsg;
EXTERN_C ULONG_PTR *KiSsdt, *KiShadowSsdt;
EXTERN_C PWCHAR *KiSsdtStrings, *KiShadowSsdtStrings;
EXTERN_C ULONG KiSsdtLimit, KiShadowSsdtLimit;
EXTERN_C PPROCESS_ENTRY KiProcessList;
EXTERN_C PROCESS_ENTRY KiKdProcess;
EXTERN_C PROCESS_ENTRY KiCsrProcess;
EXTERN_C PROCESS_ENTRY KiSystemProcess;
EXTERN_C PROCESS_ENTRY KiIdleProcess;
EXTERN_C ULONG KiProcessCount;
EXTERN_C PROCESS_ENTRY KiCurrentProcess;
EXTERN_C ULONG_PTR InterruptServiceRoutines[256];
EXTERN_C PVOID KiReadBuffer, KiReadAddress;
EXTERN_C SIZE_T KiReadSize;


/*********************************************************
**********************************************************
*********************************************************/


LONG KeInitialize(PWCHAR lpDeviceName, PWCHAR lpDriverPath, BOOL DbgMode);
VOID KeCleanup(VOID);
ULONG SyscallNaked(ULONG Ioctl, KI_PACKET *KiPacket);
BOOL Syscall(ULONG Ioctl, KI_PACKET *KiPacket);
PVOID UpdateCommonBuffer(ULONG_PTR Address, SIZE_T Size);
PVOID GetCommonReadAddress();
SIZE_T GetCommonReadSize();
PVOID GetCommonReadBuffer();
ULONG_PTR GetProcessEntryPoint(PVOID ProcessObject, ULONG_PTR ImageBase);
VOID KdInitUnicodeString(OUT PUNICODE_STRING DestinationString, IN PCWSTR SourceString OPTIONAL);
ULONG EnumerateUserModeDrivers(PDRIVER_ENTRY *Drivers);


ULONG EnumerateProcesses(PPROCESS_ENTRY *Processes);
ULONG EnumerateThreads(PTHREAD_ENTRY *Threads, PVOID ProcessObject);
ULONG EnumerateDlls(PVOID ProcessObject, PDLL_ENTRY *Dlls);
ULONG EnumerateDrivers(PDRIVER_ENTRY *Drivers);
ULONG EnumerateDevices(PVOID **Devices);
ULONG EnumerateSsdt(PSDT_ENTRY *Ssdt);
ULONG EnumerateShadowSsdt(PSDT_ENTRY *ShadowSsdt);
VOID EnumerateInterrupts(UCHAR Cpu, PKIDT_ENTRY *Idt);
ULONG_PTR HookInterruptOffset(UCHAR Cpu, ULONG Index, ULONG_PTR Offset);
USHORT HookInterruptSelector(UCHAR Cpu, ULONG Index, USHORT Selector);
ULONG EnumerateObjectTypes(POBJECT_TYPE_ENTRY *ObjectTypesList);
ULONG EnumerateKernelHooks(PWCHAR ImagePath, PHOOK_ENTRY *Hooks, ULONG Flags);
ULONG EnumerateHandles(PHANDLE_ENTRY *Handle, PVOID ProcessObject);
PDRIVER_ENTRY GettDriverInformation(PVOID DriverObject);
PWCHAR GetObjectTypeName(PVOID Object);
PWCHAR GetTypeName(PVOID Type);
PWCHAR GetObjectName(PVOID Object);
BOOL KiReadVirtualMemory(PVOID ProcessObject, PVOID Address, PVOID Buffer, SIZE_T Size);
BOOL KiWriteVirtualMemory(PVOID ProcessObject, PVOID Address, PVOID Buffer, SIZE_T Size);
BOOL ReadPhysicalPages(PLARGE_INTEGER PhysicalAddress, PVOID Buffer, SIZE_T Size);
BOOL WritePhysicalPages(PLARGE_INTEGER PhysicalAddress, PVOID Buffer, SIZE_T Size);
PVOID AllocateVirtualMemory(PVOID ProcessObject, SIZE_T Size);
VOID FreeVirtualMemory(PVOID ProcessObject, PVOID Address, SIZE_T Size);
BOOL ProtectVirtualMemory(PVOID ProcessObject, PVOID Address, SIZE_T Size, ULONG NewProtection, PULONG OldProtection);
BOOL QueryVirtualMemory(PVOID ProcessObject, PVOID Address, SIZE_T Size, PMEMORY_BASIC_INFORMATION MemoryBasicInformation);
BOOL UnmapSection(PVOID ProcessObject, PVOID SectionBase);
HANDLE GetProcessHandle(PVOID ProcessObject);
HANDLE GetProcessHandleById(ULONG ProcessId);
BOOL ProcessKill(PVOID ProcessObject, BOOL ForceKill);
BOOL ProcessSuspend(PVOID ProcessObject);
BOOL ProcessResume(PVOID ProcessObject, BOOL ForceResume);
VOID GetProcessInformation(PVOID ProcessObject, PPROCESS_ENTRY Process);
HANDLE GetThreadHandle(PVOID ThreadObject);
HANDLE GetThreadHandleById(ULONG ThreadId);
BOOL ThreadKill(PVOID ThreadObject);
BOOL ThreadCaptureStack(PVOID ThreadObject, PCONTEXT Context);
BOOL ThreadSuspend(PVOID ThreadObject);
BOOL ThreadResume(PVOID ThreadObject, BOOL ForceResume);
VOID GetThreadProcessInformation(PVOID ThreadObject, PPROCESS_ENTRY Process, PTHREAD_ENTRY Thread);
BOOL CloseProcessHandle(PVOID ProcessObject, HANDLE Handle);
BOOL FileDelete(PWCHAR FilePath, BOOL ForceDelete);
BOOL FileCopy(PWCHAR SourceFilePath, PWCHAR DestinationFilePath);
BOOL SendIoPacket(PKD_IO_PACKET IoPacket);
