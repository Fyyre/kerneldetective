


class opts
{
public:
	HFONT		hFontCall;

	COLORREF	clr_front;
	COLORREF	clr_back;
	COLORREF	clr_back2;
	COLORREF	clr_warn_bk;
	COLORREF	clr_warn_txt;

	COLORREF	clr_disasm_call;
	COLORREF	clr_disasm_jmp;
	COLORREF	clr_disasm_jcc;
	COLORREF	clr_disasm_ret;

	BOOL		igrone_warn_bk;
	BOOL		igrone_warn_txt;
	BOOL		igrone_disasm;

	opts();
	COLORREF GetFrontClr(void);
	COLORREF GetBackClr(void);
	COLORREF GetBack2Clr(void);
	COLORREF GetWarnClr_bk(void);
	COLORREF GetWarnClr_txt(void);

	COLORREF GetDisasmClr_call(void);
	COLORREF GetDisasmClr_jmp(void);
	COLORREF GetDisasmClr_jcc(void);
	COLORREF GetDisasmClr_ret(void);

	BOOL GetIgnore_bk(void);
	BOOL GetIgnore_txt(void);
	BOOL GetIgnore_disasm(void);

	void SetFrontClr(COLORREF);
	void SetBackClr(COLORREF);
	void SetBack2Clr(COLORREF);
	void SetWarnClr_bk(COLORREF);
	void SetWarnClr_txt(COLORREF);

	void SetDisasmClr_call(COLORREF);
	void SetDisasmClr_jmp(COLORREF);
	void SetDisasmClr_jcc(COLORREF);
	void SetDisasmClr_ret(COLORREF);

	void SetIgnore_bk(BOOL);
	void SetIgnore_txt(BOOL);
	void SetIgnore_disasm(BOOL);

private:
	WCHAR ini_path[MAX_PATH];
};


BOOL CALLBACK DlgClr(HWND hWin,UINT uMsg,WPARAM wParam,LPARAM lParam);