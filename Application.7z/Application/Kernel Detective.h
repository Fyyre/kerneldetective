#pragma once
#ifdef __cplusplus
  #define unique           extern "C"    // Assure that names are not mangled
#else
  #define unique           extern
#endif


#include	<windows.h>
#include	<stdio.h>
#include	<commctrl.h>
#include	<commdlg.h> 
#include	<Dbghelp.h>
#include	<Tlhelp32.h>
#include	"CListview.h"
#include	"Ki.h"
#include    "Symbols.h"
#include	"resource.h"
#include	"Dialogs.h"
#include	"Help.h"
#include	"Settings.h"


#pragma	comment	(lib, "Dbghelp.lib")


#define AppName	L"Kernel Detective v1.4.1"


//	FUNCTIONS PROTOTYPES
BOOL EnablePriv(LPCSTR lpszPriv);
int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrevInstance,LPSTR lpCmdLine, int nCmdShow);


#define	BUFFER_LEN				512

#ifdef PROCESS_ALL_ACCESS
	#undef PROCESS_ALL_ACCESS
#endif
#define PROCESS_ALL_ACCESS        (STANDARD_RIGHTS_REQUIRED | SYNCHRONIZE | \
                                   0xFFF)






/************************************************/
/************************************************/


EXTERN_C HINSTANCE	hInstance;
EXTERN_C opts settings;
EXTERN_C STATUS_BAR	status;
EXTERN_C BOOL Analyze;
EXTERN_C HWND gWin;
EXTERN_C HWND hTab;
EXTERN_C const PWCHAR ServiceWarn[];

