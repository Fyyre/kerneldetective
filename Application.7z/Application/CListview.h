#include "windows.h"
#include <commctrl.h>

#pragma once

class CListView
{
public:
	CListView(HWND parent);
	~CListView();
	void create(int x, int y, int width, int height, COLORREF BkColor, COLORREF TextColor, int defcol);
	void pickFromDlg(int Id, COLORREF BkColor, COLORREF TextColor);
	HWND getHwnd();
	void resize(int x, int y, int width, int height);
	void insertColumn(WCHAR *title,int width);
	void insertRaw(WCHAR *text, int newraw);
	void clear();
	bool isRawSelected();
	WCHAR *getText(int index, int iSub, WCHAR* buffer, int size);
	WCHAR *getSelText(int iSub, WCHAR* buffer, int size);
	unsigned int getUlong(int index, int iSub, int radix);
	unsigned int getSelUlong(int iSub, int radix);
	int getSelCount();
	int getSelIndex();
	int getCount();
	void beginRefresh(void);
	void endRefresh(void);
	void arrange(int Column);
	static int __stdcall sort(int index1, int index2, LPNMLISTVIEW pnmv);
private:
	HWND parent;
	HWND hwnd;
	int iCol;
	LV_ITEM lvi;
	int preItem;
	int preColumn;
};