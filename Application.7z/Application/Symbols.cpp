#include <stdio.h>
#include <windows.h>
#include <dbghelp.h>
#include <psapi.h>
#include "Symbols.h"
#include "Ki.h"
#include "ntdll.h"

#pragma warning (disable : 4996)

struct {
	PWCHAR *Strings;
	PULONG_PTR Addresses;
	ULONG Count;
} Symbols;

UNEXPORTED_SYMBOLS UnexportedSymbols[] = {
    { -1,
      L"nt",
      L"KiSwapContext" },

    { -1,
      L"nt", 
      L"KiDispatchInterrupt" },

    { -1,
      L"nt", 
      L"IofCallDriver" },

    { -1,
      L"nt",
      L"IofCompleteRequest" }
};


PWCHAR FullKernelModulesPath[] = {
	L"\\Systemroot\\system32\\ntoskrnl.exe",
	L"\\Systemroot\\system32\\win32k.sys",
	L"\\Systemroot\\system32\\hal.dll",
    L"\\Systemroot\\system32\\kdcom.dll",
    L"\\Systemroot\\system32\\kd1394.dll",
	L"\\Systemroot\\system32\\drivers\\afd.sys",
	L"\\Systemroot\\system32\\drivers\\tcpip.sys",
	L"\\Systemroot\\system32\\drivers\\tdi.sys",
	L"\\Systemroot\\system32\\drivers\\wanarp.sys",
	L"\\Systemroot\\system32\\drivers\\disk.sys",
	L"\\Systemroot\\system32\\drivers\\fastfat.sys",
	L"\\Systemroot\\system32\\drivers\\ntfs.sys",
	L"\\Systemroot\\system32\\drivers\\cdfs.sys",
	L"\\Systemroot\\system32\\drivers\\dmio.sys",
	L"\\Systemroot\\system32\\drivers\\ftdisk.sys",
	L"\\Systemroot\\system32\\drivers\\fltmgr.sys",
	L"\\Systemroot\\system32\\drivers\\classpnp.sys",
	L"\\Systemroot\\system32\\drivers\\atapi.sys",
	L"\\Systemroot\\system32\\drivers\\ndis.sys",
	L"\\Systemroot\\system32\\drivers\\http.sys",
	L"\\Systemroot\\system32\\drivers\\scsiport.sys",
	L"\\Systemroot\\system32\\drivers\\kbdclass.sys"
};


PWCHAR ModulesPath[] = {

	// user libraries

	L"\\ntdll.dll",		//0
	L"\\kernel32.dll",	//1
	L"\\user32.dll",	//2
	L"\\gdi32.dll",		//3
	L"\\advapi32.dll",	//4
	L"\\shell32.dll",	//5
	L"\\ole32.dll",		//6

	// kernel drivers

	L"\\ntoskrnl.exe",	//7
	L"\\ntkrnlpa.exe",	//8
	L"\\win32k.sys",
	L"\\hal.dll",
    L"\\kdcom.dll",
    L"\\kd1394.dll",
	L"\\drivers\\afd.sys",
	L"\\drivers\\tcpip.sys",
	L"\\drivers\\tdi.sys",
	L"\\drivers\\wanarp.sys",
	L"\\drivers\\disk.sys",
	L"\\drivers\\fastfat.sys",
	L"\\drivers\\ntfs.sys",
	L"\\drivers\\cdfs.sys",
	L"\\drivers\\dmio.sys",
	L"\\drivers\\ftdisk.sys",
	L"\\drivers\\fltmgr.sys",
	L"\\drivers\\classpnp.sys",
	L"\\drivers\\atapi.sys",
	L"\\drivers\\ndis.sys",
	L"\\drivers\\http.sys",
	L"\\drivers\\scsiport.sys",
	L"\\drivers\\kbdclass.sys"
};

PWCHAR ModulesFileName[] = {
	L"ntdll.dll",
	L"kernel32.dll",
	L"user32.dll",
	L"gdi32.dll",
	L"advapi32.dll",
	L"shell32.dll",
	L"ole32.dll",
	L"ntoskrnl.exe",
	L"ntkrnlpa.exe",
	L"win32k.sys",
	L"hal.dll",
    L"kdcom.dll",
    L"kd1394.dll",
	L"afd.sys",
	L"tcpip.sys",
	L"tdi.sys",
	L"wanarp.sys",
	L"disk.sys",
	L"fastfat.sys",
	L"ntfs.sys",
	L"cdfs.sys",
	L"dmio.sys",
	L"ftdisk.sys",
	L"fltmgr.sys",
	L"classpnp.sys",
	L"atapi.sys",
	L"ndis.sys",
	L"http.sys",
	L"scsiport.sys",
	L"kbdclass.sys"
};

CONST ULONG UserModeLibraryCount = 7;

ULONG_PTR ModulesBaseAddress[COF(ModulesFileName)];


BOOL CALLBACK SymEnumSymbolsProc(PSYMBOL_INFO pSymInfo, ULONG SymbolSize, PVOID UserContext)
{
	PWCHAR String = new WCHAR [pSymInfo->NameLen + 1];

	RtlZeroMemory(String, (pSymInfo->NameLen + 1) * sizeof(WCHAR));
	Symbols.Count++;
	Symbols.Strings = (PWCHAR *)realloc(Symbols.Strings, Symbols.Count * sizeof(PWCHAR));
	Symbols.Addresses = (PULONG_PTR)realloc(Symbols.Addresses, Symbols.Count * sizeof(ULONG_PTR));
	wcsncpy(String, pSymInfo->Name, pSymInfo->NameLen);
	Symbols.Strings[Symbols.Count - 1] = String;
	Symbols.Addresses[Symbols.Count - 1] = (ULONG_PTR)pSymInfo->Address;
	return TRUE;
}


VOID InitializeSymbols(VOID)
{
	LPVOID DriversBaseAddress[1024];
	ULONG cbNeeded = 0;
	ULONG DriversCount;
	WCHAR Systempath[MAX_PATH];
	CHAR ModulePath[1024];


	Symbols.Strings = (PWCHAR *)malloc(0);
	Symbols.Addresses = (unsigned long *)malloc(0);
	SymSetOptions(SYMOPT_FAIL_CRITICAL_ERRORS | SYMOPT_UNDNAME);
	SymInitialize(NtCurrentProcess(), NULL, FALSE);
	EnumDeviceDrivers((LPVOID *)&DriversBaseAddress, sizeof(DriversBaseAddress), &cbNeeded);
	DriversCount = cbNeeded / sizeof(LPVOID);
	GetSystemDirectory(Systempath, COF(Systempath));
	for (ULONG ModulesCount = 0; ModulesCount < COF(ModulesFileName); ModulesCount++)
	{
		if (ModulesCount < UserModeLibraryCount)
		{
			_snprintf(ModulePath, COF(ModulePath), "%ws%ws", Systempath, ModulesPath[ModulesCount]);
			ModulesBaseAddress[ModulesCount] = (ULONG_PTR)LoadLibraryA(ModulePath);
			SymLoadModule64(NtCurrentProcess(), NULL, ModulePath, NULL, ModulesBaseAddress[ModulesCount], 0);
			SymEnumSymbols(NtCurrentProcess(), ModulesBaseAddress[ModulesCount], NULL, SymEnumSymbolsProc, NULL);
		} 
		else
		{
			for (ULONG T = 0; T < DriversCount; T++)
			{
				WCHAR DriverFileName[MAX_PATH] = L"";
				GetDeviceDriverBaseName(DriversBaseAddress[T], DriverFileName, COF(DriverFileName));
				if (!_wcsnicmp(DriverFileName, ModulesFileName[ModulesCount], COF(ModulesFileName[ModulesCount])))
				{
					ModulesBaseAddress[ModulesCount] = (ULONG_PTR)DriversBaseAddress[T];
					_snprintf(ModulePath, COF(ModulePath), "%ws%ws", Systempath, ModulesPath[ModulesCount]);
					SymLoadModule64(NtCurrentProcess(), NULL, ModulePath, NULL, ModulesBaseAddress[ModulesCount], 0);
					SymEnumSymbols(NtCurrentProcess(), ModulesBaseAddress[ModulesCount], NULL, SymEnumSymbolsProc, NULL);
					break;
				}
			}
		}
	}
}


PWCHAR GetModulePath(ULONG_PTR Address, PWCHAR ModulePath, SIZE_T Count, BOOL GetSymbols)
{
	WCHAR *buffer = new WCHAR[MAX_PATH];
	WCHAR *symbol = new WCHAR[MAX_PATH];
	ULONG_PTR disp;
    KI_PACKET KiPacket;

	RtlZeroMemory(buffer, sizeof(WCHAR) * MAX_PATH);
	RtlZeroMemory(symbol, sizeof(WCHAR) * MAX_PATH);
	RtlZeroMemory(ModulePath, sizeof(WCHAR) * Count);
    KiPacket.Parameters.GetModuleInfo.Address = Address;
	KiPacket.Parameters.GetModuleInfo.GetExports = FALSE;
    KiPacket.Parameters.GetModuleInfo.GetSymbols = GetSymbols;
	KiPacket.Parameters.GetModuleInfo.Buffer = buffer;
    KiPacket.Parameters.GetModuleInfo.Size = MAX_PATH;
	Syscall(IOCTL_GET_MODULE, &KiPacket);
    if (buffer[0] != '-' && GetSymbols && DecodeSymbol(Address, &disp, symbol, MAX_PATH, FALSE))
	{
		_snwprintf_s(ModulePath, Count, _TRUNCATE, disp ? L"%s::%s+%x" : L"%s::%s", buffer, symbol, disp);
	}
    else if (GetSymbols && DecodeSymbol(Address, &disp, symbol, MAX_PATH, FALSE))
	{
		_snwprintf_s(ModulePath, Count, _TRUNCATE, disp ? L"%s+%x" : L"%s", symbol, disp);
	}
	else
	{
		wcsncpy_s(ModulePath, Count, buffer, _TRUNCATE);
	}
	delete[] buffer;
	delete[] symbol;
	return ModulePath;
}


BOOL DecodeSymbol(ULONG_PTR Address, PULONG_PTR Displacement, PWCHAR StringBuffer, SIZE_T Count, BOOL DecodeModule)
{
	IMAGEHLP_MODULE64 ModuleInfo;
	KI_PACKET KiPacket;


	ZeroMemory(&ModuleInfo, sizeof(ModuleInfo));
	ZeroMemory(StringBuffer, Count * sizeof(WCHAR));
	ModuleInfo.SizeOfStruct = sizeof(ModuleInfo);
	SymGetModuleInfo64(NtCurrentProcess(), Address, &ModuleInfo);
	StringBuffer[0] = '\0';
	*Displacement = 0;
	if (!ModuleInfo.BaseOfImage) {
		WCHAR kernel_module[512];
		KiPacket.Parameters.GetModuleInfo.Address = Address;
		KiPacket.Parameters.GetModuleInfo.GetExports = TRUE;
        KiPacket.Parameters.GetModuleInfo.GetSymbols = TRUE;
		KiPacket.Parameters.GetModuleInfo.Buffer = kernel_module;
        KiPacket.Parameters.GetModuleInfo.Size = COF(kernel_module);
		Syscall(IOCTL_GET_MODULE, &KiPacket);
		if (kernel_module[0] == '-') return FALSE;
		wcsncpy(StringBuffer, kernel_module, Count);
		return TRUE;
	}

	for (ULONG c = 0; c < KiSsdtLimit; ++c)
	{
		if (Address >= KiSsdt[c] && Address < KiSsdt[c] + 16)
		{
			if (DecodeModule) 
				_snwprintf(StringBuffer, Count, L"%s.%s", ModuleInfo.ModuleName, KiSsdtStrings[c]);
			else 
				_snwprintf(StringBuffer, Count, L"%s", KiSsdtStrings[c]);
			*Displacement = Address - KiSsdt[c];
			return TRUE;
		}
	}

	for (ULONG c = 0; c < KiShadowSsdtLimit; ++c)
	{
		if (Address >= KiShadowSsdt[c] && Address < KiShadowSsdt[c] + 16)
		{
			if (DecodeModule) 
				_snwprintf(StringBuffer, Count, L"%s.%s", ModuleInfo.ModuleName, KiShadowSsdtStrings[c]);
			else 
				_snwprintf(StringBuffer, Count, L"%s", KiShadowSsdtStrings[c]);
			*Displacement = Address - KiShadowSsdt[c];
			return TRUE;
		}
	}

	
	ULONG temp_ptr = 0;
	BOOL temp_found = FALSE;
	for (ULONG c = 0; c < Symbols.Count; ++c)
	{
		if (Address >= Symbols.Addresses[c] && Address < Symbols.Addresses[c] + 16)
		{
			if (!temp_found) 
			{
				temp_found = TRUE;
				temp_ptr = c;
			} 
			else 
			{
				if (Symbols.Addresses[temp_ptr] - Address > Symbols.Addresses[c] - Address) 
					temp_ptr = c;
			}
		}
	}

	if (temp_found)
	{
		if (DecodeModule)
			_snwprintf(StringBuffer, Count, L"%s.%s", ModuleInfo.ModuleName, Symbols.Strings[temp_ptr]);
		else 
			_snwprintf(StringBuffer, Count, L"%s", Symbols.Strings[temp_ptr]);
		*Displacement = Address - Symbols.Addresses[temp_ptr];
		return TRUE;
	}
	

	return FALSE;
}


VOID CleanupSymbols(VOID)
{
	for (int c = 0; c < COF(ModulesFileName); ++c)
	{
		SymUnloadModule64(NtCurrentProcess(), ModulesBaseAddress[c]);
	}

	for (unsigned long c = 0; c < Symbols.Count; ++c)
	{
		free(Symbols.Strings[c]);
	}

	free(Symbols.Addresses);
	free(Symbols.Strings);

	SymCleanup(NtCurrentProcess());
}