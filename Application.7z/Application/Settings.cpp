#include "Kernel Detective.h"





WCHAR* test2[] = 
{
    L"0",
	L"4",
	L"500",
	L"652",
	L"732",
	L"1848",
	L"720",
    L"1584",
	L"636",
};

WCHAR* test3[] = 
{
	L"System Idle Process",
	L"System",
	L"smss.exe",
	L"csrss.exe",
	L"phide_ex.exe",
	L"winlogon.exe",
    L"svchost.exe",
	L"explorer.exe",
	L"services.exe"
};



CListView *List_Test, *List_Dasm;
HWND hDlg;

opts::opts()
{
	GetCurrentDirectory( MAX_PATH, ini_path );
	wcsncat_s(ini_path, L"\\Settings.ini", wcslen(L"\\Settings.ini"));
	clr_front = GetFrontClr();

	clr_back = GetBackClr();
	clr_back2 = GetBack2Clr();

	clr_warn_bk = GetWarnClr_bk();
	clr_warn_txt = GetWarnClr_txt();

	clr_disasm_call = GetDisasmClr_call();
	clr_disasm_jmp = GetDisasmClr_jmp();
	clr_disasm_jcc = GetDisasmClr_jcc();
	clr_disasm_ret = GetDisasmClr_ret();

	igrone_warn_bk = GetIgnore_bk();
	igrone_warn_txt = GetIgnore_txt();
	igrone_disasm = GetIgnore_disasm();

	hFontCall = CreateFont(-11, 0, 0, 0, FW_BLACK, 0, 0, 0, 0, 0, 0, 0, 0, L"Courier New");
};


COLORREF opts::GetDisasmClr_call(void)
{
	return GetPrivateProfileInt( L"Disasm", L"Call", RGB(0,0,160), ini_path );
};

COLORREF opts::GetDisasmClr_jmp(void)
{
	return GetPrivateProfileInt( L"Disasm", L"Jmp", RGB(128,0,0), ini_path );
};

COLORREF opts::GetDisasmClr_jcc(void)
{
	return GetPrivateProfileInt( L"Disasm", L"Jcc", RGB(200,128,0), ini_path );
};

COLORREF opts::GetDisasmClr_ret(void)
{
	return GetPrivateProfileInt( L"Disasm", L"Ret", RGB(0,0,160), ini_path );
};



void opts::SetDisasmClr_call( COLORREF clr )
{
	WCHAR str[20];
	_ultow_s( clr, str, 10 );
	WritePrivateProfileString( L"Disasm", L"Call", str, ini_path );
};

void opts::SetDisasmClr_jmp( COLORREF clr )
{
	WCHAR str[20];
	_ultow_s( clr, str, 10 );
	WritePrivateProfileString( L"Disasm", L"Jmp", str, ini_path );
};

void opts::SetDisasmClr_jcc( COLORREF clr )
{
	WCHAR str[20];
	_ultow_s( clr, str, 10 );
	WritePrivateProfileString( L"Disasm", L"Jcc", str, ini_path );
};

void opts::SetDisasmClr_ret( COLORREF clr )
{
	WCHAR str[20];
	_ultow_s( clr, str, 10 );
	WritePrivateProfileString( L"Disasm", L"Ret", str, ini_path );
};


BOOL opts::GetIgnore_disasm(void)
{
	return GetPrivateProfileInt( L"Disasm", L"Ignore", 0, ini_path );
};

void opts::SetIgnore_disasm(BOOL flag)
{
	WCHAR str[20];
	_ultow_s(flag, str, 10);
	WritePrivateProfileString( L"Disasm", L"Ignore", str, ini_path );
};





COLORREF opts::GetFrontClr(void)
{
	return GetPrivateProfileInt( L"Color", L"Front", RGB(0,0,0), ini_path );
};


COLORREF opts::GetBackClr(void)
{
	return GetPrivateProfileInt( L"Color", L"Back", RGB(255,255,255), ini_path );
};


COLORREF opts::GetBack2Clr(void)
{
	return GetPrivateProfileInt( L"Color", L"Back2", RGB(250,250,255), ini_path );
};


COLORREF opts::GetWarnClr_bk(void)
{
	return GetPrivateProfileInt( L"Color", L"Warn_bk", RGB(255,255,255), ini_path );
};


COLORREF opts::GetWarnClr_txt(void)
{
	return GetPrivateProfileInt( L"Color", L"Warn_txt", RGB(255,0,0), ini_path );
};


BOOL opts::GetIgnore_bk(void)
{
	return GetPrivateProfileInt( L"Color", L"Ignore_bk", 1, ini_path );
};


BOOL opts::GetIgnore_txt(void)
{
	return GetPrivateProfileInt( L"Color", L"Ignore_txt", 0, ini_path );
};


void opts::SetFrontClr( COLORREF clr )
{
	WCHAR str[20];
	_ultow_s( clr, str, 10 );
	WritePrivateProfileString( L"Color", L"Front", str, ini_path );
}


void opts::SetBackClr( COLORREF clr )
{
	WCHAR str[20];
	_ultow_s( clr, str, 10 );
	WritePrivateProfileString( L"Color", L"Back", str, ini_path );
}


void opts::SetBack2Clr( COLORREF clr )
{
	WCHAR str[20];
	_ultow_s( clr, str, 10 );
	WritePrivateProfileString( L"Color", L"Back2", str, ini_path );
};


void opts::SetWarnClr_bk( COLORREF clr )
{
	WCHAR str[20];
	_ultow_s( clr, str, 10 );
	WritePrivateProfileString( L"Color", L"Warn_bk", str, ini_path );
};


void opts::SetWarnClr_txt( COLORREF clr )
{
	WCHAR str[20];
	_ultow_s( clr, str, 10 );
	WritePrivateProfileString( L"Color", L"Warn_txt", str, ini_path );
};


void opts::SetIgnore_bk(BOOL flag)
{
	WCHAR str[20];
	_ultow_s( flag, str, 10 );
	WritePrivateProfileString( L"Color", L"Ignore_bk", str, ini_path );
};


void opts::SetIgnore_txt(BOOL flag)
{
	WCHAR str[20];
	_ultow_s( flag, str, 10 );
	WritePrivateProfileString( L"Color", L"Ignore_txt", str, ini_path );
};


COLORREF Text, Back1, Back2, Warn1, Warn2;
COLORREF Call, Jmp, Jcc, Ret;

LRESULT Listview_Test( LPNMLVCUSTOMDRAW lplvcd )
{
	WCHAR Temp[BUFFER_LEN] = L"";
	LVCOLUMN lvc;

    switch(lplvcd->nmcd.dwDrawStage) 
    {
        case CDDS_PREPAINT : 
            return CDRF_NOTIFYITEMDRAW;
        case CDDS_ITEMPREPAINT: //Before an item is drawn
			lplvcd->clrText = Text;
			if ((int)lplvcd->nmcd.dwItemSpec == 4 && lplvcd->nmcd.hdr.idFrom == CLR_TEST_LV)
			{
				if (!(BST_CHECKED == IsDlgButtonChecked(hDlg, CLR_IGNORE_TXT)))
				{
					lplvcd->clrText = Warn2;
					return CDRF_NEWFONT;
				}
				if (!(BST_CHECKED == IsDlgButtonChecked(hDlg, CLR_IGNORE_BK)))
				{ 
					lplvcd->clrTextBk = Warn1;
					return CDRF_NEWFONT;
				}
			}

			//
			// disassembler highlighting
			//
			lvc.mask = LVCF_TEXT;
			lvc.cchTextMax = sizeof(Temp);
			lvc.pszText = Temp;
			ListView_GetColumn(lplvcd->nmcd.hdr.hwndFrom, 0, &lvc);
			if (!(BST_CHECKED == IsDlgButtonChecked(hDlg, CLR_IGNORE_DISASM)) && lplvcd->nmcd.hdr.idFrom == CLR_DASM_LV)
			{
				List_Dasm->getText(lplvcd->nmcd.dwItemSpec, 0, Temp, sizeof(Temp));
				if (!wcsncmp(L"call", Temp, 4))
				{
					SelectObject(lplvcd->nmcd.hdc, settings.hFontCall);
					lplvcd->clrText = Call;
				}
				else if (!wcsncmp(L"ret", Temp, 3))
				{
					lplvcd->clrText = Ret;
					return CDRF_NEWFONT;
				}
				else if (!wcsncmp(L"jmp", Temp, 3))
				{
					lplvcd->clrText = Jmp;
				}
				else if (!wcsncmp(L"j", Temp, 1))
				{
					lplvcd->clrText = Jcc;
				}
			}

			if (((int)lplvcd->nmcd.dwItemSpec%2)==0)
            {
                //customize item appearance
				lplvcd->clrTextBk = Back1;
                return CDRF_NEWFONT;
            }
            else{
                lplvcd->clrTextBk = Back2;
                return CDRF_NEWFONT;
            }
            break;

        //Before a subitem is drawn
    }
    return CDRF_DODEFAULT;
}


BOOL CALLBACK DlgClr(HWND hWin,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	WCHAR	Temp[BUFFER_LEN]=L"";
	CHOOSECOLOR	Clr;
	COLORREF	custclr[16];
	
    switch (uMsg)
    {
	case	WM_INITDIALOG:
		{
			Text = settings.clr_front;
			Back1 = settings.clr_back;
			Back2 = settings.clr_back2;
			Warn1 = settings.clr_warn_bk;
			Warn2 = settings.clr_warn_txt;

			Call = settings.clr_disasm_call;
			Jmp = settings.clr_disasm_jmp;
			Jcc = settings.clr_disasm_jcc;
			Ret = settings.clr_disasm_ret;

			List_Test = new CListView(hWin);
			List_Test->pickFromDlg(CLR_TEST_LV, settings.clr_back, settings.clr_front);
			List_Test->insertColumn(L"Process ID",80);
			List_Test->insertColumn(L"Process Name",240);
			for (int i = 0; i < sizeof(test2)/sizeof(WCHAR*); i++)
			{
				List_Test->insertRaw(test2[i], TRUE);
				List_Test->insertRaw(test3[i], FALSE);
			}
			CheckDlgButton(hWin, CLR_IGNORE_BK, settings.GetIgnore_bk());
			CheckDlgButton(hWin, CLR_IGNORE_TXT, settings.GetIgnore_txt());
			CheckDlgButton(hWin, CLR_IGNORE_DISASM, settings.GetIgnore_disasm());

			List_Dasm = new CListView(hWin);
			List_Dasm->pickFromDlg(CLR_DASM_LV, settings.clr_back, settings.clr_front);
			List_Dasm->insertColumn(L"Instructions", 410);
			List_Dasm->insertRaw(L"push dword ptr [ebp+8]", true);
			List_Dasm->insertRaw(L"call KeAlertThread", true);
			List_Dasm->insertRaw(L"test eax, eax", true);
			List_Dasm->insertRaw(L"jl 805D4B31", true);
			List_Dasm->insertRaw(L"jmp 805D4c42", true);
			List_Dasm->insertRaw(L"mov ecx, dword ptr [ebp+8]", true);
			List_Dasm->insertRaw(L"call ObfDereferenceObject", true);
			List_Dasm->insertRaw(L"xor eax, eax", true);
			List_Dasm->insertRaw(L"leave", true);
			List_Dasm->insertRaw(L"retn 4", true);

			hDlg = hWin;
			break;
		};
	case	WM_COMMAND:
		{
			for (int i = 0; i <= 15; i++)
			custclr[i] = RGB(255,255,255);
			Clr.lStructSize    = sizeof (CHOOSECOLOR) ;
			Clr.hwndOwner      = hWin ;
			Clr.hInstance      = NULL ;
			Clr.lpCustColors   = custclr ;
			Clr.Flags          = CC_RGBINIT | CC_FULLOPEN ;
			Clr.lCustData      = 0 ;
			Clr.lpfnHook       = NULL ;
			Clr.lpTemplateName = NULL ;
			switch(wParam)
			{
			case CLR_OK:
				Msg(L"Effects will be applied after restart application");
				settings.SetIgnore_bk(BST_CHECKED == IsDlgButtonChecked(hWin, CLR_IGNORE_BK));
				settings.SetIgnore_txt(BST_CHECKED == IsDlgButtonChecked(hWin, CLR_IGNORE_TXT));
				settings.SetFrontClr(Text);
				settings.SetBackClr(Back1);
				settings.SetBack2Clr(Back2);
				settings.SetWarnClr_bk(Warn1);
				settings.SetWarnClr_txt(Warn2);

				settings.SetIgnore_disasm(BST_CHECKED == IsDlgButtonChecked(hWin, CLR_IGNORE_DISASM));
				settings.SetDisasmClr_call(Call);
				settings.SetDisasmClr_jcc(Jcc);
				settings.SetDisasmClr_jmp(Jmp);
				settings.SetDisasmClr_ret(Ret);
				EndDialog(hWin,0);
				break;
			case CLR_EXIT:
				EndDialog(hWin, 0);
				break;
			case CLR_FRONT:
				Clr.rgbResult = settings.clr_front;
				if (ChooseColor( &Clr ))
					Text = Clr.rgbResult;
				break;
			case CLR_BACK:
				Clr.rgbResult = settings.clr_back;
				if (ChooseColor( &Clr ))
					Back1 = Clr.rgbResult;
				break;
			case CLR_BACK2:
				Clr.rgbResult = settings.clr_back2;
				if (ChooseColor( &Clr ))
					Back2 = Clr.rgbResult;
				break;
			case CLR_WARN:
				Clr.rgbResult = settings.clr_warn_bk;
				if (ChooseColor( &Clr ))
					Warn1 = Clr.rgbResult;
				break;
			case CLR_WARN2:
				Clr.rgbResult = settings.clr_warn_txt;
				if (ChooseColor( &Clr ))
					Warn2 = Clr.rgbResult;
				break;
			case CLR_CALL:
				Clr.rgbResult = settings.clr_disasm_call;
				if (ChooseColor( &Clr ))
					Call = Clr.rgbResult;
				break;
			case CLR_JMP:
				Clr.rgbResult = settings.clr_disasm_jmp;
				if (ChooseColor( &Clr ))
					Jmp = Clr.rgbResult;
				break;
			case CLR_JCC:
				Clr.rgbResult = settings.clr_disasm_jcc;
				if (ChooseColor( &Clr ))
					Jcc = Clr.rgbResult;
				break;
			case CLR_RET:
				Clr.rgbResult = settings.clr_disasm_ret;
				if (ChooseColor( &Clr ))
					Ret = Clr.rgbResult;
				break;
			}
			ShowWindow(List_Test->getHwnd(), SW_HIDE);
			ListView_SetBkColor(List_Test->getHwnd(),settings.GetBackClr());
			ListView_SetTextBkColor(List_Test->getHwnd(),settings.GetBackClr());
			ListView_SetTextColor(List_Test->getHwnd(),settings.GetFrontClr());
			ShowWindow (List_Test->getHwnd(), SW_SHOW);

			ShowWindow(List_Dasm->getHwnd(), SW_HIDE);
			ListView_SetBkColor(List_Dasm->getHwnd(),settings.GetBackClr());
			ListView_SetTextBkColor(List_Dasm->getHwnd(),settings.GetBackClr());
			ListView_SetTextColor(List_Dasm->getHwnd(),settings.GetFrontClr());
			ShowWindow (List_Dasm->getHwnd(), SW_SHOW);
			break;
		};
	case	WM_NOTIFY:
		{
			if (((LPNMHDR)lParam)->code == NM_CUSTOMDRAW)
			{
				SetWindowLong(hWin, DWL_MSGRESULT, (LONG)Listview_Test((LPNMLVCUSTOMDRAW)lParam));
				return true;
			}
			else if (((LPNMHDR)lParam)->code == NM_DBLCLK && ((LPNMHDR)lParam)->hwndFrom == List_Test->getHwnd())
			{
				ShellExecute(0, 0, List_Test->getSelText(2, Temp, sizeof(Temp)), 0, 0, SW_SHOWMAXIMIZED);
			};
			break;
		};
	case	WM_CLOSE:
		{
			delete List_Test;
			delete List_Dasm;
			EndDialog(hWin,0);
			break;
		};
    };
    return false;
}