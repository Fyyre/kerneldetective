

typedef struct _UNEXPORTED_SYMBOLS {
    ULONG_PTR   SymbolAddress;
    WCHAR       SymbolMod[260];
    WCHAR       SymbolString[260];
} UNEXPORTED_SYMBOLS, *PUNEXPORTED_SYMBOLS;


EXTERN_C PWCHAR FullKernelModulesPath[22];

VOID InitializeSymbols(VOID);
VOID CleanupSymbols(VOID);
BOOL DecodeSymbol(ULONG_PTR Address, PULONG Displacement, PWCHAR StringBuffer, SIZE_T Count, BOOL decodemodule);
PWCHAR GetModulePath(ULONG_PTR Address, PWCHAR ModulePath, SIZE_T Count, BOOL GetSymbols = TRUE);