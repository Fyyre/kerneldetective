#include "Kernel Detective.h"
#include "Disassemble.h"
#include "Thread.h"
#include "Extras.h"
#include <psapi.h>

CListView *List_Thread;
HMENU		Menu_Thread;




void EnumThreads(PPROCESS_ENTRY Process, CListView *Listv)
{
	WCHAR Temp[BUFFER_LEN];
	ULONG Count = 0;
    PTHREAD_ENTRY Threads;
	HANDLE hSnapshot;
	PULARGE_INTEGER ApiThreads = NULL;
	long ApiThreadsCount = 0;
	HANDLE hOpenedThread;
	

	Listv->beginRefresh();
	//__try
	{
        Count = EnumerateThreads(&Threads, Process->ProcessObject);
		UPDATE_MODULES();
		Listv->clear();
		if (Threads)
		{
			hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
			if (INVALID_HANDLE_VALUE != hSnapshot) 
            {
				THREADENTRY32 ThreadEntry;
				ThreadEntry.dwSize = sizeof(ThreadEntry);
				if (Thread32First(hSnapshot, &ThreadEntry)) 
                {
					do 
                    {
						if (Process->Pid == ThreadEntry.th32OwnerProcessID || 
                            (Process->Pid == 0 && !_wcsicmp(Process->Name, L"System Idle Process")))
                        {
							++ApiThreadsCount;
							ApiThreads = (PULARGE_INTEGER)realloc(ApiThreads, ApiThreadsCount * sizeof(ULARGE_INTEGER));
							ApiThreads[ApiThreadsCount - 1].LowPart = ThreadEntry.th32ThreadID;
							ApiThreads[ApiThreadsCount - 1].HighPart = ThreadEntry.th32OwnerProcessID;
						}
					} while (Thread32Next(hSnapshot, &ThreadEntry));
				}
				CloseHandle(hSnapshot);
			}
            for	(ULONG c = 0; c < Count; ++c)
			{
				_snwprintf_s(Temp, COF(Temp), L"%u", Threads[c].Cid);
				Listv->insertRaw(Temp, TRUE);

				_snwprintf_s(Temp, COF(Temp), L"%u", Threads[c].ParentId);
				Listv->insertRaw(Temp, FALSE);

				_snwprintf_s(Temp, COF(Temp), L"0x%p", Threads[c].Thread);
				Listv->insertRaw(Temp, FALSE);

				_snwprintf_s(Temp, COF(Temp), L"0x%p", Threads[c].Teb);
				Listv->insertRaw(Temp, FALSE);

				Listv->insertRaw(decodethreadaddr(Temp, (ULONG)Threads[c].Address), FALSE);

				WCHAR *type[] = {L"Native", L"GUI"};
				Listv->insertRaw(type[Threads[c].Type], FALSE);

				_snwprintf_s(Temp, COF(Temp), L"0x%p", Threads[c].ServiceTable);
				Listv->insertRaw(Temp, FALSE);

				
				if (Threads[c].ThreadState == 5) // THREAD_STATE_WAIT
				{
					WCHAR *WaitReasonString[] = {
						L"Wait::Executive",
						L"Wait::FreePage",
						L"Wait::PageIn",
						L"Wait::PoolAllocation",
						L"Wait::DelayExecution",
						L"Wait::Suspended",
						L"Wait::UserRequest",
						L"Wait::WrExecutive",
						L"Wait::WrFreePage",
						L"Wait::WrPageIn",
						L"Wait::WrPoolAllocation",
						L"Wait::WrDelayExecution",
						L"Wait::WrSuspended",
						L"Wait::WrUserRequest",
						L"Wait::WrEventPair",
						L"Wait::WrQueue",
						L"Wait::WrLpcReceive",
						L"Wait::WrLpcReply",
						L"Wait::WrVirtualMemory",
						L"Wait::WrPageOut",
						L"Wait::WrRendezvous",
						L"Wait::WrKeyedEvent",
						L"Wait::WrTerminated",
						L"Wait::WrProcessInSwap",
						L"Wait::WrCpuRateControl",
						L"Wait::WrCalloutStack",
						L"Wait::WrKernel",
						L"Wait::WrResource",
						L"Wait::WrPushLock",
						L"Wait::WrMutex",
						L"Wait::WrQuantumEnd",
						L"Wait::WrDispatchInt",
						L"Wait::WrPreempted",
						L"Wait::WrYieldExecution",
						L"Wait::WrFastMutex",
						L"Wait::WrGuardedMutex",
						L"Wait::WrRundown",
						L"Wait::MaximumWaitReason"
                    };
					if (Threads[c].WaitReason < COF(WaitReasonString))
						Listv->insertRaw(WaitReasonString[Threads[c].WaitReason], FALSE);
					else
						Listv->insertRaw(L"Wait::UnknownWaitReason", FALSE);
				}
				else
				{
					WCHAR *thread_state[] = {
						L"Initialized", 
						L"Ready", 
						L"Running",
						L"Standby", 
						L"Terminated",
						L"Wait", 
						L"Transition",
						L"DeferredReady", 
						L"GateWait"
					};
					if (Threads[c].ThreadState < COF(thread_state))
						Listv->insertRaw(thread_state[Threads[c].ThreadState], FALSE);
					else
						Listv->insertRaw(L"-", FALSE);
				}

				long IsHiddenCounter;
				for (IsHiddenCounter = 0; IsHiddenCounter < ApiThreadsCount; ++IsHiddenCounter) 
                {
					if (ApiThreads[IsHiddenCounter].LowPart == (DWORD)Threads[c].Cid) 
                        break;
				}
				hOpenedThread = OpenThread(THREAD_ALL_ACCESS, FALSE, (DWORD)Threads[c].Cid);
				if (hOpenedThread)
                    CloseHandle(hOpenedThread);
				SYSTEM_BASIC_INFORMATION SBI;
				pNtQuerySystemInformation(SystemBasicInformation, &SBI, sizeof(SBI), NULL);
				if (IsHiddenCounter == ApiThreadsCount)
                {
					Listv->insertRaw(L"Hidden Thread", FALSE);
				} 
                else if (Threads[c].Address > (PVOID)SBI.HighestUserAddress && 
                    '-' == *GetModulePath((ULONG)Threads[c].Address, Temp, BUFFER_LEN)) 
                {
					Listv->insertRaw(L"Thread running in unknown module", FALSE);
				}
                else if (Threads[c].Status & (1 << 0)) 
                {
					Listv->insertRaw(L"ServiceTable Hooked", FALSE);
				} 
                else if (Threads[c].Status & (1 << 1)) 
                {
					Listv->insertRaw(L"Zombie Thread !", FALSE);
				} 
                else if (hOpenedThread == NULL)
                {
					Listv->insertRaw(L"Inaccessible from user-mode", FALSE);
				} 
                else if (Threads[c].Status & (1 << 2))
                {
					Listv->insertRaw(L"Critical Thread", FALSE);
				}
                else if (Threads[c].Status & (1 << 3))
                {
					Listv->insertRaw(L"Hidden From Debugger", FALSE);
				}
                else 
                {
					Listv->insertRaw(L"-", FALSE);
				}
			}
			delete[] Threads;
			free(ApiThreads);
		}
	}
	//__except(1)
	{}

	Listv->endRefresh();
	status.Format(L"Total Threads :: %lu", Count);
}


typedef struct _STACKTRACE
{
	//
	// Number of frames in Frames array.
	//
	UINT FrameCount;

	//
	// PC-Addresses of frames. Index 0 contains the topmost frame.
	//
	ULONG Frames[ ANYSIZE_ARRAY ];
} STACKTRACE, *PSTACKTRACE;


BOOL CALLBACK ReadProcessMemoryProc64(
	HANDLE hProcess,
	DWORD64 lpBaseAddress,
	PVOID lpBuffer,
	DWORD nSize,
	LPDWORD lpNumberOfBytesRead
	)
{
	if (hProcess && lpBaseAddress < 0x80000000)
	{
        RtlZeroMemory(lpBuffer, nSize);
        *lpNumberOfBytesRead = nSize;
        return KiReadVirtualMemory(KiCurrentProcess.ProcessObject, (PVOID)lpBaseAddress, lpBuffer, nSize);
		//return ReadProcessMemory(hProcess, (LPCVOID)lpBaseAddress, lpBuffer, nSize, lpNumberOfBytesRead);
	}
	else
	{
        RtlZeroMemory(lpBuffer, nSize);
        *lpNumberOfBytesRead = nSize;
        return KiReadVirtualMemory(KiCurrentProcess.ProcessObject, (PVOID)lpBaseAddress, lpBuffer, nSize);
	}
}


HRESULT CaptureStackTrace(
	HANDLE hProcess,
	HANDLE hThread,
	PCONTEXT Context,
	PSTACKTRACE StackTrace,
	UINT MaxFrames
	)
{
	DWORD MachineType;
	STACKFRAME64 StackFrame;


	//
	// Set up stack frame.
	//
	ZeroMemory( &StackFrame, sizeof( STACKFRAME64 ) );

	MachineType                 = IMAGE_FILE_MACHINE_I386;
	StackFrame.AddrPC.Offset    = Context->Eip;
	StackFrame.AddrPC.Mode      = AddrModeFlat;
	StackFrame.AddrFrame.Offset = Context->Ebp;
	StackFrame.AddrFrame.Mode   = AddrModeFlat;
	StackFrame.AddrStack.Offset = Context->Esp;
	StackFrame.AddrStack.Mode   = AddrModeFlat;
	StackFrame.AddrBStore = StackFrame.AddrFrame;

	StackTrace->FrameCount = 0;

	while ( StackTrace->FrameCount < MaxFrames )
	{
		if ( ! StackWalk64(
			MachineType,
			hProcess,
			hThread,
			&StackFrame,
			Context,
			ReadProcessMemoryProc64,
			SymFunctionTableAccess64,
			SymGetModuleBase64,
			NULL ) )
		{
			//
			// Maybe it failed, maybe we have finished walking the stack.
			//
			break;
		}

		if ( StackFrame.AddrPC.Offset != 0 )
		{
			//
			// Valid frame.
			//
			StackTrace->Frames[ StackTrace->FrameCount++ ] =
				(ULONG)StackFrame.AddrPC.Offset;
		}
		else
		{
			//
			// Base reached.
			//
			break;
		}
	}

	return S_OK;
}


PWCHAR DecodeStackAddress(HANDLE hProcess, ULONG Address, PWCHAR lpSymString)
{
	DWORD64 Disp;
	PIMAGEHLP_SYMBOL64 Symbol;
	IMAGEHLP_MODULEW ModuleInfo;

	Symbol = (PIMAGEHLP_SYMBOL64) new char [1024];
	Symbol->SizeOfStruct = sizeof(IMAGEHLP_SYMBOL64);
	Symbol->MaxNameLength = 512;
	lpSymString[0] = lpSymString[1] = lpSymString[2] = lpSymString[3] = TEXT('\0');
	RtlZeroMemory(&ModuleInfo, sizeof(ModuleInfo));
	ModuleInfo.SizeOfStruct = sizeof(ModuleInfo);
	if (Address < 0x80000000)
	{
		SymGetModuleInfoW(hProcess, Address, &ModuleInfo);
		if (ModuleInfo.BaseOfImage)
		{
			if (SymGetSymFromAddr64(hProcess, Address, &Disp, Symbol))
			{
				_snwprintf_s(lpSymString, 260, _TRUNCATE, Disp ? L"0x%p :: %s!%S+0x%x" : L"0x%p :: %s!%S", Address, ModuleInfo.ModuleName, Symbol->Name, Disp);
			}
			else
			{
				_snwprintf_s(lpSymString, 260, _TRUNCATE, L"0x%p :: %s+0x%x", Address, ModuleInfo.ModuleName, Address - ModuleInfo.BaseOfImage);
			}
		}
		else
		{
			decodethreadaddr(lpSymString, Address);
		}
	}
	else
	{
		SymGetModuleInfoW(NtCurrentProcess(), Address, &ModuleInfo);
		if (ModuleInfo.BaseOfImage)
		{
			if (SymGetSymFromAddr64(NtCurrentProcess(), Address, &Disp, Symbol))
			{
				_snwprintf_s(lpSymString, 260, _TRUNCATE, Disp ? L"0x%p :: %s!%S+0x%x" : L"0x%p :: %s!%S", Address, ModuleInfo.ModuleName, Symbol->Name, Disp);
			}
			else
			{
				_snwprintf_s(lpSymString, 260, _TRUNCATE, L"0x%p :: %s+0x%x", Address, ModuleInfo.ModuleName, Address - ModuleInfo.BaseOfImage);
			}
		}
		else
		{
			decodethreadaddr(lpSymString, Address);
		}
	}
	delete[] Symbol;
	return lpSymString;
}


VOID CaptureThreadStackTrace(CListView *ListView, STATUS_BAR *StatusBar)
{
	ULONG TotalCount = 0;
	WCHAR Buffer[260];
	PVOID Frames[64] = {0};
	PSTACKTRACE StackTrace;
	HANDLE hThread, hProcess;
	CONTEXT Context = {0};

	ListView->clear();

	StackTrace = (PSTACKTRACE)malloc(sizeof(STACKTRACE) + (sizeof(ULONGLONG) * 64));
	hThread = GetThreadHandle((PVOID)List_Thread->getSelUlong(2, 16));
	hProcess = GetProcessHandle(KiCurrentProcess.ProcessObject);
	SymInitialize(hProcess, NULL, TRUE);
	if (List_Thread->getSelUlong(0, 10) != GetCurrentThreadId())
		ThreadSuspend((PVOID)List_Thread->getSelUlong(2, 16));
	ThreadCaptureStack((PVOID)List_Thread->getSelUlong(2, 16), &Context);
	CaptureStackTrace(hProcess, hThread, &Context, StackTrace, 64);
	if (List_Thread->getSelUlong(0, 10) != GetCurrentThreadId())
		ThreadResume((PVOID)List_Thread->getSelUlong(2, 16), FALSE);
	UPDATE_MODULES();
	for (ULONG Index = 0; Index < StackTrace->FrameCount; Index++)
	{
		DecodeStackAddress(hProcess, StackTrace->Frames[Index], Buffer);
		ListView->insertRaw(Buffer, TRUE);
	}
	TotalCount = StackTrace->FrameCount;
	free(StackTrace);
	SymCleanup(hProcess);
	CloseHandle(hProcess);
	CloseHandle(hThread);

	StatusBar->Format(L"Stack trace Count = %d", TotalCount);
}


INT_PTR CALLBACK DlgStackTrace(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam, CListView * ListView, STATUS_BAR *StatusBar, HMENU HwndMenu)
{
	int wmId;
	WCHAR Buffer[512];

	switch (message)
	{
	case WM_INITDIALOG:
		_snwprintf_s(Buffer, COF(Buffer), L"Stack for thread %d :: 0x%p", List_Thread->getSelUlong(0, 10), List_Thread->getSelUlong(2, 16));
		SetWindowText(hWnd, Buffer);
		ListView->insertColumn(L"Call Address", 500);

		ADD_MENU(1, L"Refresh");
		ADD_MENU_SEP();
		ADD_MENU(2, L"Goto Address");

		CaptureThreadStackTrace(ListView, StatusBar);
		break;

	case WM_COMMAND:
		wmId = LOWORD(wParam);
		switch (wmId)
		{
		case 1:
			CaptureThreadStackTrace(ListView, StatusBar);
			break;
		case 2:
			GOTO_ADDRESS(ListView->getSelUlong(0, 16));
			break;
		default:
			return FALSE;
		}
		break;

	case WM_NOTIFY:
		if(((LPNMHDR)lParam)->code == NM_CUSTOMDRAW)
		{
			/*PWCHAR Warn[] = {
				L"Associated Thread running in unknown module",
				L"Associated DPC running in unknown module"
			};
			SetWindowLong(hWnd, DWL_MSGRESULT, (LONG)Listview_handler((LPNMLVCUSTOMDRAW)lParam, Warn, 2, 7, ListView));
			*/return TRUE;
		}
		else
		{
			return FALSE;
		}
		break;
	default:
		return FALSE;
	}
	return TRUE;
}


void CALLBACK Thread_Cmd(HWND hWin, WPARAM wParam, LPARAM lParam, CListView *Listv)
{
	ULONG offset = 0;
	int szCmd = 0;
	int Pos = 0;
	DWORD eProcess = 0;

	switch	(wParam)
	{
	case THREAD_REFRESH:
		{
			EnumThreads(&KiCurrentProcess, Listv);
			break;
		}
	case THREAD_TERMINATE_USER:
		{
			int c = Listv->getSelCount() + Listv->getSelIndex();
			for (int i = Listv->getSelIndex(); i < c; i++)
			{
				ULONG thread = Listv->getUlong(i, 0, 10);
				thread = (DWORD)OpenThread(THREAD_TERMINATE, FALSE, thread);
				if (thread)
				{
					TerminateThread((HANDLE)thread, EXIT_SUCCESS);
					CloseHandle((HANDLE)thread);
				}
			}
			Sleep(500);
			EnumThreads(&KiCurrentProcess, Listv);
			break;
		}
	case THREAD_TERMINATE_FORCE:
		{
			if (IDYES == MessageBox(hWin, L"This operation may cause BSOD !\r\n\r\nAre you sure ?", AppName, MB_ICONEXCLAMATION|MB_YESNO))
			{
				int c = Listv->getSelCount() + Listv->getSelIndex();
				for (int i = Listv->getSelIndex(); i < c; i++)
				{
					PVOID thread = (PVOID)Listv->getUlong(i, 2, 16);
					ThreadKill(thread);
				}
				Sleep(500);
				EnumThreads(&KiCurrentProcess, Listv);
			}
            break;
		}
	case THREAD_GOTO:
		{
			UpdateCommonBuffer(Listv->getSelUlong(2, 16), 0x400);
			if (KiReadVirtualMemory(KiCurrentProcess.ProcessObject, GetCommonReadAddress(), GetCommonReadBuffer(), GetCommonReadSize()))
				PrintDisasm(GetCommonReadBuffer(), GetCommonReadAddress(), GetCommonReadSize());
			break;
		}
	case THREAD_GOTO_START:
		{
            UpdateCommonBuffer(Listv->getSelUlong(4, 16), 0x400);
            if (KiReadVirtualMemory(KiCurrentProcess.ProcessObject, GetCommonReadAddress(), GetCommonReadBuffer(), GetCommonReadSize()))
				PrintDisasm(GetCommonReadBuffer(), GetCommonReadAddress(), GetCommonReadSize());
			break;
		}
	case THREAD_SSDT_CHANGE:
		{
            KI_PACKET KiPacket;
            if	(GetAddress(Listv->getSelUlong(6, 16), &KiPacket.Parameters.Common.Parameter2))
			{
                KiPacket.Parameters.Common.Parameter1 = Listv->getSelUlong(2, 16);
				Syscall(IOCTL_THREAD_SET_SSDT, &KiPacket);
				EnumThreads(&KiCurrentProcess, Listv);
			}
			break;
		}
	case THREAD_SSDT_RESTORE:
		{
            KI_PACKET KiPacket;
			int c = Listv->getSelCount() + Listv->getSelIndex();
			for (int i = Listv->getSelIndex(); i < c; i++)
			{
                KiPacket.Parameters.Common.Parameter1 = Listv->getUlong(i, 2, 16);
				Syscall(IOCTL_THREAD_RESTORE_SSDT, &KiPacket);
			}
			EnumThreads(&KiCurrentProcess, Listv);
			break;
		}
	case THREAD_SUSPEND:
		{
			int c = Listv->getSelCount() + Listv->getSelIndex();
			for (int i = Listv->getSelIndex(); i < c; i++)
			{
				PVOID thread = (PVOID)Listv->getUlong(i, 2, 16);
                ThreadSuspend(thread);
			}
			break;
		}
	case THREAD_RESUME:
		{
			int c = Listv->getSelCount() + Listv->getSelIndex();
			for (int i = Listv->getSelIndex(); i < c; i++)
			{
				PVOID thread = (PVOID)Listv->getUlong(i, 2, 16);
				ThreadResume(thread, FALSE);
			}
			break;
		}
	case THREAD_RESUME_FORCE:
		{
			int c = Listv->getSelCount() + Listv->getSelIndex();
			for (int i = Listv->getSelIndex(); i < c; i++)
			{
				PVOID thread = (PVOID)Listv->getUlong(i, 2, 16);
				ThreadResume(thread, TRUE);
			}
			break;
		}
	case THREAD_STACKTRACE:
		{
			DialogBoxParam(hInstance, MAKEINTRESOURCE(DLG_EXTRAS), hWin, DlgExtras, (LPARAM)DlgStackTrace);
			break;
		}
	}
}


BOOL CALLBACK DlgThread(HWND hWin,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
    POINT		XY;
	static CListView List_Thread(hWin);

	::List_Thread = &List_Thread;

    switch (uMsg)
    {
    case	WM_INITDIALOG :
		List_Thread.create(0, 0, 0, 0, settings.clr_back, settings.clr_front, 0);
        List_Thread.insertColumn(L"TID", 40);
		List_Thread.insertColumn(L"PID", 40);
		List_Thread.insertColumn(L"KTHREAD", 80);
		List_Thread.insertColumn(L"TEB", 80);
		List_Thread.insertColumn(L"StartAddress", 300);
		List_Thread.insertColumn(L"Type", 80);
        List_Thread.insertColumn(L"ServiceTable", 80);
		List_Thread.insertColumn(L"ThreadState", 120);
		List_Thread.insertColumn(L"Status", 200);
        Menu_Thread = GetSubMenu(LoadMenu(hInstance,MAKEINTRESOURCE(MENU_THREAD)),0);
        break;
	case	WM_SHOWWINDOW:
		if (wParam)
		{
			EnumThreads(&KiCurrentProcess, &List_Thread);
			CurrentList = &List_Thread;
		}
		break;
    case	WM_COMMAND :
		Thread_Cmd(hWin, wParam, lParam, &List_Thread);
        break;
	case WM_SIZE:
		{
			if(wParam != SIZE_MINIMIZED)
				List_Thread.resize(0, 0, LOWORD(lParam),HIWORD(lParam));
			break;
		}
    case	WM_NOTIFY :
		if	(((LPNMHDR)lParam)->hwndFrom == List_Thread.getHwnd()  &&  ((LPNMHDR)lParam)->code == NM_RCLICK)
        {
			if	(0 == List_Thread.isRawSelected()) break;
			if (!_wcsicmp(KiCurrentProcess.Name, L"System Idle Process"))
			{
				EnableMenuItem(Menu_Thread, THREAD_STACKTRACE, MF_BYCOMMAND | MF_GRAYED);
			}
			else
			{
				EnableMenuItem(Menu_Thread, THREAD_STACKTRACE, MF_BYCOMMAND | MF_ENABLED);
			}
            GetCursorPos(&XY);
            TrackPopupMenu(Menu_Thread,TPM_LEFTALIGN,XY.x,XY.y,NULL,hWin,NULL);
        }
		if(((LPNMHDR)lParam)->code == LVN_COLUMNCLICK)
		{
			((LPNMLISTVIEW)lParam)->lParam = (LPARAM)&List_Thread;
			ListView_SortItemsEx(((LPNMHDR)lParam)->hwndFrom, CListView::sort, (LPNMLISTVIEW)lParam);
			return TRUE;
		}
		if(((LPNMHDR)lParam)->code == NM_CUSTOMDRAW)
		{
			PWCHAR warn[] = {L"Hidden Thread", L"ServiceTable Hooked", L"Thread running in unknown module"};
			SetWindowLong(hWin, DWL_MSGRESULT, (LONG)Listview_handler((LPNMLVCUSTOMDRAW)lParam, warn, 3, 8, &List_Thread));
			return TRUE;
		}
        break;
    }
    return 0;
}
